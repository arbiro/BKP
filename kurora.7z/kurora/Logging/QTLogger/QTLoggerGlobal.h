#pragma once

/* MSVC DLL import/export. */
#ifdef _MSC_VER
#pragma warning(disable : 4297)
#ifdef QTLOGGER_LIB
#define QTLOGGER_LINK __declspec(dllexport)
#else
#define QTLOGGER_LINK __declspec(dllimport)
#endif
#else
#define QTLOGGER_LINK
#endif
#pragma once
