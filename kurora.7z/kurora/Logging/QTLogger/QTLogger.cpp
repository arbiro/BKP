#include <mutex>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <QLibraryInfo>
#include <QDebug>
#include <QLoggingCategory>
#include "Common.h"
#include "ILogger.h"
#include "QTLogger.h"

QTLOGGER_LINK Q_DECLARE_LOGGING_CATEGORY(LoggerCategory)
    Q_LOGGING_CATEGORY(LoggerCategory, "LoggerCategory")

        QT_BEGIN_NAMESPACE void PrintTo(const QString &qString, ::std::ostream *os) {
  *os << qString.toStdString(); // qUtf8Printable(qString);
}
QT_END_NAMESPACE

static void QTMessageHandler(QtMsgType type, const QMessageLogContext &context, const QString &msg);

class StreamWrapperQT : public StreamWrapper {
  void MessageHandler(const std::string &msg) override {
    switch (m_type) {
    case QtDebugMsg:
      m_logger.debug() << QString::fromStdString(msg);
      break;
    case QtInfoMsg:
      m_logger.info() << QString::fromStdString(msg);
      break;
    case QtWarningMsg:
      m_logger.warning() << QString::fromStdString(msg);
      break;
    case QtCriticalMsg:
      m_logger.critical() << QString::fromStdString(msg);
      break;
    case QtFatalMsg:
      m_logger.fatal("%s", msg.c_str());
    }
  }

public:
  StreamWrapperQT(QtMsgType t, QMessageLogger &loggerToUse) : m_type(t), m_logger(loggerToUse){};

private:
  QtMsgType m_type;
  QMessageLogger &m_logger;
};

class QTLogger : public ILogger {
  QTLogger(const std::string &logFilePath)
      : m_logger(QT_MESSAGELOG_FILE, QT_MESSAGELOG_LINE, QT_MESSAGELOG_FUNC) {
    m_logFile.setFileName(QString::fromStdString(logFilePath));
    m_logFile.open(QFile::ReadWrite | QFile::Append);
    m_stream.setDevice(&m_logFile);
    qInstallMessageHandler(QTMessageHandler);
  };

  QTLogger(const QTLogger &) = delete;
  QTLogger(const QTLogger &&) = delete;
  QTLogger &operator=(const QTLogger &) = delete;
  QTLogger &operator=(const QTLogger &&) = delete;

  friend void InitializeQTLogger();

public:
  ~QTLogger() {
    m_logFile.close();
  };

  StreamWrapper &info() override {
    static StreamWrapperQT wrapper(QtInfoMsg, m_logger);
    return wrapper;
  }

  StreamWrapper &debug() override {
    static StreamWrapperQT wrapper(QtDebugMsg, m_logger);
    return wrapper;
  }

  StreamWrapper &warning() override {
    static StreamWrapperQT wrapper(QtWarningMsg, m_logger);
    return wrapper;
  }

  StreamWrapper &error() override {
    static StreamWrapperQT wrapper(QtCriticalMsg, m_logger);
    return wrapper;
  }

  StreamWrapper &fatal() override {
    static StreamWrapperQT wrapper(QtFatalMsg, m_logger);
    return wrapper;
  }

  bool isDebugLevel() override {
    return LoggerCategory().isDebugEnabled();
  }

  bool isWarnLevel() override {
    return LoggerCategory().isWarningEnabled();
  }

  bool isInfoLevel() override {
    return LoggerCategory().isInfoEnabled();
  }

  bool isErrorLevel() override {
    return LoggerCategory().isCriticalEnabled();
  }

  bool isFatalLevel() override {
    return true;
  }

  QMessageLogger m_logger;
  QFile m_logFile;
  QTextStream m_stream;
  std::mutex m_mutex;
};

static LogLevel ConvertType(QtMsgType type) {
  switch (type) {
  case QtDebugMsg:
    return LogLevel(LogLevel::Value::DEBUG_LVL);
  case QtInfoMsg:
    return LogLevel(LogLevel::Value::INFO_LVL);
  case QtWarningMsg:
    return LogLevel(LogLevel::Value::WARNING_LVL);
  case QtCriticalMsg:
    return LogLevel(LogLevel::Value::ERROR_LVL);
  case QtFatalMsg:
    return LogLevel(LogLevel::Value::FATAL_LVL);
  }
}

static void QTMessageHandler(QtMsgType type, const QMessageLogContext &context,
                             const QString &msg) {

  QString fullMessage =
      QString::fromStdString(formatMessage(ConvertType(type), msg.toUtf8().constData()));
  QTLogger *qtlogger = dynamic_cast<QTLogger *>(&ILogger::GetLogger());

  if (qtlogger) {
    std::lock_guard<std::mutex> lock(qtlogger->m_mutex);
    if (qtlogger->m_logFile.isOpen())
      qtlogger->m_stream << fullMessage << endl;
  }
}

void InitializeQTLogger() {
  static bool isInitialized = false;
  if (!isInitialized) {
    isInitialized = true;
    ILogger::setImplementation(std::unique_ptr<QTLogger>(new QTLogger(DEFAULT_LOG_FILE)));
  }
}
