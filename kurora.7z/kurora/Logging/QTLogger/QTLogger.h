#pragma once
#include "QTLoggerGlobal.h"

QTLOGGER_LINK void InitializeQTLogger();
