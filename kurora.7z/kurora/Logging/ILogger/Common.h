#pragma once

#include <string>
#include <ILoggerGlobal.h>

struct LogLevel {
  enum class Value { FATAL_LVL, ERROR_LVL, INFO_LVL, WARNING_LVL, DEBUG_LVL } value;

  LogLevel(Value value = Value::INFO_LVL) : value(value) {}

  operator std::string() const {
    switch (value) {
    case Value::FATAL_LVL:
      return "fatal";
    case Value::ERROR_LVL:
      return "error";
    case Value::INFO_LVL:
      return "info";
    case Value::WARNING_LVL:
      return "warn";
    case Value::DEBUG_LVL:
      return "debug";
    }
  }
};

LOGGING_LINK std::string formatMessage(LogLevel logLevel, std::string message);
