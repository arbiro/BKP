#include <iostream>
#include <mutex>
#include "ILogger.h"
#include "Common.h"

static std::unique_ptr<ILogger> m_loggerImpl = nullptr;

StreamWrapper &StreamWrapper::operator<<(const std::string &str) {
  this->MessageHandler(str);
  return *this;
}

void ILogger::setImplementation(std::unique_ptr<ILogger> logger) {
  m_loggerImpl = std::move(logger);
}

class StreamWrapperSTD : public StreamWrapper {

  void MessageHandler(const std::string &msg) override {
    std::lock_guard<std::mutex> lockMe(m_mutex);
    switch (m_type.value) {
    case LogLevel::Value::INFO_LVL:
    case LogLevel::Value::DEBUG_LVL:
      std::cout << formatMessage(m_type, msg);
      break;
    case LogLevel::Value::WARNING_LVL:
    case LogLevel::Value::ERROR_LVL:
    case LogLevel::Value::FATAL_LVL:
      std::cerr << formatMessage(m_type, msg);
      break;
    }
  }
  static std::mutex m_mutex;

public:
  StreamWrapperSTD(LogLevel t) : m_type(t){};

private:
  LogLevel m_type;
};

std::mutex StreamWrapperSTD::m_mutex;

class STDLogger : public ILogger {
public:
  STDLogger(){};

  STDLogger(const STDLogger &) = delete;
  STDLogger(const STDLogger &&) = delete;
  STDLogger &operator=(const STDLogger &) = delete;
  STDLogger &operator=(const STDLogger &&) = delete;

  ~STDLogger(){};

  StreamWrapper &info() override {
    static StreamWrapperSTD wrapper(LogLevel::Value::INFO_LVL);
    return wrapper;
  }

  StreamWrapper &debug() override {
    static StreamWrapperSTD wrapper(LogLevel::Value::DEBUG_LVL);
    return wrapper;
  }

  StreamWrapper &warning() override {
    static StreamWrapperSTD wrapper(LogLevel::Value::WARNING_LVL);
    return wrapper;
  }

  StreamWrapper &error() override {
    static StreamWrapperSTD wrapper(LogLevel::Value::ERROR_LVL);
    return wrapper;
  }

  StreamWrapper &fatal() override {
    static StreamWrapperSTD wrapper(LogLevel::Value::FATAL_LVL);
    return wrapper;
  }

  bool isDebugLevel() override {
    return true;
  }

  bool isWarnLevel() override {
    return true;
  }

  bool isInfoLevel() override {
    return true;
  }

  bool isErrorLevel() override {
    return true;
  }

  bool isFatalLevel() override {
    return true;
  }
};

ILogger &ILogger::GetLogger() {
  if (m_loggerImpl == nullptr) {
    m_loggerImpl.reset(new STDLogger());
  }
  return *m_loggerImpl;
}
