#pragma once

/* MSVC DLL import/export. */
#ifdef _MSC_VER
#pragma warning(disable : 4297)
#ifdef LOGGING_LIB
#define LOGGING_LINK __declspec(dllexport)
#else
#define LOGGING_LINK __declspec(dllimport)
#endif
#else
#define LOGGING_LINK
#endif