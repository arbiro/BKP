#pragma once

#include <memory>
#include <ILoggerGlobal.h>

class LOGGING_LINK StreamWrapper {
  virtual void MessageHandler(const std::string &msg) = 0;

public:
  StreamWrapper &operator<<(const std::string &str);
  operator bool() const {
    return true;
  }
};

class LOGGING_LINK ILogger {
public:
  virtual ~ILogger() {}
  virtual StreamWrapper &info() = 0;
  virtual StreamWrapper &debug() = 0;
  virtual StreamWrapper &warning() = 0;
  virtual StreamWrapper &error() = 0;
  virtual StreamWrapper &fatal() = 0;

  virtual bool isDebugLevel() = 0;
  virtual bool isWarnLevel() = 0;
  virtual bool isInfoLevel() = 0;
  virtual bool isErrorLevel() = 0;
  virtual bool isFatalLevel() = 0;

  static ILogger &GetLogger();
  static void setImplementation(std::unique_ptr<ILogger> logger);
};

#define DEBLOG ILogger::GetLogger().isDebugLevel() && ILogger::GetLogger().debug()
#define WARNLOG ILogger::GetLogger().isWarnLevel() && ILogger::GetLogger().warning()
#define INFOLOG ILogger::GetLogger().isInfoLevel() && ILogger::GetLogger().info()
#define ERRLOG ILogger::GetLogger().isErrorLevel() && ILogger::GetLogger().error()
#define FATALLOG ILogger::GetLogger().isFatalLevel() && ILogger::GetLogger().fatal()