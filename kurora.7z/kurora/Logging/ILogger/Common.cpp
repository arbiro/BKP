#include <ctime>
#include "Common.h"

/*
Get the current date and time in format: YYYY-MM-DD_HH:MM:SS
*/
static std::string GetCurrentDateTime() {
	time_t rawtime;
	struct tm *timeinfo;
	char buffer[80];

	time(&rawtime);
	timeinfo = localtime(&rawtime);

	strftime(buffer, sizeof(buffer) / sizeof(buffer[0]), "%F_%H:%M:%S", timeinfo);

	return buffer;
}

/*
Formatting the message written in the output file: [YYYY-MM-DD_HH:MM:SS] [LOGLEVEL]: message
*/
std::string formatMessage(LogLevel logLevel, std::string message) {
	std::string fullMessage =
		"[" + GetCurrentDateTime() + "] [" + std::string(logLevel) + "]: " + message;
	return fullMessage;
}