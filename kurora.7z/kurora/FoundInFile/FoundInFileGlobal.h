#pragma once

/* MSVC DLL import/export. */
#ifdef _MSC_VER
#pragma warning(disable : 4297)
#ifdef FIF_LIB
#define FIF_LINK __declspec(dllexport)
#else
#define FIF_LINK __declspec(dllimport)
#endif
#else
#define FIF_LINK
#endif
