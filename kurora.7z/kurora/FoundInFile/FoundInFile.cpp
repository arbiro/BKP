#include <memory>
#include <algorithm>
#include <string>
#include <cctype>
#include <fstream>
#include <tulip/StringCollection.h>
#include <tulip/GraphProperty.h>
#include <tulip/ForEach.h>
#include <tulip/Graph.h>
#include <tulip/StringProperty.h>
#include <cstdio>
#include "FoundInFile.h"

PLUGIN(FoundInFile)

using namespace std;
using namespace tlp;

const char *FILENAMECC = "file::Values File";
const char *PROPERTY = "String property";
const char *selNodes = "selectnodes";
const char *selEdges = "selectedges";

FoundInFile::FoundInFile(tlp::PluginContext *context) : BooleanAlgorithm(context) {
  addInParameter<string>(FILENAMECC, "Values file", "");
  addInParameter<StringProperty>(PROPERTY, "Property", "");
  addInParameter<bool>(selNodes, "Select nodes", "True");
  addInParameter<bool>(selEdges, "Select edges", "True");
}

bool FoundInFile::run() {
  std::string fileName;
  StringProperty *filterProp;
  bool selectNodes = true;
  bool selectEdges = true;
  if (dataSet != nullptr) {
    dataSet->get(PROPERTY, filterProp);
    dataSet->get(FILENAMECC, fileName);
    dataSet->get(selNodes, selectNodes);
    dataSet->get(selEdges, selectEdges);
  }

  if (fileName.empty()) {
    if (pluginProgress)
      pluginProgress->setError("Error: A file with values must be selected!");

    return false;
  }
  if (filterProp == nullptr) {
    if (pluginProgress)
      pluginProgress->setError("Error: A property must be selected");

    return false;
  }

  std::ifstream input;
  input.open(fileName);
  if (!input.is_open()) {
    if (pluginProgress)
      pluginProgress->setError("Error: Values file could not be opened!");

    return false;
  }
  std::string line;
  std::unordered_set<std::string> values;
  while (std::getline(input, line)) {
    values.insert(line);
  }
  if (selectNodes) {
    result->setAllNodeValue(false);

    for (tlp::node n : graph->nodes()) {
      if (values.find(filterProp->getNodeValue(n)) != values.end()) {
        result->setNodeValue(n, true);
      }
    }
  }
  if (selectEdges) {
    result->setAllEdgeValue(false);

    for (tlp::edge e : graph->edges()) {
      if (values.find(filterProp->getEdgeValue(e)) != values.end()) {
        result->setEdgeValue(e, true);
      }
    }
  }

  return true;
}