#pragma once

#include <tulip/TulipPluginHeaders.h>
#include <tulip/NumericProperty.h>
#include <tulip/TulipViewSettings.h>
#include "FoundInFileGlobal.h"

class FoundInFile : public tlp::BooleanAlgorithm {
public:
  PLUGININFORMATION("FoundinFile", "Murex Team", "29/01/2018",
                    "Selects nodes with property of selected file specified values ", "1.0", "Misc")
  FoundInFile(tlp::PluginContext *context);
  bool run() override;
};
