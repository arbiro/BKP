#include <string>
#include <fstream>
#include <memory>
#include <functional>
#include <tulip/StringCollection.h>
#include "BooleanOperations.h"

PLUGIN(BooleanOperations)

using namespace tlp;
using namespace std;

const char *SELECTION1 = "First selection";
const char *SELECTION2 = "Second selection";
const char *OPERATOR = "Boolean operator";
enum class Operator { AND, OR, XOR, IMPLY, EQUAL };


BooleanOperations::BooleanOperations(PluginContext *context) : BooleanAlgorithm(context) {
	addInParameter<BooleanProperty>(SELECTION1, "First input selection", "");
	addInParameter<BooleanProperty>(SELECTION2, "Second input selection", "");
	addInParameter<StringCollection>(OPERATOR, "Boolean operator", "AND;OR;XOR;IMPLY;EQUAL", true,
		"AND <br> OR <br> XOR <br> IMPLY <br> EQUAL");
}

std::function<bool(bool, bool)> operationFunction(Operator symbol) {
	switch (symbol) {
	case Operator::AND:
		return [](bool a, bool b) { return a & b; };
	case Operator::OR:
		return [](bool a, bool b) { return a | b; };
	case Operator::XOR:
		return [](bool a, bool b) { return a ^ b; };
	case Operator::IMPLY:
		return [](bool a, bool b) { return (!a) | b; };
	case Operator::EQUAL:
		return [](bool a, bool b) { return !(a ^ b); };
	default:
		return [](bool a, bool b) { return false; };
	}
}

bool BooleanOperations::run() {
	BooleanProperty* firstSelection;
	BooleanProperty* secondSelection;
	StringCollection operatorCollection;
	Operator symbol;

	if (!dataSet)
		return false;

	dataSet->get(SELECTION1, firstSelection);
	dataSet->get(SELECTION2, secondSelection);
	dataSet->get(OPERATOR, operatorCollection);
	symbol = Operator(operatorCollection.getCurrent());

	result->setAllNodeValue(false);

	std::function<bool(bool, bool)> booleanOperation = operationFunction(symbol);

	for (node n : graph->nodes()) {
		if (booleanOperation(firstSelection->getNodeValue(n), secondSelection->getNodeValue(n))) {
			result->setNodeValue(n, true);
		}
	}

	for (edge e : graph->edges()) {
		if (booleanOperation(firstSelection->getEdgeValue(e), secondSelection->getEdgeValue(e))) {
			result->setEdgeValue(e, true);
		}
	}


	return true;
}