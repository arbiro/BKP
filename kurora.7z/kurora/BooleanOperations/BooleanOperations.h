#pragma once
#include <tulip/TulipPluginHeaders.h>

class BooleanOperations : public tlp::BooleanAlgorithm {
public:
	PLUGININFORMATION("BooleanOperations", "Murex Team", "23/03/2018",
		"Apply a boolean operator on two selections", "1.0", "Selection")
	BooleanOperations(tlp::PluginContext *context);
	bool run() override;
};
