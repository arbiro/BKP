#include <tulip/DoubleProperty.h>

#include "Isolated.h"

PLUGIN(Isolated)

using namespace tlp;

Isolated::Isolated(tlp::PluginContext *context) : BooleanAlgorithm(context) {}

struct Data {
  // return result.
  tlp::BooleanProperty *selection;

  Data(tlp::BooleanProperty *s) : selection(s) {}

  bool result(tlp::Graph *g, tlp::PluginProgress *progress) {
    auto size = g->numberOfNodes();
    int i = 0;
    for (auto n : g->nodes()) {
      if (progress->progress(i, size) != tlp::TLP_CONTINUE)
        return false;
      if (g->deg(n) == 0)
        selection->setNodeValue(n, true);
      ++i;
    }
    return true;
  }
};

bool Isolated::run() {
  return Data(result).result(graph, pluginProgress);
}
