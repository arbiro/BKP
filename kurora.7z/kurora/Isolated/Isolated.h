#pragma once

#include <tulip/TulipPluginHeaders.h>

/*
** This plugin selects the isolated nodes of the graph.
*/

class Isolated : public tlp::BooleanAlgorithm {
public:
  PLUGININFORMATION("Isolated", "Murex Team", "19/03/2018", "Select isolated nodes", "1.0",
                    "Selection");
  Isolated(tlp::PluginContext *context);

  bool run();
};
