#include "gtest/gtest.h"
#include <memory>

#include <tulip/Graph.h>
#include <tulip/PluginProgress.h>
#include <tulip/DataSet.h>

#include <Mincut.h>

using namespace std;
using namespace tlp;

// Empty graph should not be valid.
TEST(MinCutTest, EmptyGraph) {

  const tlp::PluginContext *pc = new tlp::AlgorithmContext(NULL, NULL, NULL);
  Mincut *mc = new Mincut(pc);
  bool res = mc->run();

  EXPECT_EQ(res, false);
}

// Test on simple graph with isolated node.
TEST(MinCutTest, SimpleGraph) {

  Graph *graph = tlp::newGraph();

  node n1 = graph->addNode();
  node n2 = graph->addNode();
  node n3 = graph->addNode();
  node n4 = graph->addNode();

  edge e12 = graph->addEdge(n1, n2);
  edge e23 = graph->addEdge(n2, n3);
  edge e31 = graph->addEdge(n3, n1);
  edge e14 = graph->addEdge(n1, n4);

  auto ds = new DataSet();
  ds->set(Mincut::REMAINING_NODES, 2);
  ds->set(Mincut::ITERATIONS, 16);

  int nodeId;
  int res;
  for (int i = 0; i < 1000; ++i) {
    const tlp::PluginContext *pc = new tlp::AlgorithmContext(graph, ds, NULL);
    Mincut *mc = new Mincut(pc);
    mc->run();
    auto *propGraph = graph->getProperty<IntegerProperty>(Mincut::PROP_NAME);

    nodeId = 1;
    res = 0;
    for (auto n : graph->nodes()) {
      auto p = propGraph->getNodeValue(n);
      if (p == 1 && nodeId != 4)
        res++;
      nodeId++;
    }
  }

  EXPECT_EQ(res, 0);
  EXPECT_TRUE(graph->existProperty(Mincut::PROP_NAME));
}

// Test on cyclic graph with only 1 possible mincut.
TEST(MinCutTest, Cyclic1) {

  Graph *graph = tlp::newGraph();

  node n1 = graph->addNode();
  node n2 = graph->addNode();
  node n3 = graph->addNode();
  node n4 = graph->addNode();

  edge e12 = graph->addEdge(n1, n2);
  edge e21 = graph->addEdge(n2, n1);
  edge e23 = graph->addEdge(n2, n3);
  edge e34 = graph->addEdge(n3, n4);
  edge e41 = graph->addEdge(n4, n1);
  edge e31 = graph->addEdge(n3, n1);

  auto ds = new DataSet();

  ds->set(Mincut::REMAINING_NODES, 2);
  ds->set(Mincut::ITERATIONS, 16);

  int nodeId;
  int res;
  for (int i = 0; i < 1000; ++i) {
    const tlp::PluginContext *pc = new tlp::AlgorithmContext(graph, ds, NULL);
    Mincut *mc = new Mincut(pc);
    mc->run();

    auto *propGraph = graph->getProperty<IntegerProperty>(Mincut::PROP_NAME);

    nodeId = 1;
    res = 0;
    for (auto n : graph->nodes()) {
      auto p = propGraph->getNodeValue(n);
      if (p == 1 && nodeId != 4)
        res++;
      nodeId++;
    }
  }

  EXPECT_EQ(res, 0);
}

// Test on cyclic graph with 2 possibles mincut.
TEST(MinCutTest, Cyclic2) {

  Graph *graph = tlp::newGraph();

  node n1 = graph->addNode();
  node n2 = graph->addNode();
  node n3 = graph->addNode();
  node n4 = graph->addNode();

  edge e12 = graph->addEdge(n1, n2);
  edge e23 = graph->addEdge(n2, n3);
  edge e34 = graph->addEdge(n3, n4);
  edge e41 = graph->addEdge(n4, n1);
  edge e31 = graph->addEdge(n3, n1);

  auto ds = new DataSet();

  ds->set(Mincut::REMAINING_NODES, 2);
  ds->set(Mincut::ITERATIONS, 16);

  int nodeId;
  int res;
  for (int i = 0; i < 1000; ++i) {
    const tlp::PluginContext *pc = new tlp::AlgorithmContext(graph, ds, NULL);
    Mincut *mc = new Mincut(pc);
    mc->run();

    auto *propGraph = graph->getProperty<IntegerProperty>(Mincut::PROP_NAME);

    nodeId = 1;
    res = 0;
    for (auto n : graph->nodes()) {
      auto p = propGraph->getNodeValue(n);
      if (p == 1 && (nodeId == 1 || nodeId == 3))
        res++;
      nodeId++;
    }
  }

  EXPECT_EQ(res, 0);
}
