#include <memory>
#include "ParserTest.h"

RelSymbol::RelSymbol(std::string symbolString) {
  size_t pos = 0;
  std::string token[2];
  int i = 0;
  while ((pos = symbolString.find(delimiter)) != std::string::npos) {
    token[i] = symbolString.substr(0, pos);
    symbolString.erase(0, pos + delimiter.length());
    i++;
  }
  location = token[0];
  name = token[1];
  type = symbolString;
}

std::string RelSymbol::asString() const {
  std::ostringstream os;
  os << location << "||" << name << "||" << type;
  return os.str();
}

std::string Relation::asString() const {
  std::ostringstream os;
  os << source.asString() << " --" << type << "-> " << target.asString();
  return os.str();
}

RelationReader::RelationReader(const std::string &file) {
  std::ifstream input;
  input.open(file);
  std::string line;
  int count = 0;
  Relation relationship;
  while (std::getline(input, line) && readRelation(input, relationship)) {
    relations.push_back(relationship);
  }
}

std::vector<Relation> &RelationReader::getRelationsConst() {
  return relations;
}

bool RelationReader::readRelation(std::ifstream &input, Relation &relation) {
  std::string line;
  int c = 0;
  std::string strings[3];
  while (c < 3 && std::getline(input, line)) {
    strings[c] = line;
    c++;
  }
  if (c == 3) {
    relation.source = RelSymbol(strings[0]);
    relation.type = strings[1];
    relation.target = RelSymbol(strings[2]);

    return true;
  }
  return false;
}

void RelationTester::test() {
  tlp::edge edge;

  auto &relations = reader.getRelationsConst();
  EdgesMap edgesMap;

  forEach (edge, graph->getEdges()) {
    std::string edgeType = n_type->getEdgeValue(edge);
    edgesMap.insert(std::make_pair(edgeType, EdgeAndMatched(edge, 0)));
  }

  for (auto &relation : relations) {
    EXPECT_EQ("Ok", checkRelation(relation, edgesMap));
  }

  for (const auto &edgeList : edgesMap) {
    std::string edgeResult = "Ok";
    edgeLogFile.open(EdgeLog, std::ofstream::out | std::ofstream::app);
    if (edgeList.second.matched != 1) {
      std::string error =
          edgeList.second.matched == 0 ? "Edge not matched " : "Edge had multiple matches ";

      std::stringstream os;
      os << error << " in \n" << printEdge(edgeList.second.edge);
      edgeResult = os.str();
      edgeLogFile << os.rdbuf();
    }
    edgeLogFile.close();

    EXPECT_EQ("Ok", edgeResult);
  }
}

static std::string getNodeType(std::string key) {
  return NodeType::fromChar(key.empty() ? 'a' : key.back()).getName();
}

std::string escapeStringForXML(const std::string &str) {
  std::stringstream stringBuffer;
  for (int i = 0; i < str.size(); i++) {
    const char c = str[i];
    switch (c) {
    case '&': {
      stringBuffer << "&amp;";
      break;
    }
    case '\"': {
      stringBuffer << "&quot;";
      break;
    }
    case '<': {
      stringBuffer << "&lt;";
      break;
    }
    case '>': {
      stringBuffer << "&gt;";
      break;
    }
    case '\'': {
      stringBuffer << "&apos;";
      break;
    }
    default: {
      stringBuffer << c;
      break;
    }
    }
  }

  return stringBuffer.str();
}

std::string RelationTester::printNode(std::string source, const tlp::node &node) {
  std::ostringstream os;
  os << "\t<" << source << " name=\"" << escapeStringForXML(n_demangled->getNodeValue(node))
     << "\" type=\"" << getNodeType(n_key->getNodeValue(node)) << "\" location=\""
     << getFileName(n_path->getNodeValue(node)) << "\"/\>\n";
  return os.str();
}

std::string RelationTester::printEdge(const tlp::edge &edge) {
  tlp::node source = graph->source(edge);
  tlp::node target = graph->target(edge);
  std::string edgeType = n_type->getEdgeValue(edge);
  std::stringstream os;

  os << "<relation type=\"" << edgeType << "\">\n";
  os << printNode("source", source) << printNode("target", target);
  os << "</relation>\n";

  return os.str();
}

bool RelationTester::nodeIsLikeSymbol(const tlp::node &node, const RelSymbol &symbol) {
  std::string nodeName = n_demangled->getNodeValue(node);
  if (nodeName != symbol.name) {
    return false;
  }

  if (symbol.location.length() > 0) {
    std::string nodeLocation = n_path->getNodeValue(node);
    if (nodeLocation != symbol.location) {
      return false;
    }
  }

  if (symbol.type.length() > 0) {
    std::string key = n_key->getNodeValue(node);
    std::string nodeType = getNodeType(key);

    if (nodeType != symbol.type) {
      return false;
    }
  }
  return true;
}

std::string RelationTester::checkRelation(const Relation &relation, EdgesMap &edgesMap) {
  auto edgesOfTypeFound = edgesMap.equal_range(relation.type);
  int matchCount = 0;
  for (auto sourceIt = edgesOfTypeFound.first; sourceIt != edgesOfTypeFound.second; ++sourceIt) {
    const tlp::edge &currentEdge = sourceIt->second.edge;
    if (nodeIsLikeSymbol(graph->source(currentEdge), relation.source) &&
        nodeIsLikeSymbol(graph->target(currentEdge), relation.target)) {
      sourceIt->second.matched = true;
      matchCount++;
    }
  }
  if (matchCount == 1) {
    return "Ok";
  }

  std::string error = matchCount == 0 ? "Type not found" : "Multiple matches";

  std::ostringstream os;
  os << error << " in " << relation.asString();
  return os.str();
}

void TestForCompliance(Database &db, std::string pathTo) {
  try {
    tlp::Graph *g = tlp::newGraph();
    GraphAlgorithm graph(g);
    graph.createGraph(db);
    RelationReader reader(pathTo + "/relations.txt");
    RelationTester tester(reader, g);
    tester.test();
  } catch (const std::exception &e) {
    std::cerr << e.what() << std::endl;
  }
}

void RunTestAST(std::string pathTo) {
  std::string dbName = pathTo + "/TestDb";
  QFile file(dbName.c_str());
  ASSERT_TRUE(!file.exists() || file.remove()) << "Cannot remove the DB in " << dbName;

  std::unique_ptr<Database> db(new Database(dbName));

  const std::vector<std::string> &files = getFilesInCompilationDb(pathTo);

  ParseFile parseFile(
      setOptions(files, pathTo, getInlinesAllTemplateFlag(pathTo + "/relations.txt"), true), *db);
  FillDatabase fill(*db);
  for (auto file : files) {
    Database *result = db.get();
    fill(result, parseFile(file));
  }

  EXPECT_TRUE(db->getTotalNodesCount() > 0);

  TestForCompliance(*db, pathTo);
}

void RunTest(std::string pathTo) {
  std::string dbName = pathTo + "/TestDb";
  QFile file(dbName.c_str());
  ASSERT_TRUE(!file.exists() || file.remove()) << "Cannot remove the DB in " << dbName;

  std::unique_ptr<Database> db(new Database(dbName));

  const std::vector<std::string> &files = getFilesInCompilationDb(pathTo);
  /*
  QThreadPool::globalInstance()->setMaxThreadCount(1);
  QFuture<Database*> fut = QtConcurrent::mappedReduced<Database*, std::vector<std::string>,
  ParseFile, FillDatabase>(files, ParseFile(setOptions(files, true, true, pathTo), db.get()),
  FillDatabase(*db)); fut.result();
  */
  ParseFile parseFile(
      setOptions(files, pathTo, getInlinesAllTemplateFlag(pathTo + "/relations.txt")), *db);
  FillDatabase fill(*db);
  for (auto file : files) {
    Database *result = db.get();
    fill(result, parseFile(file));
  }

  EXPECT_TRUE(db->getTotalNodesCount() > 0);

  TestForCompliance(*db, pathTo);
}
void SplitFilename(const std::string &str, std::string &path, std::string &file) {

  unsigned found = str.find_last_of("/\\");
  if (found != std::string::npos) {
    path = str.substr(0, found);
    file = str.substr(found + 1);
  }
}

std::string getFileName(const std::string path) {
  std::string justpath;
  std::string file;
  SplitFilename(path, justpath, file);
  return file;
}
//
// TEST_F(ParserTest, Implements)
//{
//	RunTest(Test1);
//}
//
//
// TEST_F(ParserTest, StaticCalls)
//{
//	RunTest(Test2);
//}
//
//
// TEST_F(ParserTest, VirtualCalls)
//{
//	RunTest(Test3);
//}
//
// TEST_F(ParserTest, Overrides)
//{
//	RunTest(Test4);
//}
//
// TEST_F(ParserTest, Statics)
//{
//	RunTest(Test5);
//}
//
// TEST_F(ParserTest, Templates)
//{
//	RunTest(Test6);
//}
