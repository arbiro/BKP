import sys
import glob
import json
from xml.dom import minidom
import sys
import string
import subprocess
import os
import traceback
from graphviz import Digraph

path = ""
form = 'png'
#graph = nx.DiGraph()
graph = Digraph(format=form)

def addccitemforcpp(path, cpppath):
    commandString ="clang-tool -std=c++14 \""+cpppath+"\""
    data = {"directory" : path, "command" : commandString, "file" : cpppath}
    return data

def addTest(name):
    testString = "TEST_F(ParserTest, "+ name + ") { RunTest(\""+ dirpath +"\"); }"
    testscpp.write(testString+"\n\n")
    testStringAST = "TEST_F(ParserTest, "+ name+"AST" + ") { RunTestAST(\""+ dirpath +"\"); }"
    testscpp.write(testStringAST+"\n\n")

RealLocations = {}


nodeCount = ord('a')
nodeDict = {}

def addNodeIfNonExistent(nodeLabel):
    global nodeDict
    global nodeCount
    if nodeLabel not in nodeDict:
        nodeCount = nodeCount+1
        nodeDict[nodeLabel] = chr(nodeCount)
    graph.node(nodeDict[nodeLabel], nodeLabel)
    return nodeDict[nodeLabel]

def addEdgeToDocGraph(nodeSrc, nodeTarget, type):
    graph.edge(addNodeIfNonExistent(nodeSrc), addNodeIfNonExistent(nodeTarget), label = type)

def exportCpps(test):
    files = test.getElementsByTagName("file")
    for file in files:
        data = file.firstChild.data
        name = file.attributes['name'].value
        realPath = dirpath + "/"+name
        with open(realPath, 'w') as outfile:
            RealLocations[name] = realPath
            outfile.write(data)


def getSourceOrTargetElementAttributes(element):
    name = element.attributes['name'].value
    location = ""
    type = "" #def is default
    if "location" in element.attributes:
        location = element.attributes['location'].value
    if "type" in element.attributes:
        type = element.attributes['type'].value
    return (name, location, type)

def exportRelation(outFile, relation):
    fromElement = relation.getElementsByTagName("source")
    toElement = relation.getElementsByTagName("target")
    if fromElement.length > 1:
        print("Warning: Relation has too many froms" + relation + "\n")
    fromElement = fromElement[0]
    if toElement.length > 1:
        print("Warning: Relation has too many tos" + relation + "\n")
    toElement = toElement[0]
    #
    (name, location, type) = getSourceOrTargetElementAttributes(fromElement)
    source = getRealLocation(location) + "||" + name + "||" + type
    #adding the nodes to the graph for documentation
    graphSrc = name+"||"+type

    #
    (name, location, type) = getSourceOrTargetElementAttributes(toElement)
    target = getRealLocation(location) + "||" + name + "||" + type

    graphTarget = name + "||" + type


    type = relation.attributes['type'].value

    outFile.write(source+"\n"+type+"\n"+target+"\n\n")

    addEdgeToDocGraph(graphSrc, graphTarget, type)

def exportRelations(test):
    relations = test.getElementsByTagName("relation")
    with open(dirpath + "/relations.txt", 'a') as outFile:
        for relation in relations:
            exportRelation(outFile, relation)

def exportinlinesalltemplate(test):
    inlinesAllTemplate = test.getAttribute('inlinesAllTemplate')
    if inlinesAllTemplate=="":
        inlinesAllTemplate = "true"
    with open(dirpath + "/relations.txt", 'w') as outFile:
        outFile.write(inlinesAllTemplate + "\n")

def exportTest(parsertest):
    exportCpps(parsertest)
    exportinlinesalltemplate(parsertest)
    exportRelations(parsertest)

def getRealLocation(loc):
    return RealLocations[loc]


#get directory name, create it if it doesn't exist
def createDirectory(test):
	global dirpath
	dirname = test.getAttribute('name')
	assert(len(dirname)!=0)
	dirpath = path + "/samples/" + dirname
	if not os.path.exists(dirpath):
		os.makedirs(dirpath)
	print(dirpath)
	os.chdir(dirpath)
	return dirname;

def drawAndExportGraph(graph, name):
    imgName = name
    imgPath = imgsdir + imgName
    graph.render(imgPath, view=False, cleanup=True)
    return imgName


docmd = open("readme.md", "w");
maindir = os.getcwd()
relimgsdir = "img/"
imgsdir = maindir + "/" + relimgsdir
if not os.path.exists(imgsdir):
    os.makedirs(imgsdir)





def writeDoc(test, name, imageName):
    docmd.write("\n### "+name)
    files = test.getElementsByTagName("file")
    for file in files:
        data = file.firstChild.data
        fileName = file.attributes['name'].value
        docmd.write("\n##### "+fileName+"\n")
        docmd.write("```")
        docmd.write(data)
        docmd.write("```")
    docmd.write("\n![Graph]("+relimgsdir + imageName + " \"Graph\")")




if len(sys.argv) < 2:
    print("Error: Usage: ccpathfixer.py {Path to source folder}")

path = sys.argv[1]

docmd.write("# Tests documentation\n")

#open xml describing test
xmldoc = minidom.parse(sys.argv[1]+"//test.xml")

print("Currenly working on:", path)

parsertest = xmldoc.getElementsByTagName("parsertest")

#export cpps
#export relationship file to be read by c++
testscpp = open(path + "/Tests.cpp", "w")
testscpp.write("#include \"ParserTest.h\"\n\n")

for test in parsertest:
    try:
        graph.clear()
        name = createDirectory(test)
        exportTest(test)
        addTest(name)
        pngName = drawAndExportGraph(graph, name)
        writeDoc(test, name, pngName+"."+form)

        #export compile commands
        filestoadd = glob.glob(dirpath+"/*.cpp")#get cpps in folder
        maindata = []

        for file in filestoadd:
            maindata.append(addccitemforcpp(dirpath, file))

        with open(dirpath+'//compile_commands.json', 'w') as outfile:
            json.dump(maindata, outfile)

    except AssertionError:
        print ("Error: Name is not set for one of the tests!")
    except Exception:
        print (traceback.format_exc() + "Unexpected error in: " + dirpath)

testscpp.close()
