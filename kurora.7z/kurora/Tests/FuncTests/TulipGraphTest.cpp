
#ifdef COMPILE_THIS_DO_NOT
#include "TulipGraphTest.h"
TEST_F(TulipGraphTest, delSubgraphsAndNodesTest) {
  tGraph->delSubgraphsAndNodes("Subgraph");
  EXPECT_EQ(nullptr, tGraph->getGraph()->getSubGraph("Subgraph"));
  EXPECT_EQ(5, tGraph->getGraph()->numberOfNodes());
}
/*
TEST_F(TulipGraphTest, existNodeWithPropertyTest) {
        std::unordered_map<std::string, std::string> prop;
        prop["name"] = "";
        prop["demangled_name"] = "";
        prop["type"] = "Function";
        prop["namespace"] = "";
        prop["scope"] = "";
        prop["path"] = "C:/";
        prop["ln"] = "0";
        prop["col"] = "0";
        prop["defined"] = "1";
        prop["usr"] = "I@F";

        tlp::node n = tGraph->addNode(prop);

        EXPECT_EQ(tGraph->getGraph()->numberOfNodes()-1, n.id);
        EXPECT_EQ(n.id, tGraph->existNodeWithProperty("Path","C:/"));
        EXPECT_EQ(UINT_MAX, tGraph->existNodeWithProperty("Path", "D:/"));
}
*/

TEST_F(TulipGraphTest, EdgeColorTest) {
  std::unordered_map<std::string, std::string> propClass;
  propClass["name"] = "myClass";
  propClass["demangled_name"] = "";
  propClass["type"] = "Class";
  propClass["namespace"] = "std";
  propClass["scope"] = "std";
  propClass["path"] = "C:/";
  propClass["ln"] = "0";
  propClass["col"] = "0";
  propClass["defined"] = "1";
  propClass["usr"] = "I@C";

  std::unordered_map<std::string, std::string> propMethod;
  propMethod["name"] = "";
  propMethod["demangled_name"] = "";
  propMethod["type"] = "Method";
  propMethod["namespace"] = "std";
  propMethod["scope"] = "std::myClass";
  propMethod["path"] = "C:/";
  propMethod["ln"] = "0";
  propMethod["col"] = "0";
  propMethod["defined"] = "1";
  propMethod["usr"] = "I@M";

  unsigned id = tGraph->addEdge(tGraph->addNode(propClass), tGraph->addNode(propMethod));
  tlp::edge e = tlp::edge(id);

  tlp::ColorProperty *color = tGraph->getGraph()->getLocalProperty<tlp::ColorProperty>("viewColor");
  EXPECT_EQ(tlp::Color::Green, color->getEdgeValue(e));
}

#endif