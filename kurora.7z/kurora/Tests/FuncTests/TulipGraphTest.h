#pragma once

#include <gtest/gtest.h>
/*#include <TulipGraph.hpp>

class TulipGraphTest : public testing::Test {
public:
        TulipGraphTest() : graph(tlp::newGraph()) {
                for (int i = 0; i < 10; i++) {
                        graph->addNode();
                }
                tlp::Graph *subg = graph->addSubGraph("Subgraph");
                for (int i = 0; i < 5; i++) {
                        subg->addNode(tlp::node(i));
                }
                tGraph = new TulipGraph(nullptr, std::move(graph));
        }

        ~TulipGraphTest() {
                delete tGraph;
        }

public:
        std::unique_ptr<tlp::Graph> graph;
        TulipGraph *tGraph;
};*/