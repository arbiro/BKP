# Tests documentation

### Implements
##### header.hpp
```
struct A {
    virtual void m();
};
 
struct B:A {
    void m(); // m is virtual because A::m() is virtual
};
```
##### main.cpp
```
#include "header.hpp" 
void A::m() {
}
 
void B::m() {
}
```
![Graph](img/Implements.png "Graph")
### Declares
##### header.hpp
```
struct A {
    void m();
};

void f();
 
```
##### main.cpp
```
#include "header.hpp" 
void A::m() {}
void f() {}
```
![Graph](img/Declares.png "Graph")
### Overrides
##### main.cpp
```
struct A {
  virtual void m(int) = 0;
};

struct B:public A {
  virtual void m(int) = 0;
};
 ```
![Graph](img/Overrides.png "Graph")
### StaticCalls
##### main.cpp
```
struct A {
  int methodA();
};

struct B {
    B(int v);
    int v;
};
B::B(int v):v(v) {
}

int g(const B &b) {
    return b.v;
}

int f(A *a) 
{
   B b(a->methodA());
   return g(b);
}
```
![Graph](img/StaticCalls.png "Graph")
### Statics
##### common_module.hpp
```
#ifndef COMMON_MODULE
#define COMMON_MODULE
extern int g();
#endif
```
##### module1.hpp
```
#ifndef MODULE_1
#define MODULE_1
extern int f1();
#endif
```
##### module2.hpp
```
#ifndef MODULE_2
#define MODULE_2
extern int f2();
#endif
```
##### module1.cpp
```
#include "common_module.hpp"
#include "module1.hpp"
static int hidden() {
  return g();
}

int f1() {
    return hidden();
}
```
##### module2.cpp
```
#include "common_module.hpp"
#include "module2.hpp"
static int hidden() {
  return g();
}

int f2() {
    return hidden();
}
```
##### main.cpp
```
#include "module1.hpp"
#include "module2.hpp"

int f() {
    return f1()+f2();
}
```
![Graph](img/Statics.png "Graph")
### Templates
##### int_overload.hpp
```
#ifndef INT_OVERLOAD
#define INT_OVERLOAD
extern int g(int);
#endif
```
##### double_overload.hpp
```
#ifndef DOUBLE_OVERLOAD
#define DOUBLE_OVERLOAD
double g(double);
#endif
```
##### common_module.hpp
```
#ifndef COMMON_MODULE
#define COMMON_MODULE
#include "int_overload.hpp"
#include "double_overload.hpp"
#endif
```
##### module1.hpp
```
#ifndef MODULE_1
#define MODULE_1
extern int f1(int);
#endif
```
##### module2.hpp
```
#ifndef MODULE_2
#define MODULE_2
extern double f2(double);
#endif
```
##### template_module.hpp
```
#ifndef TEMPLATE_MODULE
#define TEMPLATE_MODULE

#include "common_module.hpp"

template<typename T>
class ClassTemplate {
  T value;
 public:
  explicit ClassTemplate(T v):value(v) {}
  T getValue() const { return value; }
};

template<typename T>
ClassTemplate<T> template_function(ClassTemplate<T> src) {
  return ClassTemplate<T>(g(src.getValue()));
}

#endif
```
##### module1.cpp
```
#include "template_module.hpp"
#include "module1.hpp"

int f1(int value) {
    return template_function(ClassTemplate<int>(value)).getValue();
}
```
##### module2.cpp
```
#include "template_module.hpp"
#include "module2.hpp"

double f2(double value) {
    return template_function(ClassTemplate<double>(value)).getValue();
}
```
##### main.cpp
```
#include "module1.hpp"
#include "module2.hpp"

int f() {
    return f1(1)+f2(1.0);
}
```
![Graph](img/Templates.png "Graph")
### VirtualCalls
##### main.cpp
```
struct A {
  virtual int methodA() = 0;
};

int f(A *a) {
  return a->methodA();
}
```
![Graph](img/VirtualCalls.png "Graph")
### PointerFunction
##### mef.hpp
```
struct A {
  int(*apf)(int);
};

extern int(*vpf)(int);

```
##### main.cpp
```
#include "mef.hpp"



int f(struct A *a) {
  vpf(1);
  return a->apf(2);
}
```
![Graph](img/PointerFunction.png "Graph")
### InlinedMethod
##### A.hpp
```
int g();

struct A {
  int m() {
    return g();
  }

};
```
##### main.cpp
```
#include "A.hpp"

int f(struct A *a) {
  return a->m();
}
```
![Graph](img/InlinedMethod.png "Graph")
### InstantiateTemplate
##### header.hpp
```
template<typename T>
struct AI {
  void mi() {}
};

struct BI {
  template<typename T>
  void mi() {}
};

template<typename T>
void gi() {}


template<typename T>
struct AD {
  void md();
};

struct BD {
  template<typename T>
  void md();
};

template<typename T>
void gd();

```
##### main.cpp
```
#include "header.hpp"

void fi(struct AI<int> *a,struct BI *b) {
  a->mi();
  b->mi<int>();
  gi<int>();
}

void fd(struct AD<int> *a,struct BD *b) {
  a->md();
  b->md<int>();
  gd<int>();
}
```
![Graph](img/InstantiateTemplate.png "Graph")
### Accesses
##### header.hpp
```

struct A {
	int field;
	void cm();
	virtual void vm();
	static void sm();
};

extern int freeVarWithoutDef;
extern int freeVarWithDef;

```
##### main.cpp
```
#include "header.hpp"

int freeVarWithDef;

int f_field(struct A *a) {
	return a->field;
}

void f_class_method(struct A *a) {
	a->cm();
}

void f_virual_method(struct A *a) {
	a->vm();
}

void f_static_method() {
	A::sm();
}

void g(int);

void f_parameter(struct A *a) {
	g(a->field);
}

void f_reference(A &a) {
	g(a.field);
}

void f_direct(A a) {
	g(a.field);
}

int f_freeVarWithDef() {
	return freeVarWithDef;
}

int f_freeVarWithoutDef() {
	return freeVarWithoutDef;
}

```
![Graph](img/Accesses.png "Graph")