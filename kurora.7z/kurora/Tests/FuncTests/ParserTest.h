#ifndef _PARSER_TEST_H
#define _PARSER_TEST_H

#pragma once
#include <gtest/gtest.h>
#include "ParserLib.h"
#include "Database.h"
#include "DependencyDB.h"
#include <QtConcurrent/qtconcurrentrun.h>
#include <QtConcurrent/qtconcurrentmap.h>
#include <QFile>
#include <iostream>
#include <fstream>
#include <tulip/ForEach.h>
#include <stdlib.h>

static int testNumber = 0;

class ParserTest : public testing::Test {
public:
  ParserTest() {}

  ~ParserTest() {}
};

struct RelSymbol {
  RelSymbol() {}
  RelSymbol(std::string symbolString);

  std::string name;
  std::string location;
  std::string type;

  std::string asString() const;

private:
  std::string delimiter = "||";
};

struct Relation {
  RelSymbol source;
  RelSymbol target;
  std::string type;

  std::string asString() const;
};

class RelationReader {
public:
  RelationReader(const std::string &file);
  std::vector<Relation> &getRelationsConst();

private:
  bool readRelation(std::ifstream &input, Relation &relation);
  std::vector<Relation> relations;
};

class RelationTester {
public:
  RelationTester(RelationReader &r, tlp::Graph *g)
      : reader(r),
        graph(g), n_demangled{graph->getLocalProperty<tlp::StringProperty>("demangledName")},
        n_path{graph->getLocalProperty<tlp::StringProperty>("Path")},
        n_type{graph->getLocalProperty<tlp::StringProperty>("Type")},
        n_key{graph->getLocalProperty<tlp::StringProperty>("Key")} {
    if (!testNumber++) {
      remove(EdgeLog);
    }
  }

  void test();
  std::ofstream edgeLogFile;

private:
  std::string printNode(std::string source, const tlp::node &node);
  std::string printEdge(const tlp::edge &edge);
  bool nodeIsLikeSymbol(const tlp::node &node, const RelSymbol &symbol);

  struct EdgeAndMatched {
    EdgeAndMatched(tlp::edge e, bool m) : edge(e), matched(m){};
    tlp::edge edge;
    int matched;
  };
  typedef std::multimap<std::string, EdgeAndMatched> EdgesMap;

  std::string checkRelation(const Relation &relation, EdgesMap &edgesMap);

  tlp::Graph *graph;
  RelationReader &reader;
  std::multimap<std::string, tlp::edge> edgesMap;
  tlp::StringProperty *n_demangled;
  tlp::StringProperty *n_type;
  tlp::StringProperty *n_path;
  tlp::StringProperty *n_key;
};

void RunTestAST(std::string pathTo);
void RunTest(std::string pathTo);
std::string getFileName(const std::string path);

#endif
