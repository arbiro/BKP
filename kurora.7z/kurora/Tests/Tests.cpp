#include "ParserTest.h"

TEST_F(ParserTest, Implements) {
  RunTest("C:/KuroraReady/Tests/samples/Implements");
}

TEST_F(ParserTest, ImplementsAST) {
  RunTestAST("C:/KuroraReady/Tests/samples/Implements");
}

TEST_F(ParserTest, Overrides) {
  RunTest("C:/KuroraReady/Tests/samples/Overrides");
}

TEST_F(ParserTest, OverridesAST) {
  RunTestAST("C:/KuroraReady/Tests/samples/Overrides");
}

TEST_F(ParserTest, StaticCalls) {
  RunTest("C:/KuroraReady/Tests/samples/StaticCalls");
}

TEST_F(ParserTest, StaticCallsAST) {
  RunTestAST("C:/KuroraReady/Tests/samples/StaticCalls");
}

TEST_F(ParserTest, Statics) {
  RunTest("C:/KuroraReady/Tests/samples/Statics");
}

TEST_F(ParserTest, StaticsAST) {
  RunTestAST("C:/KuroraReady/Tests/samples/Statics");
}

TEST_F(ParserTest, Templates) {
  RunTest("C:/KuroraReady/Tests/samples/Templates");
}

TEST_F(ParserTest, TemplatesAST) {
  RunTestAST("C:/KuroraReady/Tests/samples/Templates");
}

TEST_F(ParserTest, VirtualCalls) {
  RunTest("C:/KuroraReady/Tests/samples/VirtualCalls");
}

TEST_F(ParserTest, VirtualCallsAST) {
  RunTestAST("C:/KuroraReady/Tests/samples/VirtualCalls");
}

TEST_F(ParserTest, PointerFunction) {
  RunTest("C:/KuroraReady/Tests/samples/PointerFunction");
}

TEST_F(ParserTest, PointerFunctionAST) {
  RunTestAST("C:/KuroraReady/Tests/samples/PointerFunction");
}

TEST_F(ParserTest, InlinedMethod) {
  RunTest("C:/KuroraReady/Tests/samples/InlinedMethod");
}

TEST_F(ParserTest, InlinedMethodAST) {
  RunTestAST("C:/KuroraReady/Tests/samples/InlinedMethod");
}
