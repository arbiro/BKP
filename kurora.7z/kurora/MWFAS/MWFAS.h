#pragma once

#include <tulip/TulipPluginHeaders.h>

/*
** This plugin computes the MWFAS algorithm.
** It is used to retrieve the min set of arcs to delete, in order to make the
** graph acyclic. Such problem is know as NP-HARD.
**
** The algorithm first sorts all the edges per weight. Then the idea is to
** construct the graph edge by edge (from the heavier to the lighter), only if
** the edge to insert does not introduce a cycle. This method ensures the
** resulting graph to be acyclic and selects the edges that introduce cycles.
**
** To detect cycle the current method is a simple forward DFS.
** Complexity is huge but it is guaranteed to end.
** Other proposed method is based on this paper:
** https://www.cs.princeton.edu/courses/archive/spring13/cos528/topsort-1.pdf
*/

class MWFAS : public tlp::BooleanAlgorithm {
public:
  PLUGININFORMATION("MWFAS", "Murex Team", "17/01/2018", "Select a feedback arc set", "1.0",
                    "Selection");
  MWFAS(tlp::PluginContext *context);

  bool run();
};
