#include <algorithm>
#include <functional>
#include <memory>
#include <random>
#include <vector>

#include <tulip/DoubleProperty.h>

#include "MWFAS.h"

PLUGIN(MWFAS)

using namespace tlp;

static const char *WEIGHT = "Edge weight";
static const char *ITERATIONS = "Iterations";

MWFAS::MWFAS(tlp::PluginContext *context) : BooleanAlgorithm(context) {
  addInParameter<tlp::NumericProperty *>(WEIGHT, "Numeric Property used as edge weight",
                                         "viewMetric");
  addInParameter<int>(ITERATIONS, "Number of iterations", "1");
}

struct Data {
  // initial graph.
  tlp::Graph *graph;
  // the dag to construct.
  tlp::Graph *dag;
  // return result.
  tlp::BooleanProperty *selection;
  // selected edges.
  std::unique_ptr<std::vector<tlp::edge>> selected;
  // minimum of the cost.
  int min = INT_MAX;
  // edges to be inserted.
  std::vector<tlp::edge> heap;
  // weight of edges.
  std::vector<double> weights;

  // stores if a node is already traversed by finding algorithm.
  tlp::NodeStaticProperty<bool> isTraversed;
  // discrete distribution to choose between arcs to insert.
  std::random_device rd;
  int iterations;

  Data(tlp::Graph *g, tlp::BooleanProperty *s, int iterations)
      : graph(g), dag(g->addSubGraph()), selection(s), isTraversed(g), iterations(iterations) {}

  ~Data() {
    graph->delSubGraph(dag);
  }

  bool findPath(tlp::node n1, tlp::node n2) {
    isTraversed.setNodeValue(n1, true);
    if (n1 == n2) {
      return true;
    }
    for (tlp::node n : dag->getOutNodes(n1)) {
      if (!isTraversed.getNodeValue(n))
        if (findPath(n, n2))
          return true;
    }
    return false;
  }

  bool hasPath(tlp::node n1, tlp::node n2) {
    isTraversed.setAll(false);
    return findPath(n1, n2);
  }

  bool addNodeInDag(tlp::node n) {
    if (dag->isElement(n)) {
      return false;
    }
    dag->addNode(n);
    return true;
  }

  bool introducesCycle(tlp::edge e) {
    auto src = graph->source(e);
    auto isAdded = addNodeInDag(src);
    auto trg = graph->target(e);
    isAdded |= addNodeInDag(trg);
    return !isAdded && hasPath(trg, src);
  }

  bool build_result(tlp::DoubleProperty *weight, tlp::PluginProgress *progress) {
    auto ret = iterate(weight, [=](int s, int nb) {
      return progress->progress(s, nb * iterations) == tlp::TLP_CONTINUE;
    });
    if (ret == false)
      return false;

    for (int i = 1; i < iterations; ++i) {
      ret = iterate(weight, [=](int s, int nb) {
        return progress->progress(i * nb + s, nb * iterations) == tlp::TLP_CONTINUE;
      });
      if (ret == false)
        return false;
    }

    // careful if the graph is already acyclic.
    if (selected)
      build_select();
    return true;
  }

  bool iterate(tlp::DoubleProperty *weight, std::function<bool(int, int)> progress) {

    for (auto e : graph->edges()) {
      heap.push_back(e);
      weights.push_back(weight->getEdgeDoubleValue(heap.back()));
    }

    int cost = 0;
    std::vector<tlp::edge> cycle_edges;
    std::mt19937 gen(rd());
    std::discrete_distribution<> distr(weights.begin(), weights.end());
    auto pos = distr(gen);

    auto size = heap.size();
    for (size_t i = 0; i < size; ++i) {

      auto e = heap[pos];
      auto it = std::next(weights.begin(), pos);
      auto it2 = std::next(heap.begin(), pos);
      weights.erase(it);
      heap.erase(it2);
      std::discrete_distribution<> resized_dist(weights.begin(), weights.end());

      if (!progress(i, size))
        return false;

      if (introducesCycle(e)) {
        cycle_edges.push_back(e);
        cost += weights[pos];
      } else {
        dag->addEdge(e);
      }

      pos = resized_dist(gen);
    }
    if (cost < min) {
      selected.reset(new std::vector<tlp::edge>(cycle_edges));
    }
    return true;
  }

  void build_select() {
    for (auto e : *selected)
      selection->setEdgeValue(e, true);
  }
};

bool MWFAS::run() {
  tlp::DoubleProperty *weight = NULL;
  int nbOfIterations = 1;

  if (dataSet != NULL) {
    dataSet->get(WEIGHT, weight);
    dataSet->get(ITERATIONS, nbOfIterations);
  }

  result->setAllNodeValue(false);
  result->setAllEdgeValue(false);

  return Data(graph, result, nbOfIterations).build_result(weight, pluginProgress);
}
