#include <unordered_set>
#include <string>
#include <fstream>
#include <sstream>
#include "ParserOptions.h"
#include "clang/Tooling/Tooling.h"

ParsingOptions setOptions(const std::vector<std::string> &files,
                          const std::string &compilationDBPath, bool parseIncludes,
                          bool inlinesAllTemplateFlag, bool useAST) {
  ParsingOptions options;
  options.m_compilationDBPath = compilationDBPath;
  options.m_inputFiles = files;
  options.inlinesAllTemplateFlag = inlinesAllTemplateFlag;
  options.useAST = useAST;
  options.parseIncludes = parseIncludes;
  return options;
}

std::vector<std::string> getFilesInCompilationDb(std::string &path) {
  std::string error;
  std::unique_ptr<clang::tooling::CompilationDatabase> db =
      clang::tooling::CompilationDatabase::loadFromDirectory(path, error);
  std::unordered_set<std::string> set;
  for (auto command : db->getAllCompileCommands()) {
    set.insert(command.Filename);
  }
  return std::vector<std::string>(set.begin(), set.end());
}

bool getInlinesAllTemplateFlag(const std::string &filePath) {
  try {
    bool flag;
    std::ifstream input;
    input.open(filePath);

    std::string line;
    getline(input, line);
    std::istringstream(line) >> std::boolalpha >> flag;

    return flag;
  } catch (...) {
  }
}