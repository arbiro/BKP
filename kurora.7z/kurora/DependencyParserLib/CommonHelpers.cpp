#include <sstream>

#include "clang/Index/USRGeneration.h"
#include "clang/Frontend/FrontendActions.h"
#include "clang/AST/Type.h"

#include "CommonHelpers.h"

namespace {
const char *handleTranslationUnitError(CXErrorCode error) {
  switch (error) {
  case CXErrorCode::CXError_Crashed:
    return "Libclang crashed";
  case CXErrorCode::CXError_InvalidArguments:
    return "Invalid arguments";
  case CXErrorCode::CXError_ASTReadError:
    return "AST deserialization error";
  case CXErrorCode::CXError_Failure:
    return "Unknown error";
  default:
    return "";
  }
}

std::string getUsr(const clang::Decl *Decl) {
  llvm::SmallVector<char, 128> Buff;

  if (Decl == nullptr || clang::index::generateUSRForDecl(Decl, Buff))
    return "";

  return std::string(Buff.data(), Buff.size());
}

std::string getDemangled(const clang::Decl *decl) {
  std::string result;
  llvm::raw_string_ostream out(result);
  clang::PrintingPolicy policy(decl->getASTContext().getPrintingPolicy());
  decl->print(out, policy);
  std::string declName = out.str();
  std::ostringstream oss;
  if (const clang::FunctionDecl *fdecl = decl->getAsFunction()) {
    size_t paramCount = fdecl->parameters().size();
    if (paramCount > 0) {
      oss << "(";
      for (clang::ParmVarDecl *parameter : fdecl->parameters()) {
        paramCount--;
        oss << parameter->getType().getAsString() << (paramCount > 0 ? "," : ")");
      }
    }
  }
  // return out.str();
  const clang::NamedDecl *named = clang::dyn_cast<clang::NamedDecl>(decl);
  if (named) {
    declName = named->getQualifiedNameAsString() + oss.str();
  }
  return declName;
}

IUSR getIUSR(const clang::Decl *decl, NodeType type) {
  return BatchSymbols::makeIUSR(getUsr(decl), type);
}

std::string toPath(const CXFile &file) {
  CXString cursorSpelling = clang_getFileName(file);
  std::string filepath;
  if (auto str = clang_getCString(cursorSpelling)) {
    filepath = str;
    clang_disposeString(cursorSpelling);
  }
  return filepath;
}

Location getLocation(const clang::Decl *decl) {
  if (const clang::FunctionDecl *FD = clang::dyn_cast<clang::FunctionDecl>(decl)) {
    if (FD->isTemplateInstantiation()) {
      return Location(".", 0, 0);
    }
    if (const clang::CXXMethodDecl *MD = clang::dyn_cast<clang::CXXMethodDecl>(decl)) {
      if (clang::dyn_cast<clang::ClassTemplateSpecializationDecl>(MD->getParent())) {
        return Location(".", 0, 0);
      }
    }
  }
  if (auto fd = clang::dyn_cast<clang::FieldDecl>(decl)) {
    if (clang::dyn_cast<clang::ClassTemplateSpecializationDecl>(fd->getParent())) {
      return Location(".", 0, 0);
    }
  }
  clang::SourceManager &sourceManager = decl->getASTContext().getSourceManager();

  auto location = decl->getLocation();
  if (location.isMacroID()) // if macro id
  {
    location = sourceManager.getFileLoc(location);
  }

  // std::string locationToString = location.printToString(sourceManager); //donotdelete, for easy
  // future debug std::cerr << locationToString;
  const clang::FileEntry *entry =
      sourceManager.getFileEntryForID(sourceManager.getFileID(location));
  if (entry) {
    return Location(entry->getName(), sourceManager.getSpellingLineNumber(location),
                    sourceManager.getSpellingColumnNumber(location));
  } else {
    return Location();
  }
}

NodeType getCalleeType(const clang::Decl *decl) {
  if (const clang::CXXMethodDecl *MD = clang::dyn_cast<clang::CXXMethodDecl>(decl)) {
    if (MD->isVirtual()) {
      return NodeType::VIRTUAL;
    }
  }
  if (auto fd = clang::dyn_cast<clang::FieldDecl>(decl)) {
    return (fd->getType()->isFunctionPointerType()) ? NodeType::POINTER_FUNCTION : NodeType::FIELD;
  }
  if (auto vd = clang::dyn_cast<clang::VarDecl>(decl)) {
    return (vd->getType()->isFunctionPointerType()) ? NodeType::POINTER_FUNCTION
                                                    : NodeType::VARDECL;
  }
  return NodeType::DECLARATION;
}

NodeType getCallerType(const clang::Decl *decl) {
  if (const auto fd = clang::dyn_cast<clang::FunctionDecl>(decl)) {
    if (fd->isThisDeclarationADefinition()) {
      return NodeType::DEFINITION;
    }
  }
  if (const auto vd = clang::dyn_cast<clang::VarDecl>(decl)) {
    if (vd->isThisDeclarationADefinition() == clang::VarDecl::DefinitionKind::Definition) {
      return NodeType::VARDEF;
    }
  }
  return getCalleeType(decl);
}

Symbol &addSymbol(BatchSymbols &batch, const clang::Decl *decl, NodeType type) {
  IUSR iusr = getIUSR(decl, type);
  Symbol &symbol = batch.getSymbol(iusr);
  if (symbol.demangled().empty()) {
    symbol.setDemangled(getDemangled(decl));
  }
  if (symbol.location().path().empty()) {
    symbol.setLocation(getLocation(decl));
  }
  // std::cout << "Add " << iusr << " ("<< symbol.location().offset().ln() << ","<<
  // symbol.location().offset().col() <<")"<<std::endl;
  return symbol;
}

bool includeInGraph(const clang::Decl *decl) {
  // We skip function template definitions, as their semantics is
  // only determined when they are instantiated.
  if (const clang::FunctionDecl *FD = clang::dyn_cast<clang::FunctionDecl>(decl)) {
    if (FD->isDependentContext())
      return false;

    clang::IdentifierInfo *II = FD->getIdentifier();
    if (II && II->getName().startswith("__inline"))
      return false;
  }
  return true;
}
Symbol &getDeclarationSymbol(BatchSymbols &batch, const clang::Decl *D) {
  Symbol &declarationSymbol = addSymbol(batch, D, getCalleeType(D));
  if (const clang::FunctionDecl *FD = clang::dyn_cast<clang::FunctionDecl>(D)) {
    if (FD->isTemplateInstantiation()) {
      auto templatePattern = FD->getTemplateInstantiationPattern();
      Symbol &patternSymbol = addSymbol(batch, templatePattern, NodeType::TEMPLATE);
      declarationSymbol.addLink(patternSymbol, LinkType::INSTANTIATES);
    }
  }
  return declarationSymbol;
}

Symbol &addNodeForDecl(const clang::Decl *decl, BatchSymbols &batch) {
  Symbol &defNode = addSymbol(batch, decl, getCallerType(decl));
  return defNode;
}

} // namespace

Symbol *storeSymbol(BatchSymbols &batch, const clang::Decl *decl) {
  Symbol *currentSymbol = nullptr;
  if (includeInGraph(decl)) {
    currentSymbol = &(addNodeForDecl(decl, batch));
    Symbol *virtualMethod = nullptr;
    if (const clang::CXXMethodDecl *MD = clang::dyn_cast<clang::CXXMethodDecl>(decl)) {
      if (MD->isVirtual()) {
        virtualMethod = &addSymbol(batch, MD, NodeType::VIRTUAL);
        for (auto overMethod : MD->overridden_methods()) {
          virtualMethod->addLink(addSymbol(batch, overMethod, NodeType::VIRTUAL),
                                 LinkType::OVERRIDES);
        }
      }
    }
    if (currentSymbol->isDefinition()) {
      if (virtualMethod) {
        currentSymbol->addLink(*virtualMethod, LinkType::IMPLEMENTS);
      }
      Symbol &calleeSymbol = getDeclarationSymbol(batch, decl);
      calleeSymbol.addLink(*currentSymbol, LinkType::DECLARES);
    }
  }
  return currentSymbol;
}

const clang::Decl *getDeclFromCall(const clang::CallExpr *CE) {
  if (const clang::FunctionDecl *CalleeDecl = CE->getDirectCallee())
    return CalleeDecl;
  if (const clang::Decl *callee = CE->getCalleeDecl())
    return callee;

  // Simple detection of a call through a block.
  const clang::Expr *CEE = CE->getCallee()->IgnoreParenImpCasts();
  if (const clang::BlockExpr *Block = clang::dyn_cast<const clang::BlockExpr>(CEE)) {
    return Block->getBlockDecl();
  }
  return nullptr;
}

void addCall(BatchSymbols &batch, Symbol &caller, const clang::Decl *calleeDecl) {
  if (includeInGraph(calleeDecl)) {
    Symbol &callee = getDeclarationSymbol(batch, calleeDecl);
    caller.addLink(callee, LinkType::CALLS);
  }
}

void addRequest(BatchSymbols &batch, Symbol &caller, const clang::Decl *dataDecl) {
  if (includeInGraph(dataDecl)) {
    Symbol &field = getDeclarationSymbol(batch, dataDecl);
    caller.addLink(field, LinkType::ACCESSES);
  }
}