#include "clang/Basic/Diagnostic.h"
#include <sstream>

class CustomDiagnosticsConsumer : public clang::DiagnosticConsumer {
public:
  CustomDiagnosticsConsumer(std::ostringstream &ss);
  void HandleDiagnostic(clang::DiagnosticsEngine::Level DiagLevel,
                        const clang::Diagnostic &Info) override;

private:
  std::ostringstream &m_stream;
};
