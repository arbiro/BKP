#pragma once
#include <memory>
#include <string>
#include <vector>
#include "DataModel.h"
#include "ParserOptions.h"
#include "ParserLibGlobal.h"

PARSER_LINK std::pair<std::string, BatchSymbols *>
parseFiles(const std::string &file,
           const ParsingOptions &options); // todo REFACTOR, pretty garbagy right now
