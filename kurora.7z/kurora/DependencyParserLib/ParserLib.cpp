#include <fstream>
#include <cassert>
#include <iostream>
#include <iterator>
#include <sstream>

#include "clang/AST/RecursiveASTVisitor.h"
#include "clang/Tooling/CommonOptionsParser.h"
#include "clang/Tooling/Tooling.h"
#include "clang/Tooling/CompilationDatabase.h"
#include "CustomDiagnosticsConsumer.h"
#include "clang/Frontend/CompilerInstance.h"
#include "clang/Lex/Preprocessor.h"

#include "ParserLib.h"
#include "CommonHelpers.h"
#include "DataModel.h"
#include "ILogger.h"

#ifdef _MSC_VER
#define strdup(s) _strdup(s)
#endif

namespace {
class CGBuilder : public clang::StmtVisitor<CGBuilder> {
  BatchSymbols &batch;
  Symbol &caller;

public:
  CGBuilder(BatchSymbols &batch, Symbol &caller) : batch(batch), caller(caller) {}

  void VisitStmt(clang::Stmt *S) {
    VisitChildren(S);
  }

  void VisitCallExpr(clang::CallExpr *CE) {
    if (const clang::Decl *D = getDeclFromCall(CE))
      addCall(batch, caller, D);
    VisitChildren(CE);
  }

  void VisitCXXConstructExpr(clang::CXXConstructExpr *constructorExpr) {
    addCall(batch, caller, constructorExpr->getConstructor());
    VisitChildren(constructorExpr);
  }

  void VisitMemberExpr(clang::MemberExpr *memberExpr) {
    addRequest(batch, caller, memberExpr->getMemberDecl());
    VisitChildren(memberExpr);
  }

  void VisitDeclRefExpr(clang::DeclRefExpr *declRefExpr) {
    auto decl = declRefExpr->getDecl();
    if (decl->hasExternalFormalLinkage() &&
        (clang::dyn_cast<clang::VarDecl>(decl) || clang::dyn_cast<clang::FieldDecl>(decl))) {
      addRequest(batch, caller, decl);
    }
    VisitChildren(declRefExpr);
  }

  void VisitChildren(clang::Stmt *S) {
    for (clang::Stmt *SubStmt : S->children())
      if (SubStmt)
        this->Visit(SubStmt);
  }
};

class FindCallVisitor : public clang::RecursiveASTVisitor<FindCallVisitor> {
public:
  explicit FindCallVisitor(BatchSymbols &batch) : batch(batch) {}
  /// Part of recursive declaration visitation. We recursively visit all the
  /// declarations to collect the root functions.
  bool VisitFunctionDecl(clang::FunctionDecl *FD) {
    Symbol *currentSymbol = storeSymbol(batch, FD);
    if (currentSymbol && currentSymbol->isDefinition()) {
      if (clang::Stmt *body = FD->getBody()) {
        CGBuilder(batch, *currentSymbol).Visit(body);
      }
    }
    return true;
  }

  bool VisitVarDecl(clang::VarDecl *varDecl) {
    if (varDecl->hasExternalFormalLinkage()) {
      storeSymbol(batch, varDecl);
    }
    return true;
  }

  /// Part of recursive declaration visitation.

  // We are only collecting the declarations, so do not step into the bodies.
  bool TraverseStmt(clang::Stmt *S) {
    return true;
  }

  bool shouldWalkTypesOfTypeLocs() const {
    return false;
  }

  bool shouldVisitTemplateInstantiations() const {
    return true;
  }

private:
  BatchSymbols &batch;
};

class IncludeFinder : public clang::PPCallbacks {
public:
  explicit IncludeFinder(const clang::CompilerInstance &compiler, BatchSymbols::InclusionMap &data)
      : compiler(compiler), _data(data) {
    auto mainID = compiler.getSourceManager().getMainFileID();

    mainFile = compiler.getSourceManager().getFileEntryForID(mainID)->getName().str();
    _data[mainFile] = InclusionInfo();
  }

  clang::PPCallbacks *createPreprocessorCallbacks() {
    return this;
  }

  virtual void InclusionDirective(clang::SourceLocation hashLoc, const clang::Token &includeTok,
                                  clang::StringRef fileName, bool isAngled,
                                  clang::CharSourceRange filenameRange,
                                  const clang::FileEntry *file, clang::StringRef searchPath,
                                  clang::StringRef relativePath,
                                  const clang::Module *imported) override {

    auto &sourceManager = compiler.getSourceManager();
    std::string currentFile = sourceManager.getFilename(hashLoc);

    unsigned int lineNumber = sourceManager.getSpellingLineNumber(hashLoc);

    lastKey = searchPath.str() + "/" + relativePath.str();
    _data[currentFile].includeDirectives.push_back(std::make_pair(lastKey, lineNumber));
    //_data[lastKey] = InclusionInfo();
    if (currentFile != mainFile) {
      for (auto &headerPrefix : compiler.getHeaderSearchOpts().UserEntries) {
        _data[currentFile].headerSearchEntries.push_back(headerPrefix.Path);
      }
    }
  }

private:
  std::string mainFile;
  std::string lastKey;
  BatchSymbols::InclusionMap &_data;
  const clang::CompilerInstance &compiler;
};

class FindCallConsumer : public clang::ASTConsumer {
public:
  explicit FindCallConsumer(BatchSymbols &batch) : visitor(batch) {}

  virtual void HandleTranslationUnit(clang::ASTContext &Context) {
    visitor.TraverseDecl(Context.getTranslationUnitDecl());
  }

private:
  FindCallVisitor visitor;
};

class CreateModelAction : public clang::ASTFrontendAction {
public:
  CreateModelAction(BatchSymbols &batch) : batch(batch) {}

  virtual std::unique_ptr<clang::ASTConsumer> CreateASTConsumer(clang::CompilerInstance &Compiler,
                                                                llvm::StringRef InFile) {

    return std::unique_ptr<clang::ASTConsumer>(new FindCallConsumer(batch));
  }

protected:
  BatchSymbols &batch;
};

class CreateModelActionWithIncludes : public CreateModelAction {
public:
  CreateModelActionWithIncludes(BatchSymbols &batch) : CreateModelAction(batch) {}

  void ExecuteAction() override {
    BatchSymbols::InclusionMap data;

    clang::CompilerInstance &compiler = getCompilerInstance();
    auto mainID = compiler.getSourceManager().getMainFileID();

    std::string mainFile = compiler.getSourceManager().getFileEntryForID(mainID)->getName().str();
    compiler.getPreprocessor().addPPCallbacks(
        std::unique_ptr<IncludeFinder>(new IncludeFinder(compiler, data)));
    for (auto &headerPrefix : compiler.getHeaderSearchOpts().UserEntries) {
      data[mainFile].headerSearchEntries.push_back(headerPrefix.Path);
    }

    clang::ASTFrontendAction::ExecuteAction();

    batch.addInclusion(data);
  }
};

class ModelFrontendActionFactory : public clang::tooling::FrontendActionFactory {
  BatchSymbols &batch;

public:
  ModelFrontendActionFactory(BatchSymbols &batch, const ParsingOptions &options)
      : batch(batch), options(options) {}
  clang::FrontendAction *create() override {

    return options.parseIncludes ? new CreateModelActionWithIncludes(batch)
                                 : new CreateModelAction(batch);
  }

  const ParsingOptions &options;
};

} // namespace

std::pair<std::string, BatchSymbols *> parseFiles(const std::string &file,
                                                  const ParsingOptions &options) {

  // std::cout << "Parse compilation database" << std::endl;
  std::string error;
  std::unique_ptr<clang::tooling::CompilationDatabase> db =
      clang::tooling::CompilationDatabase::loadFromDirectory(options.m_compilationDBPath, error);
  if (!error.empty()) {
    std::cerr << error << std::endl;
  }
  std::vector<std::string> sources;
  sources.push_back(file);
  clang::tooling::ClangTool tool(*db, sources);
  tool.appendArgumentsAdjuster(clang::tooling::getInsertArgumentAdjuster("-std=c++11"));

  // Qt does not support unique_ptr in map/reduce
  BatchSymbols *result = nullptr;
  try {
    result = new BatchSymbols();
    // std::cout << "Parse translation unit of " << file << std::endl;

    ModelFrontendActionFactory factory(*result, options);

    std::ostringstream diagnosticsStreamString;
    CustomDiagnosticsConsumer consumer(diagnosticsStreamString);
    tool.setDiagnosticConsumer(&consumer);

    tool.run(&factory);

    std::string diagString = diagnosticsStreamString.str();

    INFOLOG << "Parsed translation unit of " + file;
    if (diagString.size())
      ERRLOG << diagnosticsStreamString.str();

    if (options.inlinesAllTemplateFlag)
      result->pushUpDependencies();
  } catch (const std::exception &e) {
    std::cerr << e.what() << std::endl;
  }

  return std::make_pair(file, result);
}
