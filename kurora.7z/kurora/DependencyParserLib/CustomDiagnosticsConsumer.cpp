#include <sstream>

#include "CustomDiagnosticsConsumer.h"
#include "llvm/ADT/SmallString.h"

const char *GetLevelAsString(clang::DiagnosticsEngine::Level &DiagLevel) {

  switch (DiagLevel) {
  case clang::DiagnosticsEngine::Error:
  case clang::DiagnosticsEngine::Fatal:
    return "Error: ";
    break;
  case clang::DiagnosticsEngine::Warning:
    return "Warning: ";
    break;
  default:
    return "Unknown: ";
    break;
  }
}

CustomDiagnosticsConsumer::CustomDiagnosticsConsumer(std::ostringstream &ss) : m_stream(ss) {}
void CustomDiagnosticsConsumer::HandleDiagnostic(clang::DiagnosticsEngine::Level DiagLevel,
                                                 const clang::Diagnostic &Info) {
  llvm::SmallString<1024> message;
  llvm::SmallString<256> messageLoc;
  clang::SourceManager *Sources = nullptr;
  if (Info.hasSourceManager()) {
    Sources = &Info.getSourceManager();
    messageLoc = Info.getLocation().printToString(*Sources) + " ";
  } else {
    messageLoc += "Could not find location";
  }
  Info.FormatDiagnostic(message);
  m_stream << '\n' << GetLevelAsString(DiagLevel) << messageLoc.c_str() << message.c_str();
}
