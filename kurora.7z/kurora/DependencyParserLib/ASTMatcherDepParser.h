#pragma once
#include <memory>
#include <string>
#include <vector>
#include <utility>
#include "ParserLibGlobal.h"
#include "ParserOptions.h"

class BatchSymbols;

PARSER_LINK std::pair<std::string, BatchSymbols *> parseFilesAST(const std::string &file,
                                                                 const ParsingOptions &options);
