#pragma once

#include <clang/AST/AST.h>

#include "ParserLibGlobal.h"
#include "DataModel.h"

Symbol *storeSymbol(BatchSymbols &batchSymbols, const clang::Decl *FD);
const clang::Decl *getDeclFromCall(const clang::CallExpr *CE);
void addCall(BatchSymbols &batch, Symbol &caller, const clang::Decl *calleeDecl);
void addRequest(BatchSymbols &batch, Symbol &caller, const clang::Decl *dataDecl);