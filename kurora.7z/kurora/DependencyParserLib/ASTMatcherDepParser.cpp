#include <string>
#include <fstream>
#include <cassert>
#include <iostream>
#include <iterator>
#include <sstream>
#include "clang/AST/AST.h"
#include "clang/AST/ASTConsumer.h"
#include "clang/AST/ASTContext.h"
#include "clang/AST/RecursiveASTVisitor.h"
#include "clang/Index/USRGeneration.h"
#include "clang/Driver/Options.h"
#include "clang/Frontend/ASTConsumers.h"
#include "clang/Frontend/FrontendActions.h"
#include "clang/Rewrite/Core/Rewriter.h"
#include "clang/Tooling/CommonOptionsParser.h"
#include "clang/Tooling/Tooling.h"
#include "clang/Tooling/CompilationDatabase.h"
#include "clang/ASTMatchers/ASTMatchFinder.h"
#include "clang/ASTMatchers/ASTMatchers.h"
#include "clang/Frontend/FrontendActions.h"
#include "CommonHelpers.h"
#include "CustomDiagnosticsConsumer.h"
#include "ILogger.h"

using namespace clang::ast_matchers;
using namespace clang;
using namespace clang::tooling;
using namespace clang;
using namespace llvm;

#include "ASTMatcherDepParser.h"
#include "DataModel.h"
#include "ParserOptions.h"

class MyPrinter : public MatchFinder::MatchCallback {
public:
  MyPrinter(BatchSymbols &batch)
      : m_batch(batch),
        m_bindsToFunctionsMap{
            {"functionDecl", std::bind(&MyPrinter::handleFunction, this, std::placeholders::_1)},
            {"call", std::bind(&MyPrinter::handleCall, this, std::placeholders::_1)},
            {"constructionCall",
             std::bind(&MyPrinter::handleConstrExpr, this, std::placeholders::_1)},
            {"memberExpr", std::bind(&MyPrinter::handleMembrExpr, this, std::placeholders::_1)},
            {"declRefExpr", std::bind(&MyPrinter::handleDeclRefExpr, this, std::placeholders::_1)},
            {"varDecl", std::bind(&MyPrinter::handleVarDecl, this, std::placeholders::_1)}

        } {}
  virtual void run(const MatchFinder::MatchResult &Result) {
    ASTContext *Context = Result.Context;

    auto &nodesMap = Result.Nodes.getMap();
    for (auto &node : nodesMap) {
      auto &func = m_bindsToFunctionsMap[node.first];
      func(node.second);
    }
  }

private:
  void handleFunction(const ast_type_traits::DynTypedNode &node) {
    // std::cout << "NodeKind " << node.getNodeKind().asStringRef().str() << "\n";

    if (const FunctionDecl *E = node.get<clang::FunctionDecl>()) {
      if (!E->isDefaulted()) {
        Symbol *stored = storeSymbol(m_batch, E);
        m_lastDefinitionSym = (stored && stored->isDefinition()) ? stored : m_lastDefinitionSym;
      }
    } else {
      // TODO add log
    }
  }

  void handleCall(const ast_type_traits::DynTypedNode &node) {
    if (const CallExpr *E = node.get<clang::CallExpr>()) {
      if (m_lastDefinitionSym) {
        if (const clang::Decl *D = getDeclFromCall(E))
          addCall(m_batch, *m_lastDefinitionSym, D);
      } else {
        /// add logg
      }
    }
  }

  void handleConstrExpr(const ast_type_traits::DynTypedNode &node) {
    if (const CXXConstructExpr *E = node.get<clang::CXXConstructExpr>()) {
      if (m_lastDefinitionSym) {
        if (const clang::Decl *D = E->getConstructor())
          addCall(m_batch, *m_lastDefinitionSym, D);
        else {
          // addd logg
        }
      } else {
        /// add logg
      }
    }
  }

  void handleMembrExpr(const ast_type_traits::DynTypedNode &node) {
    if (const MemberExpr *E = node.get<clang::MemberExpr>()) {
      if (m_lastDefinitionSym != nullptr) {
        addRequest(m_batch, *m_lastDefinitionSym, E->getMemberDecl());
      }
    }
  }

  void handleDeclRefExpr(const ast_type_traits::DynTypedNode &node) {
    if (const DeclRefExpr *E = node.get<clang::DeclRefExpr>()) {
      if (m_lastDefinitionSym != nullptr) {
        auto decl = E->getDecl();
        if (decl->hasExternalFormalLinkage() &&
            (clang::dyn_cast<clang::VarDecl>(decl) || clang::dyn_cast<clang::FieldDecl>(decl))) {
          addRequest(m_batch, *m_lastDefinitionSym, decl);
        }
      }
    }
  }

  void handleVarDecl(const ast_type_traits::DynTypedNode &node) {
    if (const VarDecl *E = node.get<clang::VarDecl>()) {
      if (E->hasExternalFormalLinkage()) {
        storeSymbol(m_batch, E);
      }
    }
  }

  std::unordered_map<std::string, std::function<void(const ast_type_traits::DynTypedNode &)>>
      m_bindsToFunctionsMap;
  Symbol *m_lastDefinitionSym = nullptr;
  BatchSymbols &m_batch;
};

std::pair<std::string, BatchSymbols *> parseFilesAST(const std::string &file,
                                                     const ParsingOptions &options) {

  // std::cout << "Parse compilation database" << std::endl;
  std::string error;
  std::unique_ptr<clang::tooling::CompilationDatabase> db =
      clang::tooling::CompilationDatabase::loadFromDirectory(options.m_compilationDBPath, error);
  if (!error.empty()) {
    std::cerr << error << std::endl;
  }
  std::vector<std::string> sources;
  sources.push_back(file);
  clang::tooling::ClangTool tool(*db, sources);
  tool.appendArgumentsAdjuster(clang::tooling::getInsertArgumentAdjuster("-std=c++11"));

  // Qt does not support unique_ptr in map/reduce
  BatchSymbols *result = nullptr;
  try {
    result = new BatchSymbols();

    MyPrinter printer(*result);
    MatchFinder finder;
    DeclarationMatcher funcDeclMatcher = functionDecl().bind("functionDecl");
    DeclarationMatcher varDeclMatcher = varDecl().bind("varDecl");

    StatementMatcher callMatcher = callExpr().bind("call");
    StatementMatcher constrMatcher = cxxConstructExpr().bind("constructionCall");
    StatementMatcher membrMatcher = memberExpr().bind("memberExpr");
    StatementMatcher declRefMatcher = declRefExpr().bind("declRefExpr");

    finder.addMatcher(funcDeclMatcher, &printer);
    finder.addMatcher(callMatcher, &printer);
    finder.addMatcher(constrMatcher, &printer);
    finder.addMatcher(membrMatcher, &printer);
    finder.addMatcher(declRefMatcher, &printer);
    finder.addMatcher(varDeclMatcher, &printer);

    std::ostringstream diagnosticsStreamString;
    CustomDiagnosticsConsumer consumer(diagnosticsStreamString);
    tool.setDiagnosticConsumer(&consumer);

    tool.run(newFrontendActionFactory(&finder).get());

    std::string diagString = diagnosticsStreamString.str();
    INFOLOG << "Parsed translation unit of " + file;
    if (diagString.size())
      ERRLOG << diagnosticsStreamString.str();

    if (options.inlinesAllTemplateFlag)
      result->pushUpDependencies();
  } catch (const std::exception &e) {
    std::cerr << e.what() << std::endl;
  }

  return std::make_pair(file, result);
}
