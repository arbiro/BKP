#pragma once

#include <memory>
#include <string>
#include <vector>
#include <mutex>

#include "ParserLibGlobal.h"

struct PARSER_LINK ParsingOptions {
  ParsingOptions() = default;
  std::string m_compilationDBPath;
  std::vector<std::string> m_inputFiles;

  bool useAST;
  bool inlinesAllTemplateFlag;
  bool parseIncludes;
};

PARSER_LINK ParsingOptions setOptions(const std::vector<std::string> &files,
                                      const std::string &compilationDBPath,
                                      bool parseIncludes = true, bool inlinesAllTemplateFlag = true,
                                      bool useAST = false);
PARSER_LINK std::vector<std::string> getFilesInCompilationDb(std::string &path);
PARSER_LINK bool getInlinesAllTemplateFlag(const std::string &path);
