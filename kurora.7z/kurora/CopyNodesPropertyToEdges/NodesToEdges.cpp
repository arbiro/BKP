#include <memory>
#include <algorithm>
#include <string>
#include <cctype>
#include <fstream>
#include <tulip/StringCollection.h>
#include <tulip/GraphProperty.h>
#include <tulip/ForEach.h>
#include <tulip/Graph.h>
#include <tulip/StringProperty.h>
#include <cstdio>
#include "NodesToEdges.h"

PLUGIN(NodesToEdges)

using namespace std;
using namespace tlp;

const char *PROPERTY = "String property";
const char *selNodes = "selectnodes";
const char *selEdges = "selectedges";
const char *TARGET_TYPE = "Node";
const char *TARGET_TYPES = "source;target";
#define NODE_SOURCE 0
#define NODE_TARGET 1

NodesToEdges::NodesToEdges(tlp::PluginContext *context) : Algorithm(context) {
  addInParameter<StringProperty>(PROPERTY, "Property", "");
  addInParameter<StringCollection>(TARGET_TYPE, "Which node to get the property from", TARGET_TYPES,
                                   true, "source <br> target");
}

bool NodesToEdges::run() {

  StringProperty *prop = nullptr;
  StringCollection targetType;
  targetType.setCurrent(NODE_SOURCE);
  if (dataSet != nullptr) {
    dataSet->get(PROPERTY, prop);
    dataSet->get(TARGET_TYPE, targetType);
  }

  if (prop == nullptr) {
    if (pluginProgress)
      pluginProgress->setError("Error: A property must be selected");

    return false;
  }

  for (tlp::edge e : graph->edges()) {
    std::string val = prop->getNodeValue(targetType.getCurrent() == NODE_SOURCE ? graph->source(e)
                                                                                : graph->target(e));
    prop->setEdgeValue(e, val);
  }

  return true;
}
