#pragma once

/* MSVC DLL import/export. */
#ifdef _MSC_VER
#pragma warning(disable : 4297)
#ifdef CNPTE_LIB
#define CNPTE_LINK __declspec(dllexport)
#else
#define CNPTE_LINK __declspec(dllimport)
#endif
#else
#define CNPTE_LINK
#endif
