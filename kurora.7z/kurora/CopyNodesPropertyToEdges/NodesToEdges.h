#pragma once

#include <tulip/TulipPluginHeaders.h>
#include <tulip/NumericProperty.h>
#include <tulip/TulipViewSettings.h>
#include "NodesToEdgesGlobal.h"

class NodesToEdges : public tlp::Algorithm {
public:
  PLUGININFORMATION("Copy Nodes Property To Edges", "Murex Team", "29/01/2018",
                    "Selects nodes with property of selected file specified values ", "1.0", "Misc")
  NodesToEdges(tlp::PluginContext *context);
  bool run() override;
};
