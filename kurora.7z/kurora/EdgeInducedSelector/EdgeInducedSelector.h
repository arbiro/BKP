#pragma once

#include <tulip/TulipPluginHeaders.h>
#include <tulip/NumericProperty.h>
#include <tulip/TulipViewSettings.h>
#include "EdgeInducedSelectorGlobal.h"

class EdgeInducedSelector : public tlp::BooleanAlgorithm {
public:
  PLUGININFORMATION("Edge induced selector", "Murex Team", "19/03/2018",
                    "Selects extremities of all selected edges ", "1.0", "Misc")
  EdgeInducedSelector(tlp::PluginContext *context);
  bool run() override;
};
