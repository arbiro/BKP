#pragma once

/* MSVC DLL import/export. */
#ifdef _MSC_VER
#pragma warning(disable : 4297)
#ifdef EIS_LIB
#define EIS_LINK __declspec(dllexport)
#else
#define EIS_LINK __declspec(dllimport)
#endif
#else
#define EIS_LINK
#endif
