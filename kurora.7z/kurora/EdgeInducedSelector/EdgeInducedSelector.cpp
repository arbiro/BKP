#include <memory>
#include <algorithm>
#include <string>
#include <cctype>
#include <fstream>
#include <tulip/StringCollection.h>
#include <tulip/GraphProperty.h>
#include <tulip/ForEach.h>
#include <tulip/Graph.h>
#include <tulip/StringProperty.h>
#include <cstdio>
#include "EdgeInducedSelector.h"

PLUGIN(EdgeInducedSelector)

using namespace std;
using namespace tlp;

EdgeInducedSelector::EdgeInducedSelector(tlp::PluginContext *context) : BooleanAlgorithm(context) {
  addInParameter<BooleanProperty>(
      "Selection", "Set of edges for which the extremity nodes are selected", "viewSelection");
  addInParameter<bool>("Keep Edges selected", "Keep edges in selection or not", "true");
}

bool EdgeInducedSelector::run() {

  BooleanProperty *entrySelection = nullptr;
  bool keepEdges = true;

  if (dataSet != nullptr) {
    dataSet->get("Selection", entrySelection);
    dataSet->get("Keep Edges selected", keepEdges);
  } else {
    pluginProgress->setError("Could not get inputs");
    return false;
  }

  std::unique_ptr<Iterator<edge>> itE(entrySelection->getEdgesEqualTo(true));

  std::vector<edge> edges;
  for (const edge &e : *itE) {
    edges.push_back(e);
  }

  for (const edge &e : edges) {
    result->setNodeValue(graph->source(e), true);
    result->setNodeValue(graph->target(e), true);
    if (keepEdges) {
      result->setEdgeValue(e, true);
    }
  }

  return true;
}