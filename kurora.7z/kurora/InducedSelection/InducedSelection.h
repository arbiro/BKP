#pragma once

#include <tulip/TulipPluginHeaders.h>

class InducedSelection : public tlp::Algorithm {
public:
  PLUGININFORMATION(
      "Induced Selection", "Murex Team", "01/03/2017",
      "Select the induced elements in the origin graph from a selection in the quotient graph",
      "1.0", "Quotient Graph")
  InducedSelection(tlp::PluginContext *context);

  bool run();
};
