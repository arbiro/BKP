#include <memory>
#include <functional>

#include <tulip/Plugin.h>
#include <tulip/BooleanProperty.h>

#include "InducedSelection.h"

PLUGIN(InducedSelection)

namespace {
static const char *QUOTIENT_SELECTION = "quotient selection";
static const char *QUOTIENT_PROPERTY = "quotient property";

struct Algo {
  Algo(const tlp::DataSet &dataSet, tlp::Graph *graph);
  void run();

  tlp::Graph *quotient;
  tlp::BooleanProperty *quotientSelection;
  tlp::PropertyInterface *quotientProperty;

  tlp::Graph *origin;
  tlp::BooleanProperty *originSelection;
  tlp::PropertyInterface *originProperty;
};

Algo::Algo(const tlp::DataSet &dataSet, tlp::Graph *graph) : quotient(graph) {
  dataSet.get(QUOTIENT_SELECTION, quotientSelection);
  dataSet.get(QUOTIENT_PROPERTY, quotientProperty);

  unsigned int originId = 0;
  if (!graph->getAttribute("originGraphId", originId)) {
    throw std::runtime_error("The graph must be a quotient graph.");
  }

  origin = graph->getRoot()->getSubGraph(originId);
  if (!origin) {
    throw std::runtime_error("The origin graph " + std::to_string(originId) + " cannot be found");
  }

  originSelection = origin->getLocalProperty<tlp::BooleanProperty>(quotientSelection->getName());
  if (!origin) {
    throw std::runtime_error("Cannot get property " + quotientSelection->getName() +
                             " in the origin graph");
  }
  originProperty = origin->getProperty(quotientProperty->getName());
  if (!originProperty) {
    throw std::runtime_error("Cannot get property " + quotientProperty->getName() +
                             " in the origin graph");
  }
}

void Algo::run() {
  std::unordered_map<std::string, tlp::node> nodePerValue(quotient->numberOfNodes());
  for (tlp::node n : quotient->nodes()) {
    nodePerValue.insert({quotientProperty->getNodeStringValue(n), n});
  }

  originSelection->setAllNodeValue(false);
  for (tlp::node n : origin->nodes()) {
    auto found = nodePerValue.find(originProperty->getNodeStringValue(n));
    if (found != nodePerValue.end() && quotientSelection->getNodeValue(found->second)) {
      originSelection->setNodeValue(n, true);
    }
  }

  originSelection->setAllEdgeValue(false);
  for (tlp::edge e : origin->edges()) {
    auto foundSrc = nodePerValue.find(originProperty->getNodeStringValue(origin->source(e)));
    if (foundSrc == nodePerValue.end())
      continue;
    auto foundTrg = nodePerValue.find(originProperty->getNodeStringValue(origin->target(e)));
    if (foundTrg == nodePerValue.end())
      continue;
    tlp::edge foundEdge = quotient->existEdge(foundSrc->second, foundTrg->second);
    if (foundEdge.isValid() && quotientSelection->getEdgeValue(foundEdge)) {
      originSelection->setEdgeValue(e, true);
    }
  }
}

} // namespace
InducedSelection::InducedSelection(tlp::PluginContext *context) : Algorithm(context) {
  addInParameter<tlp::BooleanProperty>(QUOTIENT_SELECTION, "Input selection", "viewSelection");
  addInParameter<tlp::PropertyInterface *>(QUOTIENT_PROPERTY, "Quotient property", "");
}

bool InducedSelection::run() {
  if (dataSet == nullptr)
    return false;
  try {
    Algo(*dataSet, graph).run();
  } catch (std::exception &e) {
    pluginProgress->setError(e.what());
    return false;
  }
  return true;
}
