#pragma once

#include <tulip/TulipPluginHeaders.h>
#include <tulip/NumericProperty.h>

class TruncPath : public tlp::Algorithm {
public:
  PLUGININFORMATION("Trunc Path", "Murex Team", "28/06/2017", "Trunc a file path property.", "1.0",
                    "Misc")
  TruncPath(tlp::PluginContext *context);

  bool run();
};
