#include <memory>
#include <algorithm>
#include <string>
#include <cctype>
#include <fstream>
#include <tulip/StringCollection.h>
#include <tulip/GraphProperty.h>
#include <tulip/ForEach.h>
#include <tulip/Graph.h>

#include "TruncPath.h"

PLUGIN(TruncPath)

namespace {
size_t findNthOccurence(const std::string &path, int occ) {
  size_t pos = 0;
  for (int i = 0; i < occ; ++i) {
    pos = path.find("/", pos);
    if (pos == std::string::npos) {
      return pos;
    }
    ++pos;
  }
  return pos;
}

size_t findNthOccurenceFromEnd(const std::string &path, int occ) {
  size_t pos = std::string::npos;
  for (int i = 0; i < occ; ++i) {
    if (pos != std::string::npos) {
      --pos;
    }
    pos = path.rfind("/", pos);
    if (pos == std::string::npos) {
      return 0;
    }
  }
  return pos;
}

static const char *EMPTY_STR = ".";

struct Transformer {
  int removeDepth;
  int truncDepth;
  Transformer(int removeDepth, int truncDepth) : removeDepth(removeDepth), truncDepth(truncDepth) {}
  std::string operator()(const std::string &value) const {
    std::string result = getTruncPath(value, removeDepth, truncDepth);
    return result.empty() ? EMPTY_STR : result;
  }
  static std::string removePath(const std::string &path, int removeDepth) {
    if (removeDepth > 0) {
      size_t removePos = findNthOccurence(path, removeDepth);
      if (removePos >= path.size())
        return "";
      return path.substr(removePos);
    } else if (removeDepth < 0) {
      size_t removePos = findNthOccurenceFromEnd(path, -removeDepth);
      return path.substr(0, removePos);
    }
    return path;
  }
  static std::string getTruncPath(const std::string &path, int removeDepth, int truncDepth) {
    std::string result = removePath(path, removeDepth);
    size_t truncPos = findNthOccurence(result, truncDepth);
    return result.substr(0, truncPos == 0 ? (std::string::npos) : truncPos);
  }
};

static const char *INPUT_PATH = "inputPath";
static const char *OUTPUT_PATH = "outputPath";
static const char *TARGET_TYPE = "target";
static const char *REMOVE_DEPTH = "removeDepth";
static const char *KEEP_DEPTH = "keepDepth";
static const char *TARGET_TYPES = "nodes;edges;both";

static const int NODES_TARGET = 0;
static const int EDGES_TARGET = 1;
static const int BOTH_TARGET = 2;

struct Parameters {
  tlp::PropertyInterface *input;
  tlp::PropertyInterface *output;
  bool withNodes;
  bool withEdges;
  std::unique_ptr<Transformer> mapFunction;

private:
  static std::unique_ptr<Transformer> getTransformer(const tlp::DataSet &data) {
    int removeDepth = 0;
    data.get(REMOVE_DEPTH, removeDepth);
    int truncDepth = 0;
    data.get(KEEP_DEPTH, truncDepth);
    return std::unique_ptr<Transformer>(new Transformer(removeDepth, truncDepth));
  }

public:
  Parameters(tlp::Graph &graph, const tlp::DataSet &dataSet)
      : input(nullptr), output(nullptr), withNodes(false), withEdges(false),
        mapFunction(getTransformer(dataSet)) {
    dataSet.get(INPUT_PATH, input);
    dataSet.get(OUTPUT_PATH, output);
    if (!graph.existLocalProperty(output->getName())) {
      output = graph.getLocalProperty(output->getName(), output->getTypename());
    }
    tlp::StringCollection targetType;
    dataSet.get(TARGET_TYPE, targetType);
    withNodes = targetType.getCurrent() == NODES_TARGET || targetType.getCurrent() == BOTH_TARGET;
    withEdges = targetType.getCurrent() == EDGES_TARGET || targetType.getCurrent() == BOTH_TARGET;
  }
  bool isValid() const {
    return input && output && mapFunction;
  }

  static void doRegistering(tlp::Algorithm &algo) {
    algo.addInParameter<tlp::PropertyInterface *>(INPUT_PATH, "Input Path", "Path");
    algo.addInParameter<tlp::PropertyInterface *>(OUTPUT_PATH, "Output Path", "Path");
    algo.addInParameter<tlp::StringCollection>(
        TARGET_TYPE,
        "Whether the algorithm is applyed only for nodes, only for edges, or for both.",
        TARGET_TYPES, true, "nodes <br> edges <br> both");
    algo.addInParameter<int>(REMOVE_DEPTH,
                             "Level of path to remove (for example level 2 of "
                             "\"C:/Users/Public/Directory\" is \"Public/Directory\")",
                             "2");
    algo.addInParameter<int>(
        KEEP_DEPTH,
        "Level of path to keep (for example level 1 of \"Public/Directory\" is \"Public\")", "0");
  }
};
} // namespace

TruncPath::TruncPath(tlp::PluginContext *context) : Algorithm(context) {
  Parameters::doRegistering(*this);
}

bool TruncPath::run() {
  if (dataSet == nullptr)
    return false;
  Parameters param(*graph, *dataSet);
  if (!param.isValid())
    return false;

  int step = 0;
  int maxSteps = (param.withNodes ? graph->numberOfNodes() : 0) +
                 (param.withEdges ? graph->numberOfEdges() : 0);

  if (param.withNodes) {
    tlp::node n;
    forEach (n, graph->getNodes()) {
      const std::string &value = (*param.mapFunction)(param.input->getNodeStringValue(n));
      param.output->setNodeStringValue(n, value);

      auto state = pluginProgress->progress(step++, maxSteps);
      if (state != tlp::TLP_CONTINUE)
        return state != tlp::TLP_CANCEL;
    }
  }
  if (param.withEdges) {
    tlp::edge e;
    forEach (e, graph->getEdges()) {
      const std::string &value = (*param.mapFunction)(param.input->getEdgeStringValue(e));
      param.output->setEdgeStringValue(e, value);
      auto state = pluginProgress->progress(step++, maxSteps);
      if (state != tlp::TLP_CONTINUE)
        return state != tlp::TLP_CANCEL;
    }
  }
  return true;
}
