#pragma once

/* MSVC DLL import/export. */
#ifdef _MSC_VER
#pragma warning(disable : 4297)
#ifdef DATA_MODEL_LIB
#define DATA_MODEL_LINK __declspec(dllexport)
#else
#define DATA_MODEL_LINK __declspec(dllimport)
#endif
#else
#define DATA_MODEL_LINK
#endif
