#pragma once

#include <iostream>
#include <unordered_set>
#include <unordered_map>
#include <map>
#include <string>
#include <memory>
#include <vector>

#include <DataModelGlobal.h>

struct DATA_MODEL_LINK OffsetLoc {
  OffsetLoc() = default;
  OffsetLoc(const OffsetLoc &lnCol) {
    m_ln = lnCol.ln();
    m_col = lnCol.col();
  }
  OffsetLoc(const unsigned &ln, const unsigned &col) : m_ln(ln), m_col(col) {}
  unsigned ln() const {
    return m_ln;
  }
  unsigned col() const {
    return m_col;
  }
  std::string toString() const {
    return std::to_string(m_ln) + ":" + std::to_string(m_col);
  }

  bool operator==(const OffsetLoc &loc) const {
    return (m_ln == loc.ln() && m_col == loc.col());
  }

protected:
  unsigned m_ln = 0;
  unsigned m_col = 0;
};

class DATA_MODEL_LINK Location {
  std::string m_path;
  OffsetLoc m_lnCol;

public:
  Location() = default;
  Location(const std::string &path, const unsigned &ln, const unsigned &col) : m_path(path) {
    m_lnCol = OffsetLoc(ln, col);
  }
  std::string path() const {
    return m_path;
  }
  OffsetLoc offset() const {
    return m_lnCol;
  }
  void setPath(const std::string &path) {
    this->m_path = path;
  }
  bool operator==(const Location &loc) const {
    return (m_path == loc.path() && m_lnCol == loc.m_lnCol);
  }

  std::string toString() const {
    return m_path + ": " + std::to_string(m_lnCol.ln()) + ":" + std::to_string(m_lnCol.col());
  }
};

struct DATA_MODEL_LINK NodeType {
  enum Value {
    NA = 0,
    DEFINITION,
    DECLARATION,
    VIRTUAL,
    POINTER_FUNCTION,
    TEMPLATE,
    FIELD,
    VARDECL,
    VARDEF
  };
  NodeType(Value v = NA);
  char getChar() const;
  ;
  static NodeType fromChar(char c);
  DATA_MODEL_LINK friend bool operator==(NodeType n1, NodeType n2);
  std::string getName() const;

private:
  Value value;
};

DATA_MODEL_LINK bool operator==(NodeType n1, NodeType n2);
DATA_MODEL_LINK bool operator!=(NodeType n1, NodeType n2);

struct DATA_MODEL_LINK LinkType {
  enum Value { NA = 0, CALLS, IMPLEMENTS, OVERRIDES, DECLARES, INSTANTIATES, ACCESSES };
  LinkType(Value v);
  int getValue() const;
  ;
  static LinkType fromValue(int);
  DATA_MODEL_LINK friend bool operator==(LinkType, LinkType);
  std::string getName() const;

private:
  Value value;
};

DATA_MODEL_LINK bool operator==(LinkType n1, LinkType n2);

typedef std::string IUSR;

struct Link;

class DATA_MODEL_LINK Symbol {
public:
  explicit Symbol(const IUSR &);
  ~Symbol();

  const std::string &demangled() const {
    return m_demangled;
  }
  const Location &location() const {
    return m_location;
  }
  const std::vector<Link *> &links() const {
    return m_links;
  }
  void addLink(Symbol &dst, LinkType type);
  void setLocation(const Location &l) {
    m_location = l;
  }
  void setDemangled(const std::string &d) {
    m_demangled = d;
  }
  const IUSR &getIUSR() const {
    return iusr;
  }

  std::string getUSR() const {
    return iusr.substr(0, iusr.size() - 1);
  }

  NodeType getType() const {
    return getType(iusr);
  }

  static NodeType getType(const IUSR &);

  bool isDefinition() const {
    auto type = getType();
    return type == NodeType::DEFINITION || type == NodeType::VARDEF;
  }

private:
  void addInternLink(Link *);
  void removeInternLink(Link *l);

  std::string m_demangled;
  Location m_location;
  std::vector<Link *> m_links;
  IUSR iusr;
};

struct Link {
  Symbol &src, &trg;
  LinkType type;
  Link(Symbol &src, Symbol &trg, LinkType type) : src(src), trg(trg), type(std::move(type)) {}
  Symbol *getOther(const Symbol &) const;
};

/*
 includeDirectives: contains pairs of header_file path and line in which
 the source file has the #include directive for the header_file
 headerSearchEntries: inclusion paths for all header_files
*/
struct InclusionInfo {
  std::vector<std::pair<std::string, int>> includeDirectives;
  std::vector<std::string> headerSearchEntries;
};

class DATA_MODEL_LINK BatchSymbols {
  typedef std::unordered_map<IUSR, std::unique_ptr<Symbol>> SymbolMap;

public:
  typedef std::map<std::string, InclusionInfo> InclusionMap;

private:
  SymbolMap m_symbols;
  InclusionMap m_inclusion;

public:
  BatchSymbols() = default;
  BatchSymbols(const BatchSymbols &) = delete;
  BatchSymbols &operator=(const BatchSymbols &) = delete;

  const SymbolMap &symbols() const;

  const Symbol *getSymbol(const IUSR &iusr) const;
  Symbol &getSymbol(const IUSR &iusr);

  void pushUpDependencies();

  static IUSR makeIUSR(const std::string &usr, NodeType type);

  void addInclusion(InclusionMap inclusion);
  InclusionMap getInclusion() const;
  void addUserHeaderEntries(std::string file);
};
