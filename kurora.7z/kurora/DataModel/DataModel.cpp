#include <algorithm>
#include <DataModel.h>

Symbol::Symbol(const IUSR &iusr) : iusr(iusr) {}

bool operator==(LinkType l1, LinkType l2) {
  return l1.value == l2.value;
}

bool operator==(NodeType n1, NodeType n2) {
  return n1.value == n2.value;
}

bool operator!=(NodeType n1, NodeType n2) {
  return !(n1 == n2);
}

NodeType::NodeType(Value v) : value(v) {}

char NodeType::getChar() const {
  return 'a' + value;
}

NodeType NodeType::fromChar(char c) {
  return NodeType(static_cast<Value>(c - 'a'));
}

static const char *nodeTypeNames[] = {"NA",      "DEFINITION",       "DECLARATION",
                                      "VIRTUAL", "POINTER_FUNCTION", "TEMPLATE",
                                      "FIELD",   "VARDECL",          "VARDEF"};

std::string NodeType::getName() const {
  return nodeTypeNames[value];
}

LinkType::LinkType(Value v) : value(v) {}

int LinkType::getValue() const {
  return value;
}

LinkType LinkType::fromValue(int v) {
  return static_cast<Value>(v);
}

static const char *linkTypeNames[] = {"NA",       "CALLS",        "IMPLEMENTS", "OVERRIDES",
                                      "DECLARES", "INSTANTIATES", "ACCESSES"};

std::string LinkType::getName() const {
  return linkTypeNames[value];
}

const BatchSymbols::SymbolMap &BatchSymbols::symbols() const {
  return m_symbols;
}

const Symbol *BatchSymbols::getSymbol(const IUSR &iusr) const {
  auto it = m_symbols.find(iusr);
  return it != m_symbols.end() ? it->second.get() : nullptr;
}

NodeType Symbol::getType(const IUSR &iusr) {
  return NodeType::fromChar(iusr.back());
}

Symbol &BatchSymbols::getSymbol(const IUSR &iusr) {
  auto it = m_symbols.find(iusr);
  if (it != m_symbols.end()) {
    return *it->second.get();
  }
  return *m_symbols.insert(std::make_pair(iusr, std::unique_ptr<Symbol>(new Symbol(iusr))))
              .first->second.get();
}

IUSR BatchSymbols::makeIUSR(const std::string &usr, NodeType type) {
  return usr + type.getChar();
}

Symbol *Link::getOther(const Symbol &n) const {
  return (&n == &src) ? ((&n == &trg) ? nullptr : &trg) : &src;
}

namespace {
template <typename T>
void none(T *) {}
} // namespace

Symbol::~Symbol() {
  for (auto link : m_links) {
    auto other = link->getOther(*this);
    if (other) {
      other->removeInternLink(link);
    }
    delete link;
  }
}

void Symbol::removeInternLink(Link *l) {
  m_links.erase(std::remove(m_links.begin(), m_links.end(), l), m_links.end());
}

void Symbol::addInternLink(Link *l) {
  m_links.push_back(l);
}

void Symbol::addLink(Symbol &dst, LinkType type) {
  if (&dst != this) {
    // std::cout << "add link " << this->getIUSR()<<" -"<<type.getName()<<"> " <<
    // dst.getIUSR()<<std::endl;
    auto found =
        std::find_if(m_links.begin(), m_links.end(), [&](Link *l) { return &l->trg == &dst; });
    if (found == m_links.end()) {
      auto l = new Link(*this, dst, type);
      m_links.push_back(l);
      dst.addInternLink(l);
    }
  }
}

void BatchSymbols::pushUpDependencies() {
  std::vector<IUSR> templates;
  for (const auto &i : m_symbols) {
    if (i.second->location().path() == ".") {
      templates.push_back(i.first);
    }
  }
  for (auto tempIUSR : templates) {
    auto found = m_symbols.find(tempIUSR);
    if (found != m_symbols.end()) {
      Symbol &temp = *found->second.get();
      auto links = temp.links();
      // links partition: Loop/PureIncoming/PureOutcoming
      auto incomingEnd =
          std::partition(links.begin(), links.end(), [&](auto l) { return &l->trg == &temp; });
      auto loopEnd =
          std::partition(links.begin(), incomingEnd, [&](auto l) { return &l->src == &temp; });

      for (auto pureIncoming = loopEnd; pureIncoming != incomingEnd; ++pureIncoming) {
        for (auto pureOutcoming = incomingEnd; pureOutcoming != links.end(); ++pureOutcoming) {
          (*pureIncoming)->src.addLink((*pureOutcoming)->trg, (*pureOutcoming)->type);
        }
      }
      m_symbols.erase(found);
    }
  }
}

void BatchSymbols::addInclusion(BatchSymbols::InclusionMap inclusion)
{
	m_inclusion.insert(inclusion.begin(), inclusion.end());
}

BatchSymbols::InclusionMap BatchSymbols::getInclusion() const
{
	return m_inclusion;
}
