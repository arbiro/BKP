#pragma once

/* MSVC DLL import/export. */
#ifdef _MSC_VER
#pragma warning(disable : 4297)
#ifdef MINCUT_LIB
#define MINCUT_LINK __declspec(dllexport)
#else
#define MINCUT_LINK __declspec(dllimport)
#endif
#else
#define MINCUT_LINK
#endif
