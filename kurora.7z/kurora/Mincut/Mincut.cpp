#include <functional>
#include <memory>
#include <random>

#include "Mincut.h"

PLUGIN(Mincut)

using namespace tlp;
using namespace std;

const char *Mincut::PROP_NAME = "MinCut";
const char *Mincut::REMAINING_NODES = "remaining nodes";
const char *Mincut::ITERATIONS = "Iterations";
const char *Mincut::WEIGHT = "Edge weight";

Mincut::Mincut(const tlp::PluginContext *context) : Algorithm(context) {
  addInParameter<tlp::NumericProperty *>(WEIGHT, "Numeric Property used as edge weight",
                                         "viewMetric");
  addInParameter<int>(REMAINING_NODES, "The number of nodes that define the cut", "2");
  addInParameter<int>(ITERATIONS, "Number of iterations", "1");
}
//====================================================================

// Compute the number of edges connecting two equivalent nodes (aka contracted
// nodes) in the entire graph paseed by arg.
static size_t cutSize(const tlp::Graph &graph, const tlp::NodeStaticProperty<int> &equ) {
  size_t result = 0;
  for (edge e : graph.edges())
    if (equ[graph.source(e)] != equ[graph.target(e)])
      ++result;
  return result;
}

// Select the edges in function of the weight (actually dead code for now)
static edge selectEdge(tlp::Graph *currentGraph, tlp::DoubleProperty *metric, double threshold) {
  const vector<edge> &allEdges = currentGraph->edges();
  double sum = 0;
  for (edge e : allEdges) {
    sum += metric->getEdgeValue(e);
    if (sum >= threshold)
      return e;
  }
  return *(allEdges.end() - 1);
}

// Dead code for now.
static std::vector<edge> getInOutEdges(tlp::Graph *g, node n) {
  std::vector<edge> result;
  edge e;
  forEach (e, g->getInOutEdges(n)) { result.push_back(e); }
  return result;
}

struct Data {

  tlp::Graph *graph;
  tlp::NodeStaticProperty<tlp::node> nodeEquiv;
  std::vector<tlp::edge> edges;
  std::vector<double> weights;
  std::random_device rd;

  Data(tlp::Graph *g, tlp::DoubleProperty *weight) : graph(g), nodeEquiv(g) {
    tlp::node n;
    forEach (n, g->getNodes()) { nodeEquiv[n] = n; }
    for (auto e : g->edges()) {
      edges.push_back(e);
      weights.push_back(weight->getEdgeDoubleValue(e));
    }
  }

  void makeEquiv(tlp::node n1, tlp::node n2) {
    nodeEquiv[getEquivClass(n1)] = getEquivClass(n2);
  }

  bool isEquiv(tlp::node n1, tlp::node n2) {
    return getEquivClass(n1) == getEquivClass(n2);
  }

  tlp::node getEquivClass(tlp::node n) {
    tlp::node next = nodeEquiv[n];
    if (n == next) {
      return n;
    }
    next = getEquivClass(next);
    // relation flattening
    nodeEquiv[n] = next;
    return next;
  }

  bool isInAClass(tlp::edge e) {
    return isEquiv(graph->source(e), graph->target(e));
  }

  // select a random edge, then cut while it is in a Class
  // (i.e the two nodes have the same equiv class).
  tlp::edge getRandomEdge() {

  std:
    mt19937 gen(rd());
    std::discrete_distribution<> distr(weights.begin(), weights.end());

    auto pos = distr(gen);
    auto selected = edges[pos];

    while (isInAClass(selected)) {
      size_t lastIdx = edges.size() - 1;
      if (lastIdx == 0)
        return edge();
      std::swap(edges[pos], edges[lastIdx]);
      std::swap(weights[pos], weights[lastIdx]);
      edges.resize(lastIdx);
      weights.resize(lastIdx);
      pos = (pos + 1) % lastIdx;
      selected = edges[pos];
    }

    return selected;
  }

  void cleanCutEdges() {
    edges.erase(
        std::remove_if(edges.begin(), edges.end(), [&](tlp::edge e) { return isInAClass(e); }),
        edges.end());
  }

  size_t getCutSize() const {
    return edges.size();
  }

  bool calculateEquivRelation(int nbOfRemainingNodes) {
    int maxStep = std::max((int)graph->numberOfNodes() - nbOfRemainingNodes, 0);
    for (int step = 0; step < maxStep; ++step) {
      int nbNodes = (int)graph->numberOfNodes();

      edge selectedEdge = getRandomEdge();

      if (selectedEdge == edge())
        break; // no more edges

      node src = graph->source(selectedEdge);
      node trg = graph->target(selectedEdge);

      makeEquiv(src, trg);
    }
    return true;
  }

  std::unique_ptr<tlp::NodeStaticProperty<int>> createCutMetric() {
    std::unique_ptr<tlp::NodeStaticProperty<int>> result(new tlp::NodeStaticProperty<int>(graph));
    std::unordered_map<tlp::node, int> classNumber;
    int maxStep = graph->numberOfNodes();
    for (tlp::node n : graph->nodes()) {
      tlp::node equivClass = getEquivClass(n);
      auto found = classNumber.insert(std::make_pair(equivClass, classNumber.size())).first;
      result->setNodeValue(n, found->second);
    }
    return result;
  }
};

static std::unique_ptr<tlp::NodeStaticProperty<int>> createCut(tlp::Graph *currentGraph,
                                                               tlp::DoubleProperty *weight,
                                                               int nbOfRemainingNodes,
                                                               size_t &cutSize) {
  Data data(currentGraph, weight);
  if (!data.calculateEquivRelation(nbOfRemainingNodes))
    return nullptr;
  std::unique_ptr<tlp::NodeStaticProperty<int>> result = data.createCutMetric();
  if (result) {
    data.cleanCutEdges();
    cutSize = data.getCutSize();
  }
  return result;
}

static void copyTo(const tlp::Graph &graph, const tlp::NodeStaticProperty<int> &src,
                   IntegerProperty &dst) {
  for (tlp::node n : graph.nodes()) {
    dst.setNodeValue(n, src.getNodeValue(n));
  }
}

static void copyTo(const tlp::Graph &graph, const IntegerProperty &src,
                   tlp::NodeStaticProperty<int> &dst) {
  for (tlp::node n : graph.nodes()) {
    dst.setNodeValue(n, src.getNodeValue(n));
  }
}

static std::unique_ptr<tlp::NodeStaticProperty<int>> retrieveFirstMinCut(tlp::Graph *graph,
                                                                         size_t &mincutSize) {
  if (!graph->existProperty(Mincut::PROP_NAME))
    return nullptr;
  IntegerProperty *startProp = graph->getProperty<IntegerProperty>(Mincut::PROP_NAME);
  std::unique_ptr<tlp::NodeStaticProperty<int>> minCutProp =
      std::unique_ptr<tlp::NodeStaticProperty<int>>(new tlp::NodeStaticProperty<int>(graph));
  copyTo(*graph, *startProp, *minCutProp);
  mincutSize = cutSize(*graph, *minCutProp);
  return minCutProp;
}

static bool calcMinCut(tlp::Graph *graph, tlp::DoubleProperty *weight, int nbOfIterations,
                       int nbOfRemainingNodes, tlp::PluginProgress *pluginProgress) {
  if (graph && pluginProgress) {
    int nbNodes = graph->numberOfNodes();
    size_t mincutValue = UINT_MAX;
    std::unique_ptr<tlp::NodeStaticProperty<int>> minCutProp;
    for (int i = 0; i < nbOfIterations; i++) {
      minCutProp = retrieveFirstMinCut(graph, mincutValue);
      size_t tryValue;
      std::unique_ptr<tlp::NodeStaticProperty<int>> tryCutProp;
      if (pluginProgress && (pluginProgress->progress(i, nbOfIterations) != tlp::TLP_CONTINUE))
        return false;
      tryCutProp = createCut(graph, weight, nbOfRemainingNodes, tryValue);
      if (!tryCutProp)
        return false;
      if (tryValue < mincutValue) {
        swap(minCutProp, tryCutProp);
        mincutValue = tryValue;
      } else {
      }
      copyTo(*graph, *minCutProp, *graph->getLocalProperty<IntegerProperty>(Mincut::PROP_NAME));
    }
    return true;
  }
  return false;
}

bool Mincut::run() {
  tlp::DoubleProperty *weight = NULL;
  int nbOfIterations = 1;
  int nbOfRemainingNodes = 0;

  if (dataSet != NULL) {
    dataSet->get(WEIGHT, weight);
    dataSet->get(REMAINING_NODES, nbOfRemainingNodes);
    dataSet->get(ITERATIONS, nbOfIterations);
  }

  return calcMinCut(graph, weight, nbOfIterations, nbOfRemainingNodes, pluginProgress);
}
