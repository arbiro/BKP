#ifndef _DEPTH_FOR_CG_METRIC_H
#define _DEPTH_FOR_CG_METRIC_H

#include <tulip/TulipPluginHeaders.h>
#include <tulip/ForEach.h>

#include <MincutGlobal.h>

/*
** This plugin computes the min-cut using the Karger algorithm
** (randomized algorithm).
**
** The idea of the algorithm is based on the concept of contraction
** of an edge. In this implementation, we represented the contractions
** with a property of equivalence (for performance purpose).
**
*/

class MINCUT_LINK Mincut : public tlp::Algorithm {
public:
  static const char *PROP_NAME;
  static const char *REMAINING_NODES;
  static const char *ITERATIONS;
  static const char *WEIGHT;

  PLUGININFORMATION("Mincut", "Murex", "17/01/2018",
                    "Computes the minimum cut on a graph"
                    "",
                    "1.0", "Hierarchical")
  Mincut(const tlp::PluginContext *context);
  bool run();
};

#endif
