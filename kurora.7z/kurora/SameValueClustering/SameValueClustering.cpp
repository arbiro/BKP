#include <memory>
#include <functional>

#include <tulip/GraphProperty.h>
#include <tulip/StringCollection.h>

#include "SameValueClustering.h"

PLUGIN(SameValueClustering)

namespace {
static const char *INPUT_PROPERTY = "input";
static const char *COUNTED_PROPERTY = "counted property";

static const char *VIEW_LABEL_METRIC = "viewLabel";
static const char *NB_OF_VALUES_METRIC = "nbOfValues";

struct LightProp {
  virtual std::string getValue(tlp::node n) const = 0;
  virtual std::string getValue(tlp::edge n) const = 0;
};

struct GraphLightProp : public LightProp {
  tlp::PropertyInterface &prop;
  explicit GraphLightProp(tlp::PropertyInterface &prop) : prop(prop) {}
  virtual std::string getValue(tlp::node n) const {
    return prop.getNodeStringValue(n);
  }
  virtual std::string getValue(tlp::edge e) const {
    return prop.getEdgeStringValue(e);
  }
};

struct IdLightProp : public LightProp {
  virtual std::string getValue(tlp::node n) const {
    return std::to_string(n.id);
  }
  virtual std::string getValue(tlp::edge e) const {
    return std::to_string(e.id);
  }
};

struct Parameters {
  tlp::PropertyInterface *input = nullptr;
  std::unique_ptr<LightProp> countedProperty;
  Parameters(const tlp::DataSet &dataSet) {
    dataSet.get(INPUT_PROPERTY, input);
    tlp::PropertyInterface *countedPropertyInDataSet = nullptr;
    dataSet.get(COUNTED_PROPERTY, countedPropertyInDataSet);
    if (countedPropertyInDataSet) {
      countedProperty = std::make_unique<GraphLightProp>(*countedPropertyInDataSet);
    } else {
      countedProperty = std::make_unique<IdLightProp>();
    }
  }
  LightProp *getCounterProperty() const {
    if (countedProperty) {
    } else {
    }
  }
};

class LightPropHash {
  LightProp &prop;

public:
  explicit LightPropHash(LightProp &prop) : prop(prop) {}
  template <typename T>
  size_t operator()(T n) const {
    return std::hash<std::string>()(prop.getValue(n));
  }
};

class LightPropEqual {
  LightProp &prop;

public:
  explicit LightPropEqual(LightProp &prop) : prop(prop) {}
  template <typename T>
  bool operator()(T n1, T n2) const {
    return prop.getValue(n1) == prop.getValue(n2);
  }
};

typedef std::unordered_set<tlp::node, LightPropHash, LightPropEqual> NodeValueSet;
typedef std::unordered_set<tlp::edge, LightPropHash, LightPropEqual> EdgeValueSet;
typedef std::function<bool(int, int)> Progress;

bool processNodes(const Parameters &param, tlp::Graph &graph, tlp::Graph &clusterGraph,
                  std::unordered_map<std::string, tlp::node> &nodes, Progress progress) {
  tlp::NodeStaticProperty<NodeValueSet *> clusterValues(&clusterGraph);
  tlp::StringProperty *name = clusterGraph.getLocalProperty<tlp::StringProperty>(VIEW_LABEL_METRIC);
  auto clusterProperty = clusterGraph.getProperty(param.input->getName());
  tlp::IntegerProperty *nbOfValues =
      clusterGraph.getLocalProperty<tlp::IntegerProperty>(NB_OF_VALUES_METRIC);

  const int maxSteps = graph.numberOfNodes();
  int step = 0;

  for (tlp::node n : graph.nodes()) {
    const std::string &value = param.input->getNodeStringValue(n);
    auto &found = nodes[value];
    NodeValueSet *nodeValueSet;
    if (!found.isValid()) {
      found = clusterGraph.addNode();
      name->setNodeValue(found, value);
      clusterProperty->setNodeStringValue(found, value);
      nodeValueSet = new NodeValueSet(1, LightPropHash(*param.countedProperty),
                                      LightPropEqual(*param.countedProperty));
      clusterValues.addNodeValue(found, nodeValueSet);
    } else {
      nodeValueSet = clusterValues.getNodeValue(found);
    }
    nodeValueSet->insert(n);

    if (!progress(step++, maxSteps)) {
      return false;
    }
  }
  for (tlp::node n : clusterGraph.nodes()) {
    NodeValueSet *nodeValueSet = clusterValues.getNodeValue(n);
    nbOfValues->setNodeValue(n, nodeValueSet->size());
    delete nodeValueSet;
  }
  return true;
}

bool processEdges(const Parameters &param, tlp::Graph &graph, tlp::Graph &clusterGraph,
                  std::unordered_map<std::string, tlp::node> &nodes, Progress progress) {
  tlp::EdgeStaticProperty<EdgeValueSet *> clusterValues(&clusterGraph);
  tlp::IntegerProperty *nbOfValues =
      clusterGraph.getLocalProperty<tlp::IntegerProperty>(NB_OF_VALUES_METRIC);

  const int maxSteps = graph.numberOfEdges();
  int step = 0;

  for (tlp::edge e : graph.edges()) {
    const std::string &srcValue = param.input->getNodeStringValue(graph.source(e));
    const std::string &dstValue = param.input->getNodeStringValue(graph.target(e));
    if (srcValue != dstValue) {
      auto srcNode = nodes[srcValue];
      auto dstNode = nodes[dstValue];
      tlp::edge found = clusterGraph.existEdge(srcNode, dstNode);
      EdgeValueSet *edgeValueSet;
      if (!found.isValid()) {
        found = clusterGraph.addEdge(srcNode, dstNode);
        edgeValueSet = new EdgeValueSet(1, LightPropHash(*param.countedProperty),
                                        LightPropEqual(*param.countedProperty));
        clusterValues.addEdgeValue(found, edgeValueSet);
      } else {
        edgeValueSet = clusterValues.getEdgeValue(found);
      }
      edgeValueSet->insert(e);
    }

    if (!progress(step++, maxSteps)) {
      return false;
    }
  }
  for (tlp::edge e : clusterGraph.edges()) {
    EdgeValueSet *edgeValueSet = clusterValues.getEdgeValue(e);
    nbOfValues->setEdgeValue(e, edgeValueSet->size());
    delete edgeValueSet;
  }
  return true;
}
} // namespace

SameValueClustering::SameValueClustering(tlp::PluginContext *context) : Algorithm(context) {
  addInParameter<tlp::PropertyInterface *>(INPUT_PROPERTY, "Input Metric", "viewMetric");
  addInParameter<tlp::PropertyInterface *>(COUNTED_PROPERTY, "Counted Metric", "", false);
}

bool SameValueClustering::run() {
  if (dataSet == nullptr)
    return false;
  if (graph == graph->getSuperGraph())
    return false; // the root cannot be used
  Parameters param(*dataSet);

  tlp::Graph *clusterGraph = graph->getSuperGraph()->addSubGraph(
      "Graph" + std::to_string(graph->getId()) + "/" + param.input->getName());
  clusterGraph->setAttribute("originGraphId", graph->getId());
  std::unordered_map<std::string, tlp::node> nodes;
  return processNodes(param, *graph, *clusterGraph, nodes,
                      [&](int step, int maxSteps) {
                        return pluginProgress->progress(step, 2 * maxSteps) == tlp::TLP_CONTINUE;
                      }) &&
         processEdges(param, *graph, *clusterGraph, nodes, [&](int step, int maxSteps) {
           return pluginProgress->progress(step + maxSteps, 2 * maxSteps) == tlp::TLP_CONTINUE;
         });
}
