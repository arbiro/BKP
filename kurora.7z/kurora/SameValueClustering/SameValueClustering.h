#pragma once

#include <tulip/TulipPluginHeaders.h>

class SameValueClustering : public tlp::Algorithm {
public:
  PLUGININFORMATION("Same Value", "Murex Team", "16/06/2017",
                    "Performs a graph clusterization grouping in the same node the nodes having "
                    "the same value for a given property.",
                    "1.0", "Clustering")
  SameValueClustering(tlp::PluginContext *context);

  bool run();
};
