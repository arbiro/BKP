#include <tulip/StringCollection.h>
#include <tulip/StableIterator.h>
#include <tulip/ForEach.h>
#include <tulip/StaticProperty.h>
#include <memory>
#include "ReachableBall.h"

PLUGIN(ReachableBall)

using namespace tlp;
using namespace std;

static const char *DIRECTION = "Direction";
static const char *STARTINGELEMENTS = "Starting elements";
static const char *DISTANCE = "Distance";
enum Direction { OUTPUT_EDGES , INPUT_EDGES, ALL_EDGES };

ReachableBall::ReachableBall(PluginContext *context) : BooleanAlgorithm(context) {
	addInParameter<StringCollection>(DIRECTION, "Navigation direction: output edges/input edges/all edges", "output edges;input edges;all edges", true, "output edges <br> input edges <br> all edges");
	addInParameter<BooleanProperty>(STARTINGELEMENTS, "Starting set of elements", "viewSelection");
	addInParameter<int>(DISTANCE, "Maximal distance of reachable elements", "5");
}


Iterator<edge>* processNode(const Graph *graph, node node, EDGE_TYPE direction) {
	switch (direction) {
	case DIRECTED: 
		return graph->getOutEdges(node);
	case INV_DIRECTED: 
		return graph->getInEdges(node);
	case UNDIRECTED: 
		return graph->getInOutEdges(node);
	}
}

void processEdge(const Graph *graph, edge edge, EDGE_TYPE direction, vector<node> &nodesSelected) {
	if (direction == DIRECTED || direction == UNDIRECTED)
		nodesSelected.push_back(graph->target(edge));
	if (direction == INV_DIRECTED || direction == UNDIRECTED)
		nodesSelected.push_back(graph->source(edge));
}

void ReachableBall::setReachable() {

	while (!edgesQueue.empty() || !nodesQueue.empty()) {

		while (!nodesQueue.empty()) {
			node currentNode = nodesQueue.front();
			nodesQueue.pop();

			Iterator<edge>* itE = processNode(graph, currentNode, direction);
			for(edge e : itE) {
				if (edgeDepth->getEdgeValue(e) < 0 || edgeDepth->getEdgeValue(e) > nodeDepth->getNodeValue(currentNode) + 1)
					edgeDepth->setEdgeValue(e, nodeDepth->getNodeValue(currentNode) + 1);

				if (!result->getEdgeValue(e) && edgeDepth->getEdgeValue(e) <= maxDistance * 2) {
					result->setEdgeValue(e, true);
					edgesQueue.push(e);
				}
			}
		}

		while (!edgesQueue.empty()) {
			edge currentEdge = edgesQueue.front();
			edgesQueue.pop();

			vector<node> nodesSelected;			
			processEdge(graph, currentEdge, direction, nodesSelected);
			for (node n : nodesSelected) {
				if (nodeDepth->getNodeValue(n) < 0 || nodeDepth->getNodeValue(n) > edgeDepth->getEdgeValue(currentEdge) + 1)
					nodeDepth->setNodeValue(n, edgeDepth->getEdgeValue(currentEdge) + 1);

				if (!result->getNodeValue(n) && nodeDepth->getNodeValue(n) <= maxDistance * 2) {
					result->setNodeValue(n, true);
					nodesQueue.push(n);
				}
			}
		}

	}

}


bool ReachableBall::run()
{
	StringCollection edgeDirectionCollection;
	BooleanProperty* startElements = graph->getProperty<BooleanProperty>("viewSelection");
	

	if (dataSet != nullptr) {
		dataSet->get(DIRECTION, edgeDirectionCollection);
		switch (edgeDirectionCollection.getCurrent()) {
		case OUTPUT_EDGES: 
			direction = DIRECTED; break;
		case INPUT_EDGES: 
			direction = INV_DIRECTED; break;
		case ALL_EDGES: 
			direction = UNDIRECTED; break;
		}
		
		dataSet->get(DISTANCE, maxDistance);
		dataSet->get(STARTINGELEMENTS, startElements);
	}

	result->setAllEdgeValue(false);
	result->setAllNodeValue(false);

	if (startElements && maxDistance) {		
		nodeDepth = unique_ptr<NodeStaticProperty<int>>(new NodeStaticProperty<int>(graph));
		edgeDepth = unique_ptr<EdgeStaticProperty<int>>(new EdgeStaticProperty<int>(graph));
		nodeDepth->setAll(-1);
		edgeDepth->setAll(-1);

		unique_ptr<Iterator<node>> itN(startElements->getNodesEqualTo(true));
		unique_ptr<Iterator<edge>> itE(startElements->getEdgesEqualTo(true));
		
		while(itN->hasNext()) {
			node node = itN->next();
			nodesQueue.push(node);
			nodeDepth->setNodeValue(node, 0);
			result->setNodeValue(node, true);
		}

		while(itE->hasNext()) {
			edge edge = itE->next();			
			edgesQueue.push(edge);	
			edgeDepth->setEdgeValue(edge, 0);
		}

		setReachable();		
	}

	return true;
}
