#pragma once
#include <queue>
#include <tulip/BooleanProperty.h>
#include <tulip/TulipPluginHeaders.h>

class ReachableBall : public tlp::BooleanAlgorithm {
public:
	PLUGININFORMATION("ReachableBall", "Murex Team", "16/03/2018",
		"Find all nodes and edges at a fixed distance of a set of elements", "1.0", "Selection")
		ReachableBall(tlp::PluginContext *context);
	bool run() override;

private:
	void setReachable();
	tlp::EDGE_TYPE direction;
	int maxDistance;
	std::queue<tlp::node> nodesQueue;
	std::queue<tlp::edge> edgesQueue;	
	std::unique_ptr<tlp::NodeStaticProperty<int>> nodeDepth;
	std::unique_ptr<tlp::EdgeStaticProperty<int>> edgeDepth;
};
