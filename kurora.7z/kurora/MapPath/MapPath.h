#pragma once

#include <tulip/TulipPluginHeaders.h>
#include <tulip/NumericProperty.h>

class MapPath : public tlp::Algorithm {
public:
  PLUGININFORMATION("Map Path", "Murex Team", "28/06/2017",
                    "Map a path property to another string defined in a file", "1.0", "Misc")
  MapPath(tlp::PluginContext *context);

  bool run();
};
