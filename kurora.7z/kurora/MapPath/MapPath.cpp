#include <memory>
#include <algorithm>
#include <string>
#include <cctype>
#include <fstream>
#include <tulip/StringCollection.h>
#include <tulip/GraphProperty.h>
#include <tulip/ForEach.h>
#include <tulip/Graph.h>

#include "MapPath.h"

PLUGIN(MapPath)

namespace {
// trim from start(in place)
inline void ltrim(std::string &s) {
  s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](int ch) { return !std::isspace(ch); }));
}

// trim from end (in place)
inline void rtrim(std::string &s) {
  s.erase(std::find_if(s.rbegin(), s.rend(), [](int ch) { return !std::isspace(ch); }).base(),
          s.end());
}

// trim from both ends (in place)
inline void trim(std::string &s) {
  ltrim(s);
  rtrim(s);
}

class Node {
  std::unique_ptr<std::string> label;
  std::vector<std::pair<std::string, std::unique_ptr<Node>>> nodes;

  auto findChild(const std::string &name) const {
    return std::find_if(nodes.begin(), nodes.end(),
                        [&name](const auto &value) { return value.first == name; });
  }
  static std::string firstName(const std::string &path) {
    auto pos = path.find_first_of('/');
    return std::string(path, 0, pos);
  }

  static std::string getNextPath(const std::string &path) {
    auto pos = path.find_first_of('/');
    return pos == std::string::npos ? std::string() : (path.substr(pos + 1));
  }
  Node &createNode(const std::string &path) {
    if (path.empty()) {
      return *this;
    }
    const std::string &childName = firstName(path);
    auto found = findChild(childName);
    if (found == nodes.end()) {
      nodes.push_back(std::make_pair(childName, std::unique_ptr<Node>(new Node())));
      found = nodes.end() - 1;
    }
    return found->second->createNode(getNextPath(path));
  }
  bool setLabel(const std::string &newLabel) {
    if (!label) {
      label = std::unique_ptr<std::string>(new std::string(newLabel));
    }
    return *label == newLabel;
  }
  const std::string *getLabel() const {
    return label.get();
  }

public:
  bool fill(const std::string &path, const std::string &newLabel) {
    return createNode(path).setLabel(newLabel);
  }
  const std::string *get(const std::string &path) const {
    if (path.empty()) {
      return getLabel();
    }
    auto found = findChild(firstName(path));
    auto result = (found == nodes.end()) ? nullptr : (found->second->get(getNextPath(path)));
    return result == nullptr ? getLabel() : result;
  }
};

std::unique_ptr<Node> getRootFromFile(std::string &fileName) {
  std::unique_ptr<Node> result(new Node());
  std::ifstream infile(fileName);
  for (std::string line; std::getline(infile, line);) {
    trim(line);
    std::size_t lastSpacePos = line.rfind(' ');
    if (lastSpacePos != std::string::npos) {
      std::string path(line, 0, lastSpacePos);
      std::string label(line, lastSpacePos + 1);
      rtrim(path);
      result->fill(path, label);
    }
  }
  return result;
}

static const char *EMPTY_PATH = ".";
struct Transformer {
  std::unique_ptr<const Node> root;
  Transformer(std::string &file) : root(getRootFromFile(file)) {}
  std::string operator()(const std::string &value) const {
    auto result = root->get(value);
    return result == nullptr ? EMPTY_PATH : (result->empty() ? EMPTY_PATH : *result);
  }
};

static const char *INPUT_PATH = "inputPath";
static const char *OUTPUT_PATH = "outputPath";
static const char *TARGET_TYPE = "target";
static const char *MAPPING_FILE = "file::mappingFile";
static const char *TARGET_TYPES = "nodes;edges;both";

static const int NODES_TARGET = 0;
static const int EDGES_TARGET = 1;
static const int BOTH_TARGET = 2;

struct Parameters {
  tlp::StringProperty *input;
  tlp::StringProperty *output;
  bool withNodes;
  bool withEdges;
  std::unique_ptr<Transformer> mapFunction;

private:
  static std::unique_ptr<Transformer> getTransformer(const tlp::DataSet &data) {
    std::string mappingFile;
    data.get(MAPPING_FILE, mappingFile);
    if (mappingFile.empty())
      return nullptr;
    return std::unique_ptr<Transformer>(new Transformer(mappingFile));
  }

public:
  Parameters(tlp::Graph &graph, const tlp::DataSet &dataSet)
      : input(nullptr), output(nullptr), mapFunction(getTransformer(dataSet)) {
    dataSet.get(INPUT_PATH, input);
    dataSet.get(OUTPUT_PATH, output);
    tlp::StringCollection targetType;
    dataSet.get(TARGET_TYPE, targetType);
    withNodes = targetType.getCurrent() == NODES_TARGET || targetType.getCurrent() == BOTH_TARGET;
    withEdges = targetType.getCurrent() == EDGES_TARGET || targetType.getCurrent() == BOTH_TARGET;
  }
  bool isValid() const {
    return input && output && mapFunction;
  }

  static void doRegistering(tlp::Algorithm &algo) {
    algo.addInParameter<tlp::PropertyInterface *>(INPUT_PATH, "Input Path", "Path");
    algo.addInParameter<tlp::PropertyInterface *>(OUTPUT_PATH, "Output Path", "Path");
    algo.addInParameter<tlp::StringCollection>(
        TARGET_TYPE,
        "Whether the algorithm is applyed only for nodes, only for edges, or for both.",
        TARGET_TYPES, true, "nodes <br> edges <br> both");
    algo.addInParameter<std::string>(MAPPING_FILE, "The file which contains a mapping", "");
  }
};
} // namespace

MapPath::MapPath(tlp::PluginContext *context) : Algorithm(context) {
  Parameters::doRegistering(*this);
}

bool MapPath::run() {
  if (dataSet == nullptr)
    return false;
  Parameters param(*graph, *dataSet);
  if (!param.isValid())
    return false;

  int step = 0;
  int maxSteps = (param.withNodes ? graph->numberOfNodes() : 0) +
                 (param.withEdges ? graph->numberOfEdges() : 0);

  if (param.withNodes) {
    tlp::node n;
    forEach (n, graph->getNodes()) {
      const std::string &value = (*param.mapFunction)(param.input->getNodeStringValue(n));
      param.output->setNodeStringValue(n, value);

      auto state = pluginProgress->progress(step++, maxSteps);
      if (state != tlp::TLP_CONTINUE)
        return state != tlp::TLP_CANCEL;
    }
  }
  if (param.withEdges) {
    tlp::edge e;
    forEach (e, graph->getEdges()) {
      const std::string &value = (*param.mapFunction)(param.input->getEdgeStringValue(e));
      param.output->setEdgeStringValue(e, value);
      auto state = pluginProgress->progress(step++, maxSteps);
      if (state != tlp::TLP_CONTINUE)
        return state != tlp::TLP_CANCEL;
    }
  }
  return true;
}
