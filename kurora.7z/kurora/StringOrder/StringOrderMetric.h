#ifndef _DEPTH_FOR_CG_METRIC_H
#define _DEPTH_FOR_CG_METRIC_H

#include <stack>

#include <tulip/DoubleProperty.h>
#include <tulip/StaticProperty.h>

/** \addtogroup metric */

/** This plugins compute for each node n, the maximum path-length between n and the other nodes.
 *  The graph can be acyclic.
 *
 *  \note This algorithm works on general graphs.
 *
 */

class StringOrderMetric : public tlp::DoubleAlgorithm {
public:
  PLUGININFORMATION(
      "StringOrder", "Murex", "22/01/2018",
      "Calculate a numeric order base on the string representation of the input property.", "1.0",
      "Misc")
  StringOrderMetric(const tlp::PluginContext *context);
  bool run();
};

#endif
