#include <stack>
#include <memory>
#include <algorithm>

#include <tulip/ForEach.h>
#include <tulip/StringCollection.h>

#include "StringOrderMetric.h"

PLUGIN(StringOrderMetric)

namespace {
static const char *INPUT_PATH = "inputPath";
static const char *TARGET_TYPE = "target";
static const char *TARGET_TYPES = "nodes;edges;both";

static const int NODES_TARGET = 0;
static const int EDGES_TARGET = 1;
static const int BOTH_TARGET = 2;

struct Parameters {
  tlp::PropertyInterface *input;
  bool withNodes;
  bool withEdges;

private:
public:
  Parameters(tlp::Graph &graph, const tlp::DataSet &dataSet)
      : input(nullptr), withNodes(false), withEdges(false) {
    dataSet.get(INPUT_PATH, input);
    tlp::StringCollection targetType;
    dataSet.get(TARGET_TYPE, targetType);
    withNodes = targetType.getCurrent() == NODES_TARGET || targetType.getCurrent() == BOTH_TARGET;
    withEdges = targetType.getCurrent() == EDGES_TARGET || targetType.getCurrent() == BOTH_TARGET;
  }
  bool isValid() const {
    return input;
  }

  static void doRegistering(tlp::Algorithm &algo) {
    algo.addInParameter<tlp::PropertyInterface *>(INPUT_PATH, "Input Path", "Path");
    algo.addInParameter<tlp::StringCollection>(
        TARGET_TYPE,
        "Whether the algorithm is applyed only for nodes, only for edges, or for both.",
        TARGET_TYPES, true, "nodes <br> edges <br> both");
  }
};
} // namespace

StringOrderMetric::StringOrderMetric(const tlp::PluginContext *context) : DoubleAlgorithm(context) {
  Parameters::doRegistering(*this);
}

bool StringOrderMetric::run() {
  Parameters param(*graph, *dataSet);
  if (!param.isValid())
    return false;

  int step = 0;
  int maxSteps = 2 * (param.withNodes ? graph->numberOfNodes() : 0) +
                 2 * (param.withEdges ? graph->numberOfEdges() : 0);

  result->setAllEdgeValue(0);
  result->setAllNodeValue(0);
  std::map<std::string, int> strMap;
  if (param.withNodes) {
    tlp::node n;
    forEach (n, graph->getNodes()) {
      const std::string &value = param.input->getNodeStringValue(n);
      strMap.insert(make_pair(value, 0));
      auto state = pluginProgress->progress(step++, maxSteps);
      if (state != tlp::TLP_CONTINUE)
        return state != tlp::TLP_CANCEL;
    }
  }

  if (param.withEdges) {
    tlp::edge e;
    forEach (e, graph->getEdges()) {
      const std::string &value = param.input->getEdgeStringValue(e);
      strMap.insert(make_pair(value, 0));
      auto state = pluginProgress->progress(step++, maxSteps);
      if (state != tlp::TLP_CONTINUE)
        return state != tlp::TLP_CANCEL;
    }
  }

  int i = 0;
  for (auto &pair : strMap) {
    pair.second = i;
    ++i;
  }

  if (param.withNodes) {
    tlp::node n;
    forEach (n, graph->getNodes()) {
      const std::string &value = param.input->getNodeStringValue(n);
      result->setNodeValue(n, strMap[value]);
      auto state = pluginProgress->progress(step++, maxSteps);
      if (state != tlp::TLP_CONTINUE)
        return state != tlp::TLP_CANCEL;
    }
  }

  if (param.withEdges) {
    tlp::edge e;
    forEach (e, graph->getEdges()) {
      const std::string &value = param.input->getEdgeStringValue(e);
      result->setEdgeValue(e, strMap[value]);
      auto state = pluginProgress->progress(step++, maxSteps);
      if (state != tlp::TLP_CONTINUE)
        return state != tlp::TLP_CANCEL;
    }
  }

  return true;
}
