#pragma once

#include <tulip/TulipPluginHeaders.h>
#include <tulip/NumericProperty.h>
#include <tulip/TulipViewSettings.h>
#include "TransitiveReductionGlobal.h"

class TransitiveReduction : public tlp::BooleanAlgorithm {
public:
  PLUGININFORMATION("Transitive Reduction", "Murex Team", "07/03/2018",
                    "Does transitive reduction(eg if there are edges from A to B, from B to C and "
                    "A to C, A to C will be reduced ) ",
                    "1.0", "Misc")
  TransitiveReduction(tlp::PluginContext *context);
  bool run() override;
};
