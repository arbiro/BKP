#include <tulip/GraphProperty.h>
#include <tulip/Graph.h>
#include <set>
#include <stack>
#include <functional>
#include "TransitiveReduction.h"

PLUGIN(TransitiveReduction)

using namespace std;
using namespace tlp;

static const char *PROPERTY = "Value numeric property";

static const char *BEHAVIOUR_TYPE = "Node";
static const char *BEHAVIOURT_TYPES = "add;max";
static const int BEHAVIOUR_ADD = 0;
static const int BEHAVIOUR_MAX = 1;

TransitiveReduction::TransitiveReduction(tlp::PluginContext *context) : BooleanAlgorithm(context) {
  addInParameter<NumericProperty *>(PROPERTY, "Property numeric", "", false);
  addInParameter<StringCollection>(
      BEHAVIOUR_TYPE,
      "Whether to add reported value to edges in path or apply max between it and current",
      BEHAVIOURT_TYPES, true, "add <br> max");
}

class TransitiveReductionAlgo {
public:
  TransitiveReductionAlgo(
      const tlp::Graph *graph, PluginProgress *prog, tlp::BooleanProperty *selectionProp,
      tlp::NumericProperty *reportProp,
      std::function<void(edge, double, double, NumericProperty *)> reportingFunc)
      : m_graph(graph), m_pluginProgress(prog),
        m_selectedAndNotNeededForTransitiveClosureReachability(selectionProp), m_prop(reportProp),
        m_reportingFunction(reportingFunc) {}

  bool run() {
    const auto &nodes = m_graph->nodes();
    const size_t nodesSize = nodes.size();
    size_t currentStep = 0;
    m_pluginProgress->progress(0, nodesSize);
    for (tlp::node n : nodes) {
      /// Do dfs
      if (!dfsMark(n))
        return false;

      currentStep++;
      m_pluginProgress->progress(currentStep, nodesSize);
    }

    return true;
  }

  void applyEdgeValueToPath(edge ed, std::deque<node> &pathDeque) {
    if (m_prop == nullptr)
      return;

    auto edgeVal = m_prop->getEdgeDoubleValue(ed);
    bool first = true;
    node prevNode;
    for (node n : pathDeque) {
      if (first) {
        first = false;
      } else {
        std::vector<edge> edges = m_graph->getEdges(prevNode, n);
        if (!edges.empty()) {
          m_reportingFunction(edges[0], m_prop->getEdgeDoubleValue(edges[0]),
                              m_prop->getEdgeDoubleValue(ed), m_prop);
        }
      }
      prevNode = n;
    }
  }

  bool dfsMark(tlp::node initial) {
    std::stack<node> toVisit;

    std::deque<node> pathDeque;

    NodeStaticProperty<bool> reached(m_graph);
    NodeStaticProperty<bool> path(m_graph);

    toVisit.push(initial);

    while (!toVisit.empty()) {
      if (m_pluginProgress->state() != tlp::ProgressState::TLP_CONTINUE)
        return false;

      node current = toVisit.top();

      if (path[current]) {
        toVisit.pop();
        path[current] = false;
        pathDeque.pop_back();
        continue;
      }
      path[current] = true;
      pathDeque.push_back(current);

      if (!reached[current]) {
        if (pathDeque.size() > 2) {
          reached[current] = true;
          std::vector<edge> edges = m_graph->getEdges(initial, current);
          for (edge ed : edges) {
            m_selectedAndNotNeededForTransitiveClosureReachability->setEdgeValue(ed, true);
            applyEdgeValueToPath(ed, pathDeque);
          }
        }

        for (edge outEdge : m_graph->getOutEdges(current)) { // actual dfs

          if (!m_selectedAndNotNeededForTransitiveClosureReachability->getEdgeValue(outEdge)) {
            node target = m_graph->target(outEdge);
            if (!path[target]) {
              toVisit.push(target);
            } else {
              m_pluginProgress->setComment("ALERT: Cycle detected!!!");
              m_pluginProgress->setError(
                  "ALERT: Cycle detected!!!"); // so it will also display it at
                                               // the end in case the user stops
                                               // it only
                                               // ADD WARNING HERE WHEN AVAILABLE IN TULIP
            }
          }
        }
      }
    }
    return true;
  }

private:
  const tlp::Graph *m_graph;
  tlp::PluginProgress *m_pluginProgress;
  tlp::BooleanProperty *m_selectedAndNotNeededForTransitiveClosureReachability;
  NumericProperty *m_prop = nullptr;
  std::function<void(edge, double, double, NumericProperty *)> m_reportingFunction;
};

void reportFunctionAdd(edge target, double currentTargetVal, double reportedVal,
                       NumericProperty *prop) {
  prop->setEdgeStringValue(target, std::to_string(reportedVal + currentTargetVal));
}

void reportFunctionMax(edge target, double currentTargetVal, double reportedVal,
                       NumericProperty *prop) {
  prop->setEdgeStringValue(target, std::to_string(max(reportedVal, currentTargetVal)));
}

bool TransitiveReduction::run() {
  StringCollection behaviourType;
  NumericProperty *prop;
  behaviourType.setCurrent(BEHAVIOUR_ADD);
  if (dataSet != nullptr) {
    dataSet->get(PROPERTY, prop);
    dataSet->get(BEHAVIOUR_TYPE, behaviourType);
  }

  std::function<void(edge, double, double, NumericProperty *)> funcToUse =
      behaviourType.getCurrent() == BEHAVIOUR_ADD ? &reportFunctionAdd : reportFunctionMax;
  TransitiveReductionAlgo algo(graph, pluginProgress, result, prop, funcToUse);

  return algo.run();
}