import sys, os
import json
import collections
from tulip import tlp


headers = {}


def getIncludes(deq, includes):	
	if deq:
		elem = deq.pop()
		includes.add(headers[elem][0])
		for hfile in headers[elem][1]:
			deq.appendleft(hfile)
		getIncludes(deq, includes)
	

def addccitemforcpp(path, cpppath):
	includes = set()
	deq = collections.deque()
	for line in open(cpppath):
		if "#include" in line:
			header = line[line.find("\"")+1:line.find(".h")+2]
			deq.appendleft(header)
			getIncludes(deq, includes)
			
	includestring = ""
	for elem in includes:
		includestring = includestring + "-isystem\""+elem+"\" "
	commandString ="clang-tool " + includestring +" -std=c++14 \""+cpppath+"\""
	data = {"directory" : path, "command" : commandString, "file" : cpppath}
	return data
	
	
def getSourceFiles(rootdir):
	cpps = []
	for root, subFolders, files in os.walk(rootdir):
		for file in files:
			if file.endswith(".cpp"):
				cpps.append(os.path.join(root, file))
			if file.endswith(".h"):
				includelist = []
				for line in open(os.path.join(root, file)):
					if "#include" in line:
						includelist.append(line[line.find("\"")+1:line.find(".h")+2])
				headers[file]=(root, includelist)
	return cpps

	
def computeCompileCommands(path):
	cppFiles = getSourceFiles(path)	
	maindata = []
	for file in cppFiles:
		maindata.append(addccitemforcpp(path, file))
	with open(path+'//compile_commands.json', 'w') as outfile:
		json.dump(maindata, outfile)
	return outfile
	
	
def computeSymbolDatabase(path):
	compilecommands = computeCompileCommands(path)
	symbolDBFile = path+"\SampleSymbolDatabase.db"
	params = {}
	params['file::compile_commands'] = compilecommands.name
	params['dir::prefixfilter'] = path
	params['anyfile::filenamesavedb'] = symbolDBFile
	graph = tlp.importGraph('Dependency db', params)
	return symbolDBFile
	
	
if __name__ == '__main__':
    computeSymbolDatabase(sys.argv[1])