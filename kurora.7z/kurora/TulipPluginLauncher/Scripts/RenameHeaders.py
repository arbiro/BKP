import sys
import argparse
import sqlite3


parser = argparse.ArgumentParser(description='Rename headers script')
parser.add_argument('symbolsDB',help='SymbolsDB.db; include the extension')
parser.add_argument('headerFile',help='Header file')
args = parser.parse_args()

symbolsDB = args.symbolsDB
headerFile = args.headerFile


def getLocations(header, conn):
	paths = []
	sqlstring = """SELECT Files.path FROM Files, Inclusions
				   WHERE Files.id = Inclusions.source AND 
				   Inclusions.target IN (SELECT id FROM Files WHERE path LIKE '%%%s')""" %header	
	cursor = conn.cursor()
	cursor.execute(sqlstring)
	for row in cursor:
		paths.append(row[0])
	return paths

	
def replaceName(file, oldName, newName):
	with open(file) as f:
		newText=f.read().replace(oldName, newName)
	with open(file, "w") as f:
		f.write(newText)


conn = sqlite3.connect(symbolsDB)
with open(headerFile) as f:
	outputFile = open("OutputRenameHeaders.txt","w+")
	outputFile.write("The following headers will be replaced (old name -> new name): \n\n")
	for line in f:
		oldName, newName = line.split(" ")
		outputFile.write(oldName + " -> " + newName)
		files = getLocations(oldName, conn)
		for file in files:				
			replaceName(file, oldName, newName)
			outputFile.write("\t" + file + "\n")

conn.close()
