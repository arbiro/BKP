import sys, os
import unittest
from xml.dom import minidom
from tulip import tlp

currentDirectory = os.path.dirname(__file__) + "\\"
sys.path.append(currentDirectory)
from ListModules import initialize, getDependencies, Result
from createcompilecommands import computeSymbolDatabase

class ExpectedResult:
		def __init__(self, name, csize, isize):
			self.moduleName = name
			self.callSize = csize
			self.interfaceSize = isize
			
			

class DependenciesTests(unittest.TestCase):

	def test_graph(self):
		self.assertIsNotNone(moduleGraph, "The graph was not successfully computed!")
	
	def test_moduleName(self):
		count = 0		
		for n in moduleGraph.graph.getNodes():
			if moduleGraph.graph.getStringProperty("moduleName")[n] == moduleName:
				count+=1
		self.assertNotEqual(count, 0, "The module is not part of the graph!")
	
	def test_dependenciesDic(self):
		self.assertNotEqual(len(dependenciesDic), 0, "The dependencies were not successfully computed!")
	
	def test_callSize(self):
		self.assertEqual(outputResult.callSize, expectedResult.callSize, "Incorrect call size")
	
	def test_interfaceSize(self):
		self.assertEqual(outputResult.interfaceSize, expectedResult.interfaceSize, "Incorrect interface size")


		
def init(mappingFile):
	global moduleGraph, moduleName
	symbol = computeSymbolDatabase(currentDirectory+"PythonSample")
	moduleGraph = initialize(symbol, mappingFile)
	
def runInitTests():
	suiteInit = unittest.TestSuite()
	suiteInit.addTest(DependenciesTests('test_graph'))
	suiteInit.addTest(DependenciesTests('test_moduleName'))
	result = unittest.TextTestRunner(verbosity=2).run(suiteInit)
	return result	

def runDependencyTest():
	suiteDep = unittest.TestSuite()
	suiteDep.addTest(DependenciesTests('test_dependenciesDic'))
	result = unittest.TextTestRunner(verbosity=2).run(suiteDep)
	return result
	
def runOutputResultTests():
	suiteResults = unittest.TestSuite()
	suiteResults.addTest(DependenciesTests('test_callSize'))
	suiteResults.addTest(DependenciesTests('test_interfaceSize'))	
	result = unittest.TextTestRunner(verbosity=2).run(suiteResults)
	return result

def getExpectedResults(name, modules):
	for module in modules:
		mname = module.attributes['moduleName'].value
		if name==mname:
			csize = module.getElementsByTagName("CS")[0].firstChild.nodeValue
			isize = module.getElementsByTagName("IS")[0].firstChild.nodeValue
			return (mname, int(csize.strip()), int(isize.strip()))
	return ("", 0, 0)
	
	
if __name__ == "__main__":
	
	xmldoc = minidom.parse(sys.argv[1])
	tests = xmldoc.getElementsByTagName("test")
	for test in tests:
		mappingFile = test.attributes['mappingFile'].value
		init(currentDirectory + mappingFile)
		
		moduleDependencies = test.getElementsByTagName("moduleDependencies")		
		for moduleDependency in moduleDependencies:
			moduleName = moduleDependency.attributes['name'].value
			used = moduleDependency.attributes['used'].value

			if runInitTests().wasSuccessful():		
				global dependenciesDic, outputResult, expectedResult
				if used=='false':
					dependenciesDic = getDependencies(moduleGraph, moduleName, False)
				else:
					dependenciesDic = getDependencies(moduleGraph, moduleName, True)
				
				if runDependencyTest().wasSuccessful():					
					modules = moduleDependency.getElementsByTagName("module")
					for key in dependenciesDic:
						outputResult = Result(key, dependenciesDic)
						(mname, csize, isize) = getExpectedResults(key, modules)
						expectedResult = ExpectedResult(mname, csize, isize)
						runOutputResultTests()
