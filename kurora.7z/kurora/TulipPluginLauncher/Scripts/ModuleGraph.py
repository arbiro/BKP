import sys
from tulip import tlp

def addStringProperty(graph, name):
	stringProp = graph.getStringProperty(name)
	stringProp.setAllNodeValue("")
	stringProp.setAllEdgeValue("")
	return name


class ModuleGraph:
	def __init__(self, symboldb, mapping):
		params = {}
		params['anyfile::filenamesavedb'] = symboldb
		self.graph = tlp.importGraph('Dependency db', params)
		self.mappingFile = mapping
		self.clusteredSubGraph = tlp.newGraph()
		
	def truncPath(self, truncPath, removeDepth = 2):
		params = tlp.getDefaultPluginParameters("Trunc Path", self.graph)
		params['inputPath'] = self.graph.getStringProperty("Path")
		params['outputPath'] = self.graph.getStringProperty(truncPath)		
		params['target'] = "nodes"
		params['removeDepth'] = removeDepth
		params['keepDepth'] = 0
		success = self.graph.applyAlgorithm('Trunc Path', params)
		print('Trunc Path: ', success)
		
	def mapPath(self, truncPath, moduleName):
		params = tlp.getDefaultPluginParameters("Map Path", self.graph)
		params['inputPath'] = self.graph.getStringProperty(truncPath)
		params['outputPath'] = self.graph.getStringProperty(moduleName)		
		params['target'] = "nodes"
		params['file::mappingFile'] = self.mappingFile
		success = self.graph.applyAlgorithm('Map Path', params)
		print('Map Path: ', success)
		
	def copyNodePropertyToEdge(self):
		params = tlp.getDefaultPluginParameters("Copy Nodes Property To Edges", self.graph)
		params['String property'] = self.graph.getStringProperty("Key")
		params['Node'] = "target"
		success = self.graph.applyAlgorithm('Copy Nodes Property To Edges', params)
		print('Copy Nodes Property To Edges: ', success)
		
	def sameValue(self, moduleName):
		subgraph = self.graph.addCloneSubGraph(name="Subgraph")	
		params = tlp.getDefaultPluginParameters("Same Value", subgraph)
		params['input'] = subgraph.getStringProperty(moduleName)
		success = subgraph.applyAlgorithm('Same Value', params)
		graph.delSubGraph(subgraph)
		self.clusteredSubgraph = self.graph.getNthSubGraph(self.graph.numberOfSubGraphs()-1)	
		print('Same Value: ', success)
		
	def removeThirdParties(self, moduleName):
		moduleNameProperty = self.clusteredSubgraph.getStringProperty(moduleName)
		for n in self.clusteredSubgraph.getNodes():
			if moduleNameProperty[n] == ".":
				self.clusteredSubgraph.delNode(n)
		
	def MWFAS(self):
		params = tlp.getDefaultPluginParameters("MWFAS", self.clusteredSubgraph)
		params['Edge weight'] = self.clusteredSubgraph.getIntegerProperty("nbOfValues")
		params['Iterations'] = 1
		success = self.clusteredSubgraph.applyBooleanAlgorithm("MWFAS", self.clusteredSubgraph.getBooleanProperty("viewSelection"), params)
		print('MWFAS: ', success)
		
	def transitiveReduction(self):
		params = tlp.getDefaultPluginParameters("Transitive Reduction", self.clusteredSubgraph)
		params['Value numeric property'] = self.clusteredSubgraph.getIntegerProperty("nbOfValues")
		params['Node'] = "add"
		success = self.clusteredSubgraph.applyBooleanAlgorithm("Transitive Reduction", self.clusteredSubgraph.getBooleanProperty("viewSelection"), params)
		print('Transitive Reduction: ', success)
		

		
	

def prepareFinalGraph(moduleGraph):
	truncPath = addStringProperty(moduleGraph.graph, "truncPath")	
	moduleGraph.truncPath(truncPath)
	moduleName=addStringProperty(moduleGraph.graph, "moduleName")
	moduleGraph.mapPath(truncPath, moduleName)
	moduleGraph.copyNodePropertyToEdge()
	moduleGraph.sameValue(moduleName)
	moduleGraph.removeThirdParties(moduleName)
	moduleGraph.MWFAS()
	moduleGraph.transitiveReduction()
		
