import sys
import os
sys.path.append(os.path.dirname(__file__))
from ModuleGraph import *
import argparse
__author__ = 'Murex'


class NodeDetails:
    def __init__(self, nodeID):
        self.nodeId = nodeID
        self.properties = {}
        self.properties["demangledName"] = DemangledNameProperty[nodeID]
        self.properties["Path"] = PathProperty[nodeID]
        self.properties["Ln"] = LineProperty[nodeID]
	
    def printProperties(self):
        print("\tDemangled name: ", self.properties["demangledName"])
        print("\tFile: ", self.properties["Path"])
        print("\tLine: ", self.properties["Ln"])

		
class Result:
    def __init__(self, name, dependenciesDic):
        self.moduleName = name
        self.callSize = len(dependenciesDic[name])		
        self.interfaceSize = self.setInterfaceSize(dependenciesDic)
        self.detailsList = self.setDetails(dependenciesDic)
        
    def setInterfaceSize(self, dependenciesDic):
        unique = set()
        for items in dependenciesDic[self.moduleName]:
            unique.add(items[1])
        return len(unique)
		
    def setDetails(self, dependenciesDic):
        detailsList = []
        for item in dependenciesDic[self.moduleName]:
            detailsList.append((NodeDetails(item[0]), NodeDetails(item[1])))
        return detailsList
		
    def printDetails(self):	
        for item in self.detailsList:
            print("Source:", item[0].nodeId)
            item[0].printProperties()
            print("Target:", item[1].nodeId)
            item[1].printProperties()
	


def parseArguments():
    parser = argparse.ArgumentParser(description='List modules used by module')
    parser.add_argument('symbolsDB',help='SymbolsDB')
    parser.add_argument('mappingFile',help='Mapping File')
    parser.add_argument('moduleName',help='moduleName')
    parser.add_argument('-prefixdepth', dest='prefixdepth', help='Depth to remove in the path''s prefix', required=False, type=int, const=2, default=2, nargs='?')
    parser.add_argument('-is', dest='interfaceSize', help='Interface size', required=False, action='store_true')
    parser.add_argument('-cs', dest='callSize', help='Calling size', required=False, action='store_true')
    parser.add_argument('-d', dest='details', help='Details', required=False, action='store_true')
    parser.add_argument('-u', dest='use', help='List modules which use module', required=False, action='store_true')
    args = parser.parse_args()
    return args


def initialize(symbolsDB, mappingFile, prefixdepth=2): 
    global ModuleNameProp, TypeProperty, DemangledNameProperty, PathProperty, LineProperty
    moduleGraph = setGraph(symbolsDB, mappingFile, prefixdepth)
    ModuleNameProp = moduleGraph.graph.getStringProperty("moduleName")
    TypeProperty = moduleGraph.graph.getStringProperty("Type")
    DemangledNameProperty = moduleGraph.graph.getStringProperty("demangledName")
    PathProperty = moduleGraph.graph.getStringProperty("Path")
    LineProperty = moduleGraph.graph.getIntegerProperty("Ln")
    return moduleGraph
 

def setGraph(symbolsDB, mappingFile, prefixdepth):
    moduleGraph = ModuleGraph(symbolsDB, mappingFile)
    truncPath = addStringProperty(moduleGraph.graph, "truncPath")
    moduleGraph.truncPath(truncPath, prefixdepth)
    addStringProperty(moduleGraph.graph, "moduleName")
    moduleGraph.mapPath(truncPath, "moduleName")
    return moduleGraph


def addDependecies(node, n, edges, currentDeps):
    for e in edges:
        if TypeProperty[e] == "CALLS":
            if ModuleNameProp[n] not in currentDeps:
                currentDeps[ModuleNameProp[n]] = [(node,n)]
            else:
                currentDeps[ModuleNameProp[n]].append((node,n))

def getDependencies(moduleGraph, moduleName, use=False):
    dependenciesDic = {}
    for node in moduleGraph.graph.getNodes():
        if ModuleNameProp[node] == moduleName:
            if use:
                for n in moduleGraph.graph.getOutNodes(node):
                    edges = moduleGraph.graph.getEdges(node, n)
                    addDependecies(node, n, edges, dependenciesDic)
            else:
                for n in moduleGraph.graph.getInNodes(node):
                    edges = moduleGraph.graph.getEdges(n, node)
                    addDependecies(node, n, edges, dependenciesDic)
    return dependenciesDic
			

def printResult(result, interfaceSize, callsSize, details):
    print(result.moduleName)
    if callsSize:
        print("CS:", result.callSize)
    if interfaceSize:        
        print("IS:", result.interfaceSize)
    if details:
        print("DETAILS:")
        result.printDetails()
			


def main():		
    args = parseArguments()
    moduleGraph = initialize(args.symbolsDB, args.mappingFile, args.prefixdepth)
    dependenciesDic = getDependencies(moduleGraph, args.moduleName, args.use)  

    for name in dependenciesDic:
        result = Result(name, dependenciesDic)
        printResult(result, args.interfaceSize, args.callSize, args.details)

	
if __name__ == '__main__':
    main()