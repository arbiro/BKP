import sys
import argparse
import sqlite3
import os


parser = argparse.ArgumentParser(description='Rename headers script')
parser.add_argument('symbolsDB',help='SymbolsDB.db; include the extension')
parser.add_argument('--headerFile',help='Header file', required=False)
parser.add_argument('--path', help='Source path', required=False)
parser.add_argument('--destination', help='Destination', required=False)
args = parser.parse_args()

symbolsDB = args.symbolsDB
headerFile = args.headerFile
path = args.path
destination = args.destination

if (headerFile and path and destination):
    print("Error, either use a headerfile or a path destination combination")
    sys.exit(1)

def normalizePath(path):
    return path.replace("\\\\", "/").replace( "\\", "/").replace("//", "/").replace("/./","/")


def getInclusionLine(source_id, header_id):
    sqlstring = "SELECT line FROM Inclusions WHERE source=={source_id} AND " \
            "target == {header_id}".format(**locals())

    cursor = conn.cursor()
    return cursor.execute(sqlstring)

def getFileId(path):
    try:
        paths = []
        sqlstring = """SELECT Files.id FROM Files WHERE path LIKE '%%%s'""" % path
        cursor = conn.cursor()
        return cursor.execute(sqlstring).fetchone()[0]
    except Exception as e:
        return None

def updateFilePath(file_id, path):
    paths = []
    sqlstring = """UPDATE Files SET path='%s' WHERE id == %s """ % (path, file_id)
    cursor = conn.cursor()
    return cursor.execute(sqlstring)

def getLocations(header, conn):
	paths = []
	sqlstring = """SELECT Files.path FROM Files, Inclusions
				   WHERE Files.id = Inclusions.source AND
				   Inclusions.target IN (SELECT id FROM Files WHERE path LIKE '%%%s')""" %header
	cursor = conn.cursor()
	cursor.execute(sqlstring)
	for row in cursor:
		paths.append(row[0])
	return paths

def getUsedHeaderPaths(id):
    usedHeaderPaths = []
    sqlstring = """SELECT HeaderPathEntries.path FROM HeaderPathEntries, UsedHeaderPaths
				   WHERE HeaderPathEntries.id = UsedHeaderPaths.target AND
				   UsedHeaderPaths.source == %s""" %id
    cursor = conn.cursor()
    cursor.execute(sqlstring)
    for row in cursor:
        usedHeaderPaths.append(row[0])
    return usedHeaderPaths

def getRelativeName(path, usedHeaderPaths):
    for usedHeaderPath in usedHeaderPaths:
        if path.startswith(usedHeaderPath+"/"):
            return path[len(usedHeaderPath)+1:]
    return None


def shouldAlterInclude(file):
    return file.endswith((".h", ".hpp", ".cpp", ".cxx"))

def isHeader(file):
    return file.endswith((".h", ".hpp"))

def replaceName(file, headerId, oldName, newName):
    try:
        print("Updating include for " + oldName + " in " + file + "\n")
        if (shouldAlterInclude(file)):
            fileid = getFileId(file)
            usedHeaderPaths = getUsedHeaderPaths(fileid)
            oldNameRel = getRelativeName(oldName, usedHeaderPaths)
            newNameRel = getRelativeName(newName, usedHeaderPaths)
            if oldNameRel == None:
                print("Error: Can't find " + oldName + "  in HeaderPathEntries! Skipping")
                return False
            if newNameRel == None:
                print("Error: Can't find " + newNameRel + " in HeaderPathEntries! Skipping")
                return False

            if (fileid != None):
                cursor = getInclusionLine(fileid, headerId).fetchall()
                lineToModify = cursor[0][0]
                counter = 0
                with open(file, "r") as src:
                    lines = src.readlines()

                with open(file, "w") as dst:
                    for line in lines:
                        counter += 1
                        if counter == lineToModify:
                            dst.write("#include \"" + newNameRel + "\"\n")
                        else:
                            dst.write(line)
        return True
    except Exception as e:
        print("No include replace done in "+ file +" for "+oldName +"\n")


import glob
import os, errno

def moveHeader(oldName, newName):
    try:
        head, tail = os.path.split(newName)
        try:
            os.makedirs(head)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
        os.rename(oldName, newName)
        headerFileId = getFileId(oldName)
        if (headerFileId != None):
            files = getLocations(oldName, conn)
            for file in files:
                replaceName(file, headerFileId, oldName, newName)
            updateFilePath(headerFileId, newName)
        else:
            print("Header " + oldName +" not found in symbols db")
    except Exception as e:
        print(e)

conn = sqlite3.connect(symbolsDB)
if headerFile:
    with open(headerFile) as f:
        for line in f:
            oldName, newName = line.split(" ")
            moveHeader(normalizePath(oldName), normalizePath(newName))
else:
    if os.path.isfile(path) and not os.path.isdir(destination):
        moveHeader(normalizePath(path), normalizePath(destination))
    elif os.path.isdir(path) and os.path.isdir(destination):
        files = glob.glob(path + '/**/*.*', recursive=True)
        for file in files:
            oldName = file
            newName = oldName.replace(path, destination)
            moveHeader(normalizePath(oldName), normalizePath(newName))



conn.commit()
conn.close()
