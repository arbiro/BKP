#include "Module6.h"
#include "Module5.h"

Module6::Module6(Module1 m1, int v) : m_mod1(m1), m_val(v){
}


void Module6::doStuff() {
	int val;
	val = module5_do();
}