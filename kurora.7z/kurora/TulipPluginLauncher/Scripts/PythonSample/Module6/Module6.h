#pragma once
#include "Module1.h"

class Module6
{
	Module1 m_mod1;
	int m_val;

public:
	Module6() {};
	Module6(Module1, int);
	void doStuff();

};