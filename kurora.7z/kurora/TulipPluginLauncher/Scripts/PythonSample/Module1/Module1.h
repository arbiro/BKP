#pragma once
struct Module1 {
	int field;
	void cm() {};
	virtual void vm() {};
	static void sm() {};
};

extern int freeVarWithDef;

