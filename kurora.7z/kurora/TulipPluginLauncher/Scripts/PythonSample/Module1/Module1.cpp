#include "Module1.h"

int freeVarWithDef;

int f_field(struct Module1 *a) {
	return a->field;
}

void f_class_method(struct Module1 *a) {
	a->cm();
}

void f_virual_method(struct Module1 *a) {
	a->vm();
}

void f_static_method() {
	Module1::sm();
}

void g(int) {};

void f_parameter(struct Module1 *a) {
	g(a->field);
}

void f_reference(Module1 &a) {
	g(a.field);
}

void f_direct(Module1 a) {
	g(a.field);
}

int f_freeVarWithDef() {
	return freeVarWithDef;
}


int main() {}

