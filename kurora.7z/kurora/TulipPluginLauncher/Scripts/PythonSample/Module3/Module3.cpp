#include "Module3.h" 

void Module3::doStuff()
{
	//
}