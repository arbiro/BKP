#pragma once

extern int globalVar;

class Module3 {
public:
	Module3():m_val(0) {}
	Module3(int val):m_val(val) {}
	int get() { return m_val; }
	void doStuff();

private:
	int m_val;
};
