#include "Module2.h"

class MODULE4_LINK Module4 {
public:
	void doStuff();
	int getCount();
	void setCount(int);

private:
	BI m_bi;
	int m_count;
};