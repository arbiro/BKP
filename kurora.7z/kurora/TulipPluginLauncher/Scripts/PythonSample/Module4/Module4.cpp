#include "Module4.h"

void Module4::doStuff() {
	m_bi.mi<int>();
}

int Module4::getCount() {
	return m_count;
}

void Module4::setCount(int c) {
	m_count = c;
}