#pragma once
template<typename T>
struct AI {
	void mi() {}
};

struct BI {
	template<typename T>
	void mi() {}
};

template<typename T>
void gi() {}


template<typename T>
struct AD {
	void md();
};

struct BD {
	template<typename T>
	void md();
};

template<typename T>
void gd();