#include "Module2.h"

template<typename T>
void AD<T>::md() {}

template<typename T>
void BD::md() {}

template<typename T>
void gd() {}


void fi(struct AI<int> *a, struct BI *b) {
	a->mi();
	b->mi<int>();
	gi<int>();
}

void fd(struct AD<int> *a, struct BD *b) {
	a->md();
	b->md<int>();
	gd<int>();
}
