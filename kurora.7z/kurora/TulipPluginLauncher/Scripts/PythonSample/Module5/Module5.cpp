#include "Module5.h"

int module5_do() {
	Module4 m4;
	Module3 m3(10);	
	m4.setCount(2);

	m4.doStuff();

	return m3.get() * m4.getCount();
}