#ifndef COMMON_MODULE
#define COMMON_MODULE
extern int g();
#endif
