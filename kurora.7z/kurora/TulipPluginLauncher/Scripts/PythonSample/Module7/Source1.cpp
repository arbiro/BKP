#include "Common.h"
#include "Header1.h"

static int hidden() {
	return g();
}

int f1() {
	return hidden();
}
