#include "Common.h"
#include "Header2.h"

static int hidden() {
	return g();
}

int f2() {
	return hidden();
}
