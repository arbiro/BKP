#include "Header1.h"
#include "Header2.h"

int f() {
	return f1() + f2();
}
