#include "Common.h"

int g() {
	return 5;
}