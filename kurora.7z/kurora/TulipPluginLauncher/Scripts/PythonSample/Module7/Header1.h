
#ifndef MODULE_1
#define MODULE_1
extern int f1();
#endif
