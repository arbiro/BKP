
#ifndef MODULE_2
#define MODULE_2
extern int f2();
#endif
