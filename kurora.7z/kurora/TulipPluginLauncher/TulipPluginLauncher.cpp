#include <tulip/PythonInterpreter.h>
#include <tulip/PluginLibraryLoader.h>
#include <tulip/PluginLoader.h>
#include <tulip/TlpTools.h>
#include <QtCore>
#pragma push_macro("slots")
#undef slots
#include "Python.h"
#pragma pop_macro("slots")
#include <fstream>

using namespace std;


// argv[0] is the executable name, therefore we will skip the first argument when setting the python
// arguments.
static const int NONPYTHONARGV = 1;

static void setPythonArguments(int argc, char **argv) {
  int wargc = argc - NONPYTHONARGV;
  if (wargc > 0) {
    wchar_t **wargv = (wchar_t **)PyMem_Malloc(sizeof(wchar_t *) * wargc);
    for (int i = 0; i < wargc; i++) {
      size_t argsize = mbstowcs(NULL, argv[i + NONPYTHONARGV], 0);
      wargv[i] = (wchar_t *)PyMem_Malloc(sizeof(wchar_t) * (argsize + 1));
      mbstowcs(wargv[i], argv[i + NONPYTHONARGV], argsize + 1);
    }

    PySys_SetArgv(wargc, wargv);

    for (int i = 0; i < wargc; i++)
      PyMem_Free(wargv[i]);
    PyMem_Free(wargv);
  }
}

static void runScript(const std::string &fileName) {
  FILE *PythonScriptFile = fopen(fileName.c_str(), "r");
  if (PythonScriptFile) {
    PyRun_SimpleFile(PythonScriptFile, fileName.c_str());
    fclose(PythonScriptFile);
  }
}

int main(int argc, char *argv[]) {

  QCoreApplication application(argc, argv);
  if (tlp::TulipPluginsPath.empty()) {
    tlp::initTulipLib(TULIP_INCLUDE);
  }

  setPythonArguments(argc, argv);

  std::string pythonPluginsFullPath =
      tlp::TulipLibDir + tlp::PythonInterpreter::pythonPluginsPath.toUtf8().constData();
  tlp::PythonInterpreter::getInstance()->addModuleSearchPath(
      QString::fromStdString(pythonPluginsFullPath), true);

  tlp::PluginLibraryLoader::loadPlugins();

  try {
    if (argv[1] != NULL)
      runScript(argv[1]);
  } catch (const std::exception &e) {
    cerr << "Script execution failed. Error: " << e.what() << endl;
  }
}