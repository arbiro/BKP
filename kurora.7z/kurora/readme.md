# Build documentation

### Linux
1. Install dependencies( tulip, clang, llvm, QT5, and transitive dependencies of the forementioned )
2. create build folder in main folder, enter said folder, run cmake .. ( you might have to provide with -D the path towards things like zlib and path towards llvm)
3. make, sudo make install
