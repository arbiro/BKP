#pragma once

/* MSVC DLL import/export. */
#ifdef _MSC_VER
#pragma warning(disable : 4297)
#ifdef DATABASE_LIB
#define DATABASE_LINK __declspec(dllexport)
#else
#define DATABASE_LINK __declspec(dllimport)
#endif
#else
#define DATABASE_LINK
#endif
