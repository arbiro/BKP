#pragma once

#include <string>
#include <unordered_map>
#include <vector>
#include <memory>
#include <functional>
#include <mutex>

//#include <DataModel.h>

//#include <qprogressbar.h>
#include <DBIterator.h>
#include "DatabaseGlobal.h"

#include <DataModel.h>

class sqlite3;
class sqlite3_stmt;

class DATABASE_LINK Database {
public:
  Database() = default;
  Database(const std::string &dbName);
  ~Database();

  void beginTransaction() const;
  void endTransaction() const;

  int insertNode(const std::string &key, const std::string &demangledName, int fileID, unsigned ln,
                 unsigned col);

  void insertEdge(int sourceID, int targetID, int type);

  int insertFile(const std::string &filePath, const std::string &lastModified, bool isParsed);

  int insertHeaderPathEntry(const std::string &includePath);

  void insertUsedHeaderPathEntry(const int srcId, const int dstId);

  void insertInclusion(const int srcId, const int dstId, const int line);

  int existNode(const std::string &usr) const;
  bool existEdge(int nodeID1, int nodeID2) const;
  int existFile(const std::string &file) const;
  int existHeaderPathEntry(const std::string &path) const;

  std::unordered_map<std::string, std::string> getNode(const std::string &usr) const;
  std::vector<std::unordered_map<std::string, std::string>>
  getOutNodes(const std::string &usr) const;
  std::vector<std::unordered_map<std::string, std::string>>
  getInNodes(const std::string &usr) const;

  void updateNodeInDB(const std::string &usr, int fileID, unsigned ln, unsigned col);

  std::vector<std::string> getParsedFiles() const;
  // std::vector<std::string> getOutdatedNodes(QProgressBar* prog) const;
  int getTotalNodesCount() const;
  int getTotalEdgesCount() const;

  int addNode(const std::string &key, const std::string &demangledName, const std::string path,
              unsigned ln, unsigned col);
  int readSymbol(const std::string &key, Symbol &result);
  void updateNode(const std::string &usr, const std::string &path, unsigned ln, unsigned col);

  bool addEdge(int nodeID1, int nodeID2, LinkType type);
  int addHeaderPathEntry(const std::string &path);
  int addFile(const std::string &filePath, const std::string &lastModified, bool isParsed);

  std::unique_ptr<DBIterator<std::unordered_map<std::string, std::string>>>
  getIteratorOnNodes() const;
  std::unique_ptr<DBIterator<std::unordered_map<std::string, std::string>>>
  getIteratorOnEdges() const;

  const std::map<std::string, int> &getFileIdMap() {
    return fileIdMap;
  }

  void delNode(const std::string &usr);
  void delDefFile(const std::string &usr);
  void delFile(const std::string &file);

private:
  std::map<std::string, int> fileIdMap;
  sqlite3 *db = nullptr;
  sqlite3_stmt *stmtInsertNode;
  sqlite3_stmt *stmtInsertEdge;
  sqlite3_stmt *stmtInsertFile;
  sqlite3_stmt *stmtInsertHeaderPathEntry;
  sqlite3_stmt *stmtInsertHeaderPathEntryUsage;
  sqlite3_stmt *stmtGetNode;
  sqlite3_stmt *stmtReadNode;
  sqlite3_stmt *stmtInsertInclusion;
};

struct DATABASE_LINK FillDatabase {
  explicit FillDatabase(Database &db, std::function<void()> increment = std::function<void()>())
      : m_db(&db), m_incrementFunc(increment) {}
  void operator()(Database *&result, std::pair<std::string, BatchSymbols *> data);

private:
  Database *m_db;
  std::function<void()> m_incrementFunc;
};
