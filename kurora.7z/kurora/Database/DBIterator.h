#ifndef KURORA_DBITERATOR_H_
#define KURORA_DBITERATOR_H_

template <typename T>
struct DBIterator {
  virtual ~DBIterator() {}
  virtual bool operator()(T &) = 0;
};

#endif
