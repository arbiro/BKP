#include "Database.h"

#include <iostream>
#include <sstream>
#include <sqlite3.h>

Database::Database(const std::string &fileName) {
  int rc = sqlite3_open(fileName.c_str(), &db);

  if (rc) {
    std::cerr << "Can't open database " << sqlite3_errmsg(db) << std::endl;
    throw std::runtime_error("Can't open DB");
  }

  /* Execute SQL statement */
  char *errMsg = "";
  char *sql = "CREATE TABLE IF NOT EXISTS Files("
              "id INTEGER    PRIMARY KEY			 ,"
              "path TEXT	UNIQUE	     NOT NULL,"
              "date	DATETIME		 NOT NULL,"
              "parsed BOOLEAN   NOT NULL )";

  rc = sqlite3_exec(db, sql, nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't create table: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  sql = "CREATE TABLE IF NOT EXISTS Nodes("
        "id  INTEGER  PRIMARY KEY           ,"
        "usr            TEXT UNIQUE NOT NULL,"
        "demangled_name TEXT    NOT NULL,"
        "path	          INTEGER         ,"
        "ln             INTEGER NOT NULL,"
        "col            INTEGER NOT NULL)";

  rc = sqlite3_exec(db, sql, nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't create table: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  sql = "CREATE TABLE IF NOT EXISTS Edges("
        "source INTEGER	    NOT NULL,"
        "target INTEGER		NOT NULL,"
        "type   INTEGER     NOT NULL,"
        "PRIMARY KEY (source, target))";
  rc = sqlite3_exec(db, sql, nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't create table: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  sql = "CREATE TABLE IF NOT EXISTS Inclusions("
        "source INTEGER NOT NULL,"
        "target INTEGER NOT NULL,"
        "line INTEGER,"
        "UNIQUE(source, target))";
  rc = sqlite3_exec(db, sql, nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't create table: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  sql = "CREATE TABLE IF NOT EXISTS HeaderPathEntries("
        "id  INTEGER  PRIMARY KEY           ,"
        "path            TEXT UNIQUE NOT NULL)";
  rc = sqlite3_exec(db, sql, nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't create table: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  sql = "CREATE TABLE IF NOT EXISTS UsedHeaderPaths("
        "source INTEGER NOT NULL,"
        "target INTEGER NOT NULL,"
        "UNIQUE(source, target))";
  rc = sqlite3_exec(db, sql, nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't create table: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  std::string sqlStr = "INSERT OR IGNORE INTO Nodes VALUES (NULL, ?, ?, ?, ?, ?)";
  sqlite3_prepare_v2(db, sqlStr.c_str(), (int)sqlStr.size() + 1, &stmtInsertNode, nullptr);

  sqlStr = "INSERT OR IGNORE INTO Edges VALUES (?, ?, ?)";
  sqlite3_prepare_v2(db, sqlStr.c_str(), (int)sqlStr.size() + 1, &stmtInsertEdge, nullptr);

  sqlStr = "INSERT INTO Files VALUES (NULL, ?, ?, ?)";
  sqlite3_prepare_v2(db, sqlStr.c_str(), (int)sqlStr.size() + 1, &stmtInsertFile, nullptr);

  sqlStr = "INSERT OR IGNORE INTO HeaderPathEntries VALUES (NULL, ?)";
  sqlite3_prepare_v2(db, sqlStr.c_str(), (int)sqlStr.size() + 1, &stmtInsertHeaderPathEntry,
                     nullptr);

  sqlStr = "INSERT OR IGNORE INTO UsedHeaderPaths VALUES (?, ?)";
  sqlite3_prepare_v2(db, sqlStr.c_str(), (int)sqlStr.size() + 1, &stmtInsertHeaderPathEntryUsage,
                     nullptr);

  sqlStr = "SELECT id FROM Nodes WHERE usr=?";
  sqlite3_prepare_v2(db, sqlStr.c_str(), (int)sqlStr.size() + 1, &stmtGetNode, nullptr);

  sqlStr = "SELECT Nodes.id, Nodes.demangled_name, Files.path, Nodes.ln, Nodes.col FROM Nodes LEFT "
           "JOIN Files ON Nodes.path = Files.id WHERE usr=?";
  sqlite3_prepare_v2(db, sqlStr.c_str(), (int)sqlStr.size() + 1, &stmtReadNode, nullptr);

  sqlStr = "INSERT OR IGNORE INTO Inclusions VALUES (?, ?, ?)";
  sqlite3_prepare_v2(db, sqlStr.c_str(), (int)sqlStr.size() + 1, &stmtInsertInclusion, nullptr);
}

Database::~Database() {
  sqlite3_finalize(stmtReadNode);
  sqlite3_finalize(stmtGetNode);
  sqlite3_finalize(stmtInsertFile);
  sqlite3_finalize(stmtInsertEdge);
  sqlite3_finalize(stmtInsertNode);
  sqlite3_finalize(stmtInsertInclusion);
  sqlite3_close(db);
}

void Database::beginTransaction() const {
  char *errMsg = "";
  int rc = sqlite3_exec(db, "BEGIN TRANSACTION", nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't start transaction: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
}

void Database::endTransaction() const {
  char *errMsg = "";
  int rc = sqlite3_exec(db, "END TRANSACTION", nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't end transaction: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
}

int Database::insertNode(const std::string &key, const std::string &demangledName, int fileID,
                         unsigned ln, unsigned col) {

  sqlite3_bind_text64(stmtInsertNode, 1, key.c_str(), key.size(), nullptr, SQLITE_UTF8);
  sqlite3_bind_text64(stmtInsertNode, 2, demangledName.c_str(), demangledName.size(), nullptr,
                      SQLITE_UTF8);

  if (fileID < 0) {
    sqlite3_bind_text64(stmtInsertNode, 3, NULL, NULL, nullptr, SQLITE_UTF8);
  } else {
    sqlite3_bind_int64(stmtInsertNode, 3, fileID);
  }
  sqlite3_bind_int64(stmtInsertNode, 4, ln);
  sqlite3_bind_int64(stmtInsertNode, 5, col);

  int rc = sqlite3_step(stmtInsertNode);

  if (rc != SQLITE_DONE) {
    std::cerr << "Can't insert node: " << sqlite3_errmsg(db) << std::endl;
  }
  int id = sqlite3_last_insert_rowid(db);
  // std::cout << "DB insert " << id << " = " << key << std::endl;
  sqlite3_reset(stmtInsertNode);
  return id;
}

void Database::insertEdge(int sourceID, int targetID, int type) {
  sqlite3_bind_int64(stmtInsertEdge, 1, sourceID);
  sqlite3_bind_int64(stmtInsertEdge, 2, targetID);
  sqlite3_bind_int64(stmtInsertEdge, 3, type);

  int rc = sqlite3_step(stmtInsertEdge);

  if (rc != SQLITE_DONE) {
    std::cerr << "Can't insert edge: " << sqlite3_errmsg(db) << std::endl;
  }

  sqlite3_reset(stmtInsertEdge);
  // std::cout << "DB insert edge " << sourceID << " -> " << targetID << " type " << type <<
  // std::endl;
}

static bool replaceString(std::string &str, const std::string &src, const std::string &dst) {
  auto found = str.find(src);
  if (found == std::string::npos) {
    return false;
  }
  str.replace(found, src.size(), dst);
  return true;
}

static std::string normalizePath(std::string filePath) {
  while (replaceString(filePath, "\\\\", "/"))
    ;
  while (replaceString(filePath, "\\", "/"))
    ;
  while (replaceString(filePath, "//", "/"))
    ;
  while (replaceString(filePath, "/./", "/"))
    ;
  return filePath;
}

static std::string getLastModifiedDate(const std::string &filePath) {
  return "";
}

int Database::insertFile(const std::string &filePath, const std::string &lastModified,
                         bool isParsed) {
  if (filePath.size() == 0) {
    std::cerr << "Empty file name! " << std::endl;
  }

  sqlite3_bind_text64(stmtInsertFile, 1, filePath.c_str(), filePath.size(), nullptr, SQLITE_UTF8);
  sqlite3_bind_text64(stmtInsertFile, 2, lastModified.c_str(), lastModified.size(), nullptr,
                      SQLITE_UTF8);
  sqlite3_bind_int64(stmtInsertFile, 3, isParsed);

  int rc = sqlite3_step(stmtInsertFile);

  if (rc != SQLITE_DONE) {
    std::cerr << "Can't insert file: " << sqlite3_errmsg(db) << std::endl;
  }

  sqlite3_reset(stmtInsertFile);

  return sqlite3_last_insert_rowid(db);
}

int Database::addHeaderPathEntry(const std::string &path) {
  int pathID = existHeaderPathEntry(path);
  if (!path.empty() && pathID < 0) {
    pathID = insertHeaderPathEntry(path);
  }

  return pathID;
}

int Database::insertHeaderPathEntry(const std::string &fpath) {
  std::string path = normalizePath(fpath);
  if (path.size() == 0) {
    std::cerr << "Empty include path! " << std::endl;
  }

  sqlite3_bind_text64(stmtInsertHeaderPathEntry, 1, path.c_str(), path.size(), nullptr,
                      SQLITE_UTF8);

  int rc = sqlite3_step(stmtInsertHeaderPathEntry);

  if (rc != SQLITE_DONE) {
    std::cerr << "Can't insert header path entry: " << sqlite3_errmsg(db) << std::endl;
  }

  sqlite3_reset(stmtInsertHeaderPathEntry);

  return sqlite3_last_insert_rowid(db);
}

void Database::insertUsedHeaderPathEntry(const int srcId, const int dstId) {
  if (srcId == 0 || dstId == 0) {
    return;
  }
  sqlite3_bind_int64(stmtInsertHeaderPathEntryUsage, 1, srcId);
  sqlite3_bind_int64(stmtInsertHeaderPathEntryUsage, 2, dstId);

  int rc = sqlite3_step(stmtInsertHeaderPathEntryUsage);

  if (rc != SQLITE_DONE) {
    std::cerr << "Can't insert used header path entry: " << sqlite3_errmsg(db) << std::endl;
  }

  sqlite3_reset(stmtInsertHeaderPathEntryUsage);
}

int Database::existNode(const std::string &usr) const {
  sqlite3_bind_text64(stmtGetNode, 1, usr.c_str(), usr.size(), nullptr, SQLITE_UTF8);

  int rc = sqlite3_step(stmtGetNode);
  int result;
  switch (rc) {
  case SQLITE_ROW:
    result = sqlite3_column_int(stmtGetNode, 0);
    break;
  default:
    std::cerr << "Can't getNode: " << sqlite3_errmsg(db) << std::endl;
  case SQLITE_DONE:
    result = -1;
  }
  sqlite3_reset(stmtGetNode);
  return result;
}

namespace {
const char *toCString(const unsigned char *value) {
  const char *result = reinterpret_cast<const char *>(value);
  return value == nullptr ? "" : result;
}

class NodeIterator : public DBIterator<std::unordered_map<std::string, std::string>> {
  sqlite3 *db;
  sqlite3_stmt *stmt;

public:
  NodeIterator(sqlite3 *db) : db(db), stmt(nullptr) {
    std::string sql = "SELECT Nodes.id, Nodes.usr, Nodes.demangled_name, Files.path, Nodes.ln, "
                      "Nodes.col FROM Nodes LEFT JOIN Files ON Nodes.path = Files.id";
    int err = sqlite3_prepare_v2(db, sql.c_str(), sql.size() + 1, &stmt, nullptr);
    if (err != SQLITE_OK) {
      std::cerr << "Can't initialize iterator: " << sqlite3_errmsg(db) << std::endl;
    }
  }
  ~NodeIterator() {
    int err = sqlite3_finalize(stmt);
    if (err != SQLITE_OK) {
      std::cerr << "Can't finalize iterator: " << sqlite3_errmsg(db) << std::endl;
    }
  }

  bool operator()(std::unordered_map<std::string, std::string> &nodeInfo) override {
    int rc = sqlite3_step(stmt);
    if (rc == SQLITE_ROW) {
      int count = sqlite3_column_count(stmt);
      nodeInfo.clear();
      for (int i = 0; i < count; ++i) {
        nodeInfo.insert(std::make_pair(std::string(sqlite3_column_name(stmt, i)),
                                       std::string(toCString(sqlite3_column_text(stmt, i)))));
      }
      return true;
    } else if (rc == SQLITE_DONE) {
      return false;
    } else {
      std::cerr << "Can't retrieve node iterator row: " << sqlite3_errmsg(db) << std::endl;
      return false;
    }
  }
};
class EdgeIterator : public DBIterator<std::unordered_map<std::string, std::string>> {
  sqlite3 *db;
  sqlite3_stmt *stmt;

public:
  EdgeIterator(sqlite3 *db) : db(db), stmt(nullptr) {

    std::string sql = "SELECT Edges.source, Edges.target , Edges.type FROM Edges";

    int err = sqlite3_prepare_v2(db, sql.c_str(), sql.size() + 1, &stmt, nullptr);
    if (err != SQLITE_OK) {
      std::cerr << "Can't initialize iterator: " << sqlite3_errmsg(db) << std::endl;
    }
  }
  ~EdgeIterator() {
    int err = sqlite3_finalize(stmt);
    if (err != SQLITE_OK) {
      std::cerr << "Can't finalize iterator: " << sqlite3_errmsg(db) << std::endl;
    }
  }

  bool operator()(std::unordered_map<std::string, std::string> &nodeInfo) override {
    int rc = sqlite3_step(stmt);
    if (rc == SQLITE_ROW) {
      int count = sqlite3_column_count(stmt);
      nodeInfo.clear();
      for (int i = 0; i < count; ++i) {
        nodeInfo.insert(std::make_pair(std::string(sqlite3_column_name(stmt, i)),
                                       std::string(toCString(sqlite3_column_text(stmt, i)))));
      }
      return true;
    } else if (rc == SQLITE_DONE) {
      return false;
    } else {
      std::cerr << "Can't retrieve edge iterator row: " << sqlite3_errmsg(db) << std::endl;
      return false;
    }
  }
};
} // namespace

std::unique_ptr<DBIterator<std::unordered_map<std::string, std::string>>>
Database::getIteratorOnNodes() const {
  return std::unique_ptr<DBIterator<std::unordered_map<std::string, std::string>>>(
      new NodeIterator(db));
}

std::unique_ptr<DBIterator<std::unordered_map<std::string, std::string>>>
Database::getIteratorOnEdges() const {
  return std::unique_ptr<DBIterator<std::unordered_map<std::string, std::string>>>(
      new EdgeIterator(db));
}

bool Database::existEdge(int nodeID1, int nodeID2) const {
  std::string sql = "SELECT EXISTS(SELECT 1 FROM Edges WHERE source=" + std::to_string(nodeID1) +
                    " AND target=" + std::to_string(nodeID2) + " LIMIT 1)";

  bool exist = false;
  char *errMsg = "";
  int rc = sqlite3_exec(db, sql.c_str(),
                        [](void *data, int argc, char **argv, char **azColName) {
                          bool *exist = static_cast<bool *>(data);
                          std::istringstream(argv[0]) >> *exist;
                          return 0;
                        },
                        &exist, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't check if edge exists: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  return exist;
}

int Database::existFile(const std::string &file) const {
  std::string sql = "SELECT id FROM Files WHERE path='" + normalizePath(file) + "' LIMIT 1";

  int id = -1;
  char *errMsg = "";
  int rc = sqlite3_exec(db, sql.c_str(),
                        [](void *data, int argc, char **argv, char **azColName) {
                          int *id = static_cast<int *>(data);
                          if (argc > 0) {
                            *id = atoi(argv[0]);
                          }
                          return 0;
                        },
                        &id, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't check if file exists: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  return id;
}

int Database::existHeaderPathEntry(const std::string &path) const {
  std::string sql =
      "SELECT id FROM HeaderPathEntries WHERE path='" + normalizePath(path) + "' LIMIT 1";

  int id = -1;
  char *errMsg = "";
  int rc = sqlite3_exec(db, sql.c_str(),
                        [](void *data, int argc, char **argv, char **azColName) {
                          int *id = static_cast<int *>(data);
                          if (argc > 0) {
                            *id = atoi(argv[0]);
                          }
                          return 0;
                        },
                        &id, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't check if file exists: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  return id;
}

std::unordered_map<std::string, std::string> Database::getNode(const std::string &usr) const {
  std::string sql = "SELECT Nodes.usr, Nodes.demangled_name, Files.path, Nodes.ln, Nodes.col FROM "
                    "Nodes LEFT JOIN FILES ON Nodes.path = Files.id WHERE usr='" +
                    usr + "' LIMIT 1";

  std::unordered_map<std::string, std::string> props;
  char *errMsg = "";
  int rc = sqlite3_exec(db, sql.c_str(),
                        [](void *data, int argc, char **argv, char **azColName) {
                          std::unordered_map<std::string, std::string> *props =
                              static_cast<std::unordered_map<std::string, std::string> *>(data);
                          for (int i = 0; i < argc; i++) {
                            props->insert({std::string(azColName[i]),
                                           argv[i] == NULL ? std::string() : std::string(argv[i])});
                          }
                          return 0;
                        },
                        &props, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't select node: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }

  return props;
}

std::vector<std::unordered_map<std::string, std::string>>
Database::getOutNodes(const std::string &usr) const {
  std::string sql = "SELECT TargetNode.usr AS target, Edges.path, Edges.ln, Edges.col "
                    "FROM Edges "
                    "INNER JOIN Nodes AS SourceNode ON SourceNode.id = Edges.source "
                    "INNER JOIN Nodes AS TargetNode ON TargetNode.id = Edges.target "
                    "WHERE SourceNode.usr = '" +
                    usr + "'";

  std::vector<std::unordered_map<std::string, std::string>> props;
  char *errMsg = "";
  int rc = sqlite3_exec(
      db, sql.c_str(),
      [](void *data, int argc, char **argv, char **azColName) {
        std::vector<std::unordered_map<std::string, std::string>> *nodes =
            static_cast<std::vector<std::unordered_map<std::string, std::string>> *>(data);
        std::unordered_map<std::string, std::string> prop;
        for (int i = 0; i < argc; i++) {
          prop.insert(
              {std::string(azColName[i]), argv[i] == NULL ? std::string() : std::string(argv[i])});
        }
        nodes->push_back(prop);
        return 0;
      },
      &props, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't select node: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
  return props;
}

std::vector<std::unordered_map<std::string, std::string>>
Database::getInNodes(const std::string &usr) const {
  std::string sql = "SELECT SourceNode.usr AS source "
                    "FROM Edges "
                    "INNER JOIN Nodes AS SourceNode ON SourceNode.id = Edges.source "
                    "INNER JOIN Nodes AS TargetNode ON TargetNode.id = Edges.target "
                    "WHERE TargetNode.usr = '" +
                    usr + "'";

  std::vector<std::unordered_map<std::string, std::string>> props;
  char *errMsg = "";
  int rc = sqlite3_exec(
      db, sql.c_str(),
      [](void *data, int argc, char **argv, char **azColName) {
        std::vector<std::unordered_map<std::string, std::string>> *nodes =
            static_cast<std::vector<std::unordered_map<std::string, std::string>> *>(data);
        std::unordered_map<std::string, std::string> prop;
        for (int i = 0; i < argc; i++) {
          prop.insert(
              {std::string(azColName[i]), argv[i] == NULL ? std::string() : std::string(argv[i])});
        }
        nodes->push_back(prop);
        return 0;
      },
      &props, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't select node: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
  return props;
}

void Database::updateNodeInDB(const std::string &usr, int fileID, unsigned ln, unsigned col) {
  std::string sql = "UPDATE Nodes SET path =  " + std::to_string(fileID) +
                    ", ln = " + std::to_string(ln) + ", col = " + std::to_string(col) +
                    " WHERE id = " + std::to_string(existNode(usr));

  char *errMsg = "";
  int rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't update node: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
}

std::vector<std::string> Database::getParsedFiles() const {

  std::string sql = "SELECT path FROM Files WHERE parsed = 1";
  char *errMsg = "";
  std::vector<std::string> files;

  int rc = sqlite3_exec(db, sql.c_str(),
                        [](void *data, int argc, char **argv, char **azColName) {
                          std::vector<std::string> *files =
                              static_cast<std::vector<std::string> *>(data);
                          files->push_back(argv[0]);
                          return 0;
                        },
                        &files, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't get parsed files: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
  return files;
}

int Database::addNode(const std::string &key, const std::string &demangledName, std::string path,
                      unsigned ln, unsigned col) {
  path = normalizePath(path);
  Symbol dbVersion(key);
  int foundRowId = readSymbol(key, dbVersion);
  if (foundRowId > 0) {
    const Location &loc = dbVersion.location();
    if (loc.path() != path || loc.offset().ln() != ln || loc.offset().col() != col) {
      std::cerr << "Definition location different " << key << " " << loc.path() << " ("
                << loc.offset().ln() << ":" << loc.offset().col() << ") " << path << " (" << ln
                << "," << col << ")" << std::endl;
    }
    return foundRowId;
  }
  int fileID = addFile(path, getLastModifiedDate(path), false);

  return insertNode(key, demangledName, fileID, ln, col);
}

int Database::addFile(const std::string &filePath, const std::string &lastModified, bool isParsed) {
  int fileID = existFile(filePath);
  if (!filePath.empty() && fileID < 0) {
    fileID = insertFile(filePath, getLastModifiedDate(filePath), false);
    fileIdMap[filePath] = fileID;
  }
  return fileID;
}

int Database::readSymbol(const std::string &usr, Symbol &result) {
  sqlite3_bind_text64(stmtReadNode, 1, usr.c_str(), usr.size(), nullptr, SQLITE_UTF8);

  int rc = sqlite3_step(stmtReadNode);
  int rowId = 0;
  switch (rc) {
  case SQLITE_ROW:
    result.setDemangled(std::string(toCString(sqlite3_column_text(stmtReadNode, 1))));
    result.setLocation(Location(std::string(toCString(sqlite3_column_text(stmtReadNode, 2))),
                                sqlite3_column_int(stmtReadNode, 3),
                                sqlite3_column_int(stmtReadNode, 4)));
    rowId = sqlite3_column_int(stmtReadNode, 0);
    ;
    break;
  default:
    std::cerr << "Can't getNode: " << sqlite3_errmsg(db) << std::endl;
  case SQLITE_DONE:
    break;
  }
  // TODO: use RAII to reset the stmt
  sqlite3_reset(stmtReadNode);
  return rowId;
}

void Database::updateNode(const std::string &usr, const std::string &path, unsigned ln,
                          unsigned col) {
  int fileID = addFile(path, getLastModifiedDate(path), false);

  updateNodeInDB(usr, fileID, ln, col);
}

bool Database::addEdge(int nodeID1, int nodeID2, LinkType type) {
  if (nodeID1 == nodeID2 || existEdge(nodeID1, nodeID2)) {
    return false;
  }
  insertEdge(nodeID1, nodeID2, type.getValue());
  return true;
}

void Database::delNode(const std::string &usr) {
  std::string sql = "DELETE FROM Nodes WHERE usr = '" + usr + "'";

  char *errMsg = "";
  int rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't delete Node: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
}

void Database::delDefFile(const std::string &usr) {
  std::string sql =
      "DELETE FROM Files WHERE id IN (SELECT path FROM Nodes WHERE  Nodes.usr = '" + usr + "')";

  char *errMsg = "";
  int rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't delete defintion file: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
}

void Database::delFile(const std::string &file) {
  std::string sql = "DELETE FROM Files WHERE path = '" + file + "'";

  char *errMsg = "";
  int rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't delete File: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
}

int Database::getTotalNodesCount() const {
  int nodesCount = 0;
  char *errMsg = "";
  std::string sql = "SELECT COUNT(*) FROM Nodes";
  int rc = sqlite3_exec(db, sql.c_str(),
                        [](void *data, int argc, char **argv, char **azColName) {
                          int *maxProg = static_cast<int *>(data);
                          *maxProg = std::stoi(argv[0]);
                          return 0;
                        },
                        &nodesCount, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't count nodes: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
  return nodesCount;
}
int Database::getTotalEdgesCount() const {
  int edgesCount = 0;
  char *errMsg = "";
  std::string sql = "SELECT COUNT(*) FROM Edges";
  int rc = sqlite3_exec(db, sql.c_str(),
                        [](void *data, int argc, char **argv, char **azColName) {
                          int *maxProg = static_cast<int *>(data);
                          *maxProg = std::stoi(argv[0]);
                          return 0;
                        },
                        &edgesCount, &errMsg);

  if (rc != SQLITE_OK) {
    std::cerr << "Can't count edges: " << errMsg << std::endl;
    sqlite3_free(errMsg);
  }
  return edgesCount;
}

void Database::insertInclusion(const int srcId, const int dstId, const int line) {
  if (srcId == 0 || dstId == 0) {
    return;
  }
  sqlite3_bind_int64(stmtInsertInclusion, 1, srcId);
  sqlite3_bind_int64(stmtInsertInclusion, 2, dstId);
  if (line != -1) {
    sqlite3_bind_int64(stmtInsertInclusion, 3, line);
  }

  int rc = sqlite3_step(stmtInsertInclusion);

  if (rc != SQLITE_DONE) {
    std::cerr << "Can't insert node: " << sqlite3_errmsg(db) << std::endl;
  }

  sqlite3_reset(stmtInsertInclusion);
}

void FillDatabase::operator()(Database *&result, std::pair<std::string, BatchSymbols *> data) {
  std::unique_ptr<BatchSymbols> batch(data.second);
  if (!batch) {
    return;
  }

  std::unordered_map<Symbol *, int> symbolMap;
  // Export all symbols
  m_db->beginTransaction();
  for (const auto &symbolIt : batch->symbols()) {
    int id = m_db->addNode(
        symbolIt.first, symbolIt.second->demangled(), symbolIt.second->location().path(),
        symbolIt.second->location().offset().ln(), symbolIt.second->location().offset().col());
    symbolMap.insert({symbolIt.second.get(), id});
  }
  m_db->endTransaction();

  // Export all links
  m_db->beginTransaction();
  for (const auto &symbolIt : batch->symbols()) {
    for (const auto &linkIt : symbolIt.second->links()) {
      if (&linkIt->src == symbolIt.second.get()) {
        auto srcFound = symbolMap.find(&linkIt->src);
        auto trgFound = symbolMap.find(&linkIt->trg);
        if (srcFound != symbolMap.end() && trgFound != symbolMap.end()) {
          m_db->insertEdge(srcFound->second, trgFound->second, linkIt->type.getValue());
        }
      }
    }
  }
  m_db->endTransaction();

  // Export all inclusions
  auto inclusionMap = data.second->getInclusion();
  auto fileIdMap = m_db->getFileIdMap();
  m_db->beginTransaction();
  for (auto it = inclusionMap.begin(); it != inclusionMap.end(); it++) {
    int from = m_db->addFile(it->first, "", false);
    for (int i = 0; i < it->second.includeDirectives.size(); i++) {
      int to = m_db->addFile(it->second.includeDirectives[i].first, "", false);
      m_db->insertInclusion(from, to, it->second.includeDirectives[i].second);
    }
    for (auto &headerPath : it->second.headerSearchEntries) {
      int headerPathEntryId = m_db->addHeaderPathEntry(headerPath);
      m_db->insertUsedHeaderPathEntry(from, headerPathEntryId);
    }
  }
  m_db->endTransaction();

  result = m_db;
  if (m_incrementFunc)
    m_incrementFunc();
}
