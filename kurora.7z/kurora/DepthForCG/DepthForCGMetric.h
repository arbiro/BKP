#ifndef _DEPTH_FOR_CG_METRIC_H
#define _DEPTH_FOR_CG_METRIC_H

#include <stack>

#include <tulip/DoubleProperty.h>
#include <tulip/StaticProperty.h>

/** \addtogroup metric */

/** This plugins compute for each node n, the maximum path-length between n and the other nodes.
 *  The graph can be acyclic.
 *
 *  \note This algorithm works on general graphs.
 *
 */
class DepthForCGMetric : public tlp::DoubleAlgorithm {
public:
  PLUGININFORMATION("DepthForCG", "Murex", "10/01/2018",
                    "For each node n on an acyclic graph,"
                    "it computes the maximum path length between n and the other node."
                    "",
                    "1.0", "Hierarchical")
  DepthForCGMetric(const tlp::PluginContext *context);
  bool run();
  bool check(std::string &);

private:
  std::unique_ptr<tlp::NodeStaticProperty<int>> minNums;
  std::stack<tlp::node> componentStack;
  std::vector<int> depth;
  int num;
  int strongComponent(const tlp::node n);
};

#endif
