#include <stack>
#include <memory>
#include <algorithm>

#include "DepthForCGMetric.h"
#include <tulip/ForEach.h>

PLUGIN(DepthForCGMetric)

using namespace tlp;

DepthForCGMetric::DepthForCGMetric(const tlp::PluginContext *context) : DoubleAlgorithm(context) {}

/* minNums convention:
  x > 0 : x is distance from the root in the component algorithm
  x < 0 : x is component index
*/

//=================================================
int DepthForCGMetric::strongComponent(tlp::node current) {
  int minNum = minNums->getNodeValue(current);
  if (minNum != 0)
    return minNum;
  componentStack.push(current);
  num++;
  int myNum = num;
  minNum = myNum;
  minNums->setNodeValue(current, minNum);

  int maxDepth = 0;
  std::unique_ptr<Iterator<tlp::node>> iter(graph->getOutNodes(current));
  while (iter->hasNext()) {
    int childNum = strongComponent(iter->next());
    if (childNum < 0) {
      // the child is a root of another component
      int componentIdx = -1 - childNum;
      maxDepth = std::max(maxDepth, depth[componentIdx] + 1);
    } else {
      if (childNum < minNum) {
        minNum = childNum;
      }
    }
  }
  if (minNum == myNum) {
    // It is the root node of the component
    depth.push_back(maxDepth);
    minNum = -depth.size();
    while (componentStack.top() != current) {
      tlp::node top = componentStack.top();
      componentStack.pop();
      minNums->setNodeValue(top, minNum);
    }
    componentStack.pop();
  }
  minNums->setNodeValue(current, minNum);
  return minNum;
}
//====================================================================
bool DepthForCGMetric::run() {
  result->setAllEdgeValue(0);
  result->setAllNodeValue(0);
  num = 0;
  minNums = std::unique_ptr<tlp::NodeStaticProperty<int>>(new tlp::NodeStaticProperty<int>(graph));
  node n;
  forEach (n, graph->getNodes()) {
    int componentIdx = -1 - strongComponent(n);
    result->setNodeValue(n, depth[componentIdx]);
  }
  minNums.reset();
  depth.clear();
  return true;
}
//=================================================
bool DepthForCGMetric::check(std::string &erreurMsg) {
  return true;
}
//=================================================
