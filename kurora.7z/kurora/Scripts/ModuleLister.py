import sys
import os
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from multiprocessing import Pool
from collections import defaultdict
sys.path.append(os.path.dirname(__file__))
import argparse
__author__ = 'Murex'

CALLS = 1;

def parseArguments():
    parser = argparse.ArgumentParser(description='List modules used by module')
    parser.add_argument('symbolsDB',help='SymbolsDB')
    parser.add_argument('mappingFile',help='Mapping File')
    parser.add_argument('moduleName',help='moduleName')
    parser.add_argument('-prefixdepth', dest='prefixdepth', help='Depth to remove in the path''s prefix', required=False, type=int, const=2, default=2, nargs='?')
    parser.add_argument('-is', dest='interfaceSize', help='Interface size', required=False, action='store_true')
    parser.add_argument('-cs', dest='callSize', help='Calling size', required=False, action='store_true')
    parser.add_argument('-d', dest='details', help='Details', required=False, action='store_true')
    parser.add_argument('-u', dest='use', help='List modules which use module', required=False, action='store_true')
    args = parser.parse_args()
    return args

class NodeDetails:
    def __init__(self, node, filePaths):
        self.nodeId = node
        self.properties = {}
        self.properties["demangledName"] = node.demangled_name
        self.properties["Path"] = filePaths[node.path]
        self.properties["Ln"] = node.ln

    def printProperties(self):
        print("\tDemangled name: ", self.properties["demangledName"])
        print("\tFile: ", self.properties["Path"])
        print("\tLine: ", self.properties["Ln"])

class Result:
    def __init__(self, name, dependenciesDic, filePaths):
        self.moduleName = name
        self.filePaths = filePaths
        self.callSize = len(dependenciesDic[name])
        self.interfaceSize = self.setInterfaceSize(dependenciesDic)
        self.detailsList = self.setDetails(dependenciesDic)


    def setInterfaceSize(self, dependenciesDic):
        unique = set()
        for items in dependenciesDic[self.moduleName]:
            unique.add(items[1])
        return len(unique)

    def setDetails(self, dependenciesDic):
        detailsList = []
        for item in dependenciesDic[self.moduleName]:
            detailsList.append((NodeDetails(item[0], self.filePaths), NodeDetails(item[1], self.filePaths)))
        return detailsList

    def printDetails(self):
        for item in self.detailsList:
            print("Source:", item[0].nodeId)
            item[0].printProperties()
            print("Target:", item[1].nodeId)
            item[1].printProperties()


class ModuleLister:
    def __init__(self, symbolsDB, mappingFile, prefixdepth=2):
        #try:
        self.filePaths = {}
        self.mappingFile = mappingFile
        engine = create_engine("sqlite:///" + symbolsDB)
        self.Base = automap_base()
        self.Base.prepare(engine, reflect=True)
        session=Session(engine)
        #Nodes = session.query(Base.classes.Nodes).first()
        self.nodes = session.query(self.Base.classes.Nodes)
        self.files = session.query(self.Base.classes.Files).all()
        self.edges = session.query(self.Base.classes.Edges)
        self.getMappings()
        self.mapModules()
        #except Exception as e:
        #    print(e)
    def getMappings(self):
        with open(self.mappingFile,"r") as f:
            content = f.readlines()
            self.pathModuleMap = { line.split(" ", 1)[0]:line.split(" ", 1)[1].rstrip() for line in content }


    def getModule(self, path):
        for modulePath, moduleName in self.pathModuleMap.items():
            if modulePath in path:
                return moduleName
        return "UNKNOWNMODULE"

    def getFileModulePair(self, file):
        return (file.id,self.getModule(file.path))


    def mapModules(self):
        self.moduleFiles = defaultdict(list)
        self.fileModule = {}
        for file in self.files:
            module = self.getModule(file.path)
            self.moduleFiles[module].append(file.id)
            self.fileModule[file.id] = module
            self.filePaths[file.id] = file.path;

    def addDependecies(self, node, n, currentDeps):
        moduleName = self.fileModule[n.path]
        if moduleName not in currentDeps:
            currentDeps[moduleName] = [(node,n)]
        else:
            currentDeps[moduleName].append((node,n))

    def getDependencies(self, moduleName, use=True):
        dependenciesDic = {}
        filesInModule = self.moduleFiles[moduleName]
        nodesInModule = self.nodes.filter(self.Base.classes.Nodes.path.in_(filesInModule)).all()
        for node in nodesInModule:
            if use:
                 edges = self.edges.filter(self.Base.classes.Edges.source == node.id).filter(self.Base.classes.Edges.type == 1).all()
                 for edge in edges:
                     targetNode = self.nodes.filter(self.Base.classes.Nodes.id == edge.target).first()
                     self.addDependecies(node, targetNode, dependenciesDic)
            else:
                edges = self.edges.filter(self.Base.classes.Edges.target == node.id).filter(self.Base.classes.Edges.type == 1).all()
                for edge in edges:
                    sourceNode = self.nodes.filter(self.Base.classes.Nodes.id == edge.source).first()
                    self.addDependecies(node, sourceNode, dependenciesDic)
        return dependenciesDic


def printResult(result, interfaceSize, callsSize, details):
    print(result.moduleName)
    if callsSize:
        print("CS:", result.callSize)
    if interfaceSize:
        print("IS:", result.interfaceSize)
    if details:
        print("DETAILS:")
        result.printDetails()


def main():
    args = parseArguments()
    moduleLister = ModuleLister(args.symbolsDB, args.mappingFile, args.prefixdepth)
    dependenciesDic = moduleLister.getDependencies(args.moduleName, args.use)

    for name in dependenciesDic:
        result = Result(name, dependenciesDic, moduleLister.filePaths)
        printResult(result, args.interfaceSize, args.callSize, args.details)
    #dependenciesDic = getDependencies(moduleGraph, args.moduleName, args.use)

    #for name in dependenciesDic:
#        result = Result(name, dependenciesDic)
#        printResult(result, args.interfaceSize, args.callSize, args.details)


if __name__ == '__main__':
    main()
