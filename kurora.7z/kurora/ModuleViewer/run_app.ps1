param(
    [switch]$debug = $false,
    [string]$app_host = "0.0.0.0",
    [string]$environment = "production",
    [switch]$help = $false
)

if($help) {
    Write-Host(
"Script used to run the server of the module viewer app.
Parameters:
    -debug : Runs the server in debug mode.
    -app_host : Default value '0.0.0.0'. The ip used to run the app.
    -environment : Default value 'production'. Other valid value is development. Represents the environment in which the app will run.
    -help : Shows this message."
    )
    exit(0)
}

$env:PYTHONPATH="server"
$env:FLASK_APP="server"
$env:FLASK_ENV=$environment
$env:FLASK_DEBUG=$debug

$current_path=$pwd.Path

Set-Location -Path ".\static\dist\"

if(![System.IO.File]::Exists($pwd.Path + "\\bundle.js") -Or ![System.IO.File]::Exists($pwd.Path + "\\styles.css")) {
    Set-Location -Path "..\"
    npm run build
}

Set-Location -Path $current_path

.\flask_env\Scripts\activate.ps1
flask run --host=$app_host