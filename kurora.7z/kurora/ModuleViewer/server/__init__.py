from flask import Flask, render_template, jsonify, request
from ModuleLister import process

app = Flask(__name__, static_folder='../static/dist', template_folder='../static/templates')


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/getModuleList')
def getModuleList():
    fileList = [line.split(" ")[1] for line in open("D:/Kurora/ModuleMapping.txt", "r")]
    return jsonify(fileList)


@app.route('/getModuleInfo/<path:moduleName>')
def getModuleInfo(moduleName : str):
    details = request.args.get('details') == 'true'
    use = request.args.get('use') == 'true'

    result = process(
        moduleName,
        details,
        use
    )

    return jsonify(result)


if __name__ == '__main__':
    app.run()
