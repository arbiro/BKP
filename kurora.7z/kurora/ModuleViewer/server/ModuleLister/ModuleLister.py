import sys
import os
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from collections import defaultdict

sys.path.append(os.path.dirname(__file__))
__author__ = 'Murex'


class NodeDetails:
    def __init__(self, node, filePaths):
        self.nodeId = node.id
        self.properties = {}
        self.properties["demangledName"] = node.demangled_name
        self.properties["Path"] = filePaths[node.path]
        self.properties["Ln"] = node.ln

    def getProperties(self):
        return self.properties


class Result:
    def __init__(self, name, dependenciesDic, filePaths):
        self.moduleName = name
        self.filePaths = filePaths
        self.callSize = len(dependenciesDic[name])
        self.interfaceSize = self.setInterfaceSize(dependenciesDic)
        self.detailsList = self.setDetails(dependenciesDic)


    def setInterfaceSize(self, dependenciesDic):
        unique = set()
        for items in dependenciesDic[self.moduleName]:
            unique.add(items[1])
        return len(unique)

    def setDetails(self, dependenciesDic):
        detailsList = []
        for item in dependenciesDic[self.moduleName]:
            detailsList.append((NodeDetails(item[0], self.filePaths), NodeDetails(item[1], self.filePaths)))
        return detailsList

    def getDetails(self):
        result = []
        for item in self.detailsList:
            itemResult = {}
            itemResult['Source'] = [item[0].nodeId, item[0].getProperties()]
            itemResult['Target'] = [item[1].nodeId, item[1].getProperties()]
            result.append(itemResult)
        
        return result


class ModuleLister:
    def __init__(self, symbolsDB, mappingFile):
        self.filePaths = {}
        self.mappingFile = mappingFile
        engine = create_engine("sqlite:///" + symbolsDB + "?check_same_thread=False")
        self.Base = automap_base()
        self.Base.prepare(engine, reflect=True)
        session=Session(engine)
        self.nodes = session.query(self.Base.classes.Nodes)
        self.files = session.query(self.Base.classes.Files).all()
        self.edges = session.query(self.Base.classes.Edges)
        self.getMappings()
        self.mapModules()

    def getMappings(self):
        with open(self.mappingFile,"r") as f:
            content = f.readlines()
            self.pathModuleMap = { line.split(" ", 1)[0]:line.split(" ", 1)[1].rstrip() for line in content }


    def getModule(self, path):
        for modulePath, moduleName in self.pathModuleMap.items():
            if modulePath in path:
                return moduleName
        return "UNKNOWNMODULE"

    def getFileModulePair(self, file):
        return (file.id,self.getModule(file.path))


    def mapModules(self):
        self.moduleFiles = defaultdict(list)
        self.fileModule = {}
        for file in self.files:
            module = self.getModule(file.path)
            self.moduleFiles[module].append(file.id)
            self.fileModule[file.id] = module
            self.filePaths[file.id] = file.path

    def addDependecies(self, node, n, currentDeps):
        moduleName = self.fileModule[n.path]
        if moduleName not in currentDeps:
            currentDeps[moduleName] = [(node,n)]
        else:
            currentDeps[moduleName].append((node,n))

    def getDependencies(self, moduleName, use=True):
        dependenciesDic = {}
        filesInModule = self.moduleFiles[moduleName]
        nodesInModule = self.nodes.filter(self.Base.classes.Nodes.path.in_(filesInModule)).all()
        for node in nodesInModule:
            if use:
                 edges = self.edges.filter(self.Base.classes.Edges.source == node.id).filter(self.Base.classes.Edges.type == 1).all()
                 for edge in edges:
                     targetNode = self.nodes.filter(self.Base.classes.Nodes.id == edge.target).first()
                     self.addDependecies(node, targetNode, dependenciesDic)
            else:
                edges = self.edges.filter(self.Base.classes.Edges.target == node.id).filter(self.Base.classes.Edges.type == 1).all()
                for edge in edges:
                    sourceNode = self.nodes.filter(self.Base.classes.Nodes.id == edge.source).first()
                    self.addDependecies(node, sourceNode, dependenciesDic)
        return dependenciesDic


def getResult(result, interfaceSize, callsSize, details):
    ret = {}
    ret["moduleName"] = result.moduleName
    if callsSize:
        ret["callSize"] = result.callSize
    if interfaceSize:
        ret["interfaceSize"] = result.interfaceSize
    if details:
        ret["details"] = result.getDetails()

    return ret


moduleLister = ModuleLister("D:/Kurora/Database.db","D:/Kurora/ModuleMapping.txt")


def process(moduleName, details=True, use=True, interfaceSize=True, callSize=True):
    dependenciesDic = moduleLister.getDependencies(moduleName, use)

    result = []
    resultMap = {}

    resultMap["use"] = use
    resultMap["details"] = details

    for name in dependenciesDic:
        result.append(getResult(Result(name, dependenciesDic, moduleLister.filePaths), interfaceSize, callSize, details))

    resultMap["modules"] = result

    return resultMap
