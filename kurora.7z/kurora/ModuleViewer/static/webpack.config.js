const ExtractTextPlugin = require('extract-text-webpack-plugin');
const webpack = require('webpack');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

const config = {
    entry:  __dirname + '/js/index.jsx',
    output: {
        path: __dirname + '/dist',
        filename: 'bundle.js',
    },
    resolve: {
        extensions: [".js", ".jsx", ".css"]
    },
    module: {
        loaders: [
            {
            	test: /\.jsx?/,
            	exclude: /node_modules/,
            	use: ['babel-loader']
            },
            {
            	test: /\.jsx?/,
            	exclude: /node_modules/,
            	use: ['eslint-loader']
            },
            {
                test: /\.css$/,
                use: ExtractTextPlugin.extract({
                    fallback: 'style-loader',
                    use: 'css-loader',
                })
            },
            {
                test: /\.(png|svg|jpg|gif|ico)$/,
                loader: 'file-loader?name=[name].[ext]',
            }
        ]
    },
    plugins: [
        new ExtractTextPlugin('styles.css'),
        new UglifyJsPlugin(),
        new webpack.DefinePlugin({
            'process.env.NODE_ENV': JSON.stringify('production')
        }),
        new webpack.optimize.UglifyJsPlugin()
    ]
};

module.exports = config;
