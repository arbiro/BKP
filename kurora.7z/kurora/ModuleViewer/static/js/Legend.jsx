import React from "react";

export default class Legend extends React.Component {
    constructor(props) {
        super(props);
        this.state = {legend : ""};
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        let state = prevState;
        state.legend = "";
        if (nextProps.modules !== undefined) {
            let legend = (
            <fieldset>
                <legend>Legend</legend>
                <ul className="list-group">
                {
                    nextProps.modules.map(function(moduleItem) {
                        return <li className="list-group-item"><span style={{background: moduleItem[1]}}></span>{moduleItem[0]}</li>
                    })
                }
                </ul>
            </fieldset>
            );
            state.legend = legend;
        }

        return state;
    }
    
    render() {
        return (
            <React.Fragment>
                {this.state.legend}
            </React.Fragment>
        );
    }
}