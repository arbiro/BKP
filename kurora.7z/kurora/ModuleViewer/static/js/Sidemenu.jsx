import React from "react";
import {moveSidenav} from "./Apputils"

require('../css/sidemenu.css');
let $ = require('jquery');

export default class Sidemenu extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            searchButton: undefined,
            filterButton: undefined,
            filterContents: "",
            filterOptions: {
                use: true,
                details: true
            }
        };
        

        this.sidemenuToggle = this.sidemenuToggle.bind(this);
        this.searchButton = this.searchButton.bind(this);
        this.filterButton = this.filterButton.bind(this);
        this.toggleFilterMenu = this.toggleFilterMenu.bind(this);
        this.filterChange = this.filterChange.bind(this);
    }

    sidemenuToggle(event) {
        const searchButton = this.searchButton();
        const filterButton = this.filterButton();
        if (this.state.searchButton === undefined) {
            this.state.searchButton = searchButton;
            this.state.filterButton = filterButton;
            this.setState(this.state,
                moveSidenav(event));
        }
        else {
            if (event.target.id != "search-button") {
                return;
            }
            moveSidenav(event);
            setTimeout(() => {
                this.state.searchButton = undefined;
                this.state.filterButton = undefined;
                this.setState(this.state);
            }, 500);
        }
    }

    searchButton() {
        return (
            <span className="fa fa-search fa-4x" id="search-button"></span>
        );
    }

    filterChange(event) {
        let value = $(event.target).is(":checked");
        this.state.filterOptions[$(event.target).val()] = value;
        this.setState(this.state);
    }

    toggleFilterMenu() {
        if (this.state.filterContents == "") {
            this.state.filterContents = (
                <React.Fragment>
                    <li>Details<input type="checkbox" value="details" onChange={this.filterChange} defaultChecked={this.state.filterOptions.details}/></li>
                    <li>Use<input type="checkbox" value="use" onChange={this.filterChange} defaultChecked={this.state.filterOptions.use}/></li>
                </React.Fragment>
            );
        }
        else {
            this.state.filterContents = "";
        }
        this.state.filterButton = this.filterButton();
        this.setState(this.state);
    }

    filterButton() {
        return (
            <div className="filter-container">
                <ul>
                    <li> 
                        <span className="fa fa-filter fa-4x" id="filter-button" onClick={this.toggleFilterMenu}></span>
                    </li>
                    {this.state.filterContents}
                </ul>
            </div>
        );  
    }

    render() {
        return (
            <div className="sidemenu">
                {this.state.searchButton}
                {this.state.filterButton}
            </div>
        );
    }
}