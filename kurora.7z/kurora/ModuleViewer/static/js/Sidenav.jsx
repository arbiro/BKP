import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import { swapLoadingAndApp} from "./Apputils";

require('../css/sidenav.css');
let $ = require('jquery');

export default class Sidenav extends React.Component {
    constructor(props) {
        super(props);
        this.state = {items : '', filteredList : ''};
        this.state.show = true;
        this.app = React.createRef();
        this.processItems = this.processItems.bind(this);
        this.filterItems = this.filterItems.bind(this);
        this.getModuleInfo = this.getModuleInfo.bind(this);
        this.renderItems = this.renderItems.bind(this);

        $.get("/getModuleList", (data) => {
            this.processItems(data);
        });

        ReactDOM.render(
            <App ref={this.app}/>,
            document.getElementById("app")
        );
    }

    processItems(data) {
        this.state.items = data;
        this.setState(this.state);
        this.renderItems(data);
    }

    getModuleInfo(event) {
        event.preventDefault();
        swapLoadingAndApp();
        let module = $(event.target).text();
        let filterOptions = this.app.current.getFilterOptions();

        $.get(
            "/getModuleInfo/" + module,
            {
                use: filterOptions.use,
                details: filterOptions.details
            },
            (data) => {
                this.app.current.displayModuleInfo(data, module);
            }
        );
    }

    renderItems (list) {
        let filteredItems = (
            <ul className="list-group">
            {
                list.map(function(item) {
                    return <li className="list-group-item" onClick={this.getModuleInfo}>{item}</li>
                }, this)
            }
            </ul>
        );
        ReactDOM.render(filteredItems, document.getElementById('module-list')); 
    }

    filterItems(event) {
        event.preventDefault();
        let updatedList = this.state.items;
        updatedList = updatedList.filter((item) => {
            return item.toLowerCase().search(
                event.target.value.toLowerCase()) !== -1;
        });
        this.renderItems(updatedList);       
    }

    keyDownHandler(event) {
        if (event.keyCode == 13) {
            event.preventDefault();
        }
    }

    render () {
        return (
            <form>
                <fieldset className="form-group">
                    <input type="text" className="form-control form-control-lg" placeholder="Search" onChange={this.filterItems} onKeyDown={this.keyDownHandler} />
                </fieldset>
                <div id="module-list" />
            </form>
        );
    }
}
