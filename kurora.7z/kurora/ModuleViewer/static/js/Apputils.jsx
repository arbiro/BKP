let $ = require('jquery');
let randomColor = require('randomcolor');

export function swapLoadingAndApp() {
    let loadingZIndex = $(".loading").css("z-index");
    
    if (loadingZIndex == 20) {
        $(".loading").css("z-index", 10);
        $(".app-contents").css("z-index", 20);
    }
    else {
        $(".loading").css("z-index", 20);
        $(".app-contents").css("z-index", 10);
    }
}

export function moveSidenav(event) {
    let width = $("#sidenav").css("width");
    
    if (width == "250px") {
        $("#sidenav").css("width", "0");
        $("#sidenav + #app .app-container").css("margin-left", "0");
        $("#sidemenu").ready(() => {
            $(".sidemenu").css("opacity", "100");
            $(".sidemenu").css("position", "absolute");
        });
    }
    else {
        if(event.target.id != "search-button") {
            return;
        }
        $("#sidenav").css("width", "250px");
        $("#sidenav + #app .app-container").css("margin-left", "250px");
        $(".sidemenu").css("opacity", "0");
        $(".sidemenu").css("position", "absolute");
    }
}

export function getRandomColor(luminosity='light') {
    return randomColor({
        luminosity: luminosity,
        hue: 'random'
    });
}
