import React from "react";
import Graph from "react-graph-vis";
import { swapLoadingAndApp, getRandomColor } from "./Apputils";
import Legend from "./Legend";
import Sidemenu from "./Sidemenu";

require('../css/app.css');
let $ = require('jquery');

export default class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            graph : {nodes : [], edges : []},
            options : {},
            nodesList : []
        };

        this.sidemenu = React.createRef();

        this.displayModuleInfo = this.displayModuleInfo.bind(this);
        this.getGraphFromJsonReply = this.getGraphFromJsonReply.bind(this);
        this.setNetworkInstance = this.setNetworkInstance.bind(this);
        this.filterNodes = this.filterNodes.bind(this);
        this.keyDownHandler = this.keyDownHandler.bind(this);
        this.sidemenuToggle = this.sidemenuToggle.bind(this);
        this.getFilterOptions = this.getFilterOptions.bind(this);
    }

    getFilterOptions() {
        return this.sidemenu.current.state.filterOptions;
    }

    getGraphWithDetails(modulesMap, mainModule) {
        let nodesMap = {};
        let nodes = []; //[{id : node-id, label: node-display-name}]
        let edges = []; //[{from : source-id, to : destination-id}]
        let mainModuleColor = getRandomColor();
        let modules = [[mainModule, mainModuleColor]];

        modulesMap.forEach((moduleItem) => {
            if(moduleItem.moduleName !== "UNKNOWNMODULE") {
                let moduleColor = undefined;

                if (moduleItem.moduleName.trim() !== mainModule.trim()) {
                    moduleColor = getRandomColor();
                    modules.push([moduleItem.moduleName, moduleColor]);
                }
                else {
                    moduleColor = mainModuleColor;
                }

                moduleItem.details.forEach((item) => {
                    let source = item.Source;
                    let target = item.Target;

                    if (!(source[0] in nodesMap)) {
                        nodesMap[source[0]] = [source[1], mainModuleColor];
                    }

                    if (!(target[0] in nodesMap)) {
                        nodesMap[target[0]] = [target[1], moduleColor];
                    }

                    edges.push({from : source[0], to : target[0]});
                });
            }
        });

        Object.keys(nodesMap).forEach((key) => {
            let value = nodesMap[key];
            nodes.push({
                id : key,
                label : value[0].demangledName.replace(/(.{15})/g, "$1\n"),
                borderWidth: 2,
                color : {
                    background : value[1],
                    highlight : {
                        border : '#990000',
                        background : value[1]
                    }
                }
            });
        });

        return {nodes : nodes, edges : edges, modules : modules};
    }

    getGraphWithNoDetails(modulesMap, mainModule, use) {
        let nodes = []; //[{id : node-id, label: node-display-name}]
        let edges = []; //[{from : source-id, to : destination-id}]
        let mainModuleColor = getRandomColor();
        let modules = [[mainModule, mainModuleColor]];
        let idCounter = 1;

        nodes.push({
            id : 0,
            label : mainModule,
            borderWidth: 2,
            color : {
                background : mainModuleColor,
                highlight : {
                    border : '#990000',
                    background : mainModuleColor
                }
            }
        });

        modulesMap.forEach((moduleItem) => {
            if (moduleItem.moduleName !== "UNKNOWNMODULE") {
                if (moduleItem.moduleName.trim() === mainModule.trim()) {
                    return;
                }
                let moduleColor = getRandomColor();
                modules.push([moduleItem.moduleName, moduleColor]);
                nodes.push({
                    id : idCounter,
                    label : moduleItem.moduleName,
                    borderWidth: 2,
                    color : {
                        background : moduleColor,
                        highlight : {
                            border : '#990000',
                            background : moduleColor
                        }
                    }
                });

                if (use) {
                    edges.push({from: 0, to: idCounter});
                }
                else {
                    edges.push({from: idCounter, to: 0});
                }

                idCounter++;
            }
        });

        return {nodes : nodes, edges : edges, modules : modules};
    }

    getGraphFromJsonReply(data, mainModule) {
        if (data.details) {
            return this.getGraphWithDetails(data.modules, mainModule);
        }
        else {
            return this.getGraphWithNoDetails(data.modules, mainModule, data.use);
        }
    }

    setNetworkInstance (nw) {
        this.state.network = nw;
    }

    displayModuleInfo (data, mainModule) {
        let nodes = [];
        let id = 1;

        this.state.modules  = undefined;
        this.state.graph    = {
            nodes : [],
            edges : []
        };
        this.state.options  = {};
        this.setState(this.state);

        let graph = this.getGraphFromJsonReply(data, mainModule);   //graph = {nodes: [node], edges: [edge]}

        this.state.graph    = {
            nodes : graph.nodes,
            edges : graph.edges
        };
        this.state.options  = {
                autoResize: true,
                layout: {
                    hierarchical: {
                        enabled: true,
                        treeSpacing: 5
                    }
                },
                edges: {
                    smooth: true,
                    arrows : {
                        to: {
                            enabled: true,
                            type:"arrow"
                        }
                    }
                },
                nodes: {
                    shape: "box"
                },
                physics: {
                    enabled: true,
                    hierarchicalRepulsion: {
                        nodeDistance: 300
                    }
                }
        };
        this.state.nodesList = graph.nodes;
        
        this.state.network.once("stabilized", (event) => {
            this.state.network.fit();
            this.state.modules = graph.modules;
            this.setState(this.state);
            swapLoadingAndApp();
        });
        this.setState(this.state);
    }

    filterNodes() {
        if(this.state.graph === undefined ||
            this.state.nodesList.length == 0) {
            return;
        }

        let term = $("#search-bar input").val().trim().toLowerCase();
        if (term.length == 0) {
            this.state.network.selectNodes([]);
            return;
        }

        let nodeIdList = [];
        this.state.nodesList.forEach((item) => { 
            let label = item.label.trim().toLowerCase().replace(/\n/g, '');
            if(label.includes(term)) {
                nodeIdList.push(item.id);
            }
        });
        this.state.network.selectNodes(nodeIdList);
    }

    keyDownHandler(event) {
        if (event.keyCode == 13) {
            this.filterNodes();
        }
    }

    sidemenuToggle(event) {
        this.sidemenu.current.sidemenuToggle(event);
    }

    render() {
        return (
            <div onClick={this.sidemenuToggle} className="app-container">
                <Sidemenu ref={this.sidemenu}/>
                <div className="loading">
                    <span className="fa fa-cog fa-spin fa-9x fa-fw"></span>
                </div>
                <div className="app-contents">
                    <div id="search-bar" className="form-group">
                        <input className="form-control input-sm"
                            onKeyDown={this.keyDownHandler} placeholder="Search nodes"/>
                        <span className="fa fa-search fa-2x" onClick={this.filterNodes}></span>
                    </div>
                    <div className="graph">
                        <Graph graph={this.state.graph} options={this.state.options} getNetwork={this.setNetworkInstance}/>
                    </div>
                    <div className="legend">
                        <Legend modules= {this.state.modules}/>
                    </div>
                </div>
            </div>
        );
    }
}
