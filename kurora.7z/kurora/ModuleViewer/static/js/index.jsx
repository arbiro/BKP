import React from "react";
import ReactDOM from "react-dom";
import Sidenav from "./Sidenav";
require("../images/favicon.ico")

ReactDOM.render(
    <Sidenav />,
    document.getElementById("sidenav")
);