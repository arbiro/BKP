#!/bin/bash

echo "int main() {return 0;}" > test.cpp
echo -e "int main() {\n  return 0;\n}" > res.cpp

git add test.cpp

msg="test format clang hook"
git commit -m "$msg"

res1=`echo $?`

diff test.cpp res.cpp

res2=`echo $?`

if [ $res1 -eq 0 ]
then
    if [ $res2 -eq 0 ]
    then
	echo -e "\n SUCCESS \n git hook is working well"
    else
	echo -e "\n FAIL\n git hook installed but clang format seems to fail"
    fi
else
    echo -e "\n FAIL \n clang format was not found,\n Please verify your PATH env variable"
fi

# cleaning
# prevent reset on wrong commit
last="$(git log -1 --pretty=%B)"
if [ "$msg" = "$last" ]
then
    git reset HEAD~
fi
rm res.cpp
rm test.cpp
