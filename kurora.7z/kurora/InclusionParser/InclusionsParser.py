import sqlite3
import os
import argparse


class InclusionParser:
    def __init__(self, db_path):
        if not os.path.isfile(db_path):
            raise FileNotFoundError
        self.__db = sqlite3.connect(db_path)

    def get_all_sources_id(self):
        query = "SELECT id FROM Files WHERE path LIKE '%.cpp'"
        return self.__db.execute(query)

    def get_all_includes_from_file_id(self, file_id):
        query = "SELECT target FROM Inclusions WHERE source=" + str(file_id)
        return self.__db.execute(query)

    def get_all_nodes_for_file_ids(self, id_list):
        query = "SELECT id FROM Nodes WHERE path IN(" + id_list + ")"
        return self.__db.execute(query)

    def get_edges_between_file_id(self, src, dst):
        query =\
            "SELECT COUNT(*) FROM (" \
            "SELECT e.source, e.target FROM Edges e, " \
            "(SELECT id FROM Nodes WHERE path={src}) src_syms, " \
            "(SELECT id FROM Nodes WHERE path IN {dst}) hdr_syms " \
            "WHERE e.source = src_syms.id AND e.target = hdr_syms.id" \
            ")".format(**locals())

        return self.__db.execute(query)

    def get_file_path_by_id(self, file_id):
        query = "SELECT id,path FROM Files WHERE id IN {file_id}".format(**locals())

        return self.__db.execute(query)

    def get_inclusion_line_by_source_and_target(self, source_id, header_id):
        query = "SELECT line FROM Inclusions WHERE source={source_id} AND " \
                "target IN {header_id}".format(**locals())

        return self.__db.execute(query)

    def delete_inclusions_by_source_targets(self, source_id, target_ids):
        query = "DELETE FROM Inclusions WHERE source={source_id} AND " \
                "target IN {target_ids}".format(**locals())

        self.__db.execute(query)
        self.__db.commit()


class SourceFile:
    def __init__(self, file_id, ip: InclusionParser):
        self.file_id = file_id
        self.header_list = {}
        self.ip = ip
        self.symbols = None

    def set_sub_header_for_header(self, header, sub_headers):
        self.header_list[header] = sub_headers

    def set_symbols(self, symbols):
        self.symbols = symbols

    # Return a list with structured [necessary_headers_list, unnecessary headers_list]
    def get_necessary_includes(self):
        ret = ([], [])

        for header, sub_headers in self.header_list.items():
            edges_list = self.ip.get_edges_between_file_id(self.file_id, "(" + header + ")")
            size = edges_list.fetchone()[0]
            if size > 0:
                ret[0].append(header)

            else:
                edges_list = self.ip.get_edges_between_file_id(self.file_id, "(" + ", ".join(sub_headers) + ")")
                size = edges_list.fetchone()[0]
                if size > 0:
                    ret[0].append(header)
                else:
                    ret[1].append(header)
        return ret


def main():
    if __name__ != "__main__":
        exit(0)

    # Set up argument list
    parser = argparse.ArgumentParser(description="Unnecessary include directive parser")
    parser.add_argument("-p", "--path", help="Path to symbols database", required=True)
    parser.add_argument("-a", "--apply", help="Delete unused included from the source files", action="store_true")
    parser.add_argument("-r", "--results", help="Path to save output results", default="results", required=False)
    args = parser.parse_args()

    ip = InclusionParser(args.path)
    src_ids = ip.get_all_sources_id()
    results = args.results
    sources = []

    for src_id in src_ids:
        sources.append(SourceFile(str(src_id[0]), ip))

    # Initialize information for all source files
    for source in sources:
        header_ids = ip.get_all_includes_from_file_id(source.file_id)

        for header_id in header_ids:
            sub_headers = ip.get_all_includes_from_file_id(header_id[0])
            sub_header_list = []
            for sub_header in sub_headers:
                sub_header_list.append(str(sub_header[0]))
            source.set_sub_header_for_header(str(header_id[0]), sub_header_list)

    with open(results, "w") as save_filename:
        for source in sources:
            files = source.get_necessary_includes()

            # Source file info
            src_item = ip.get_file_path_by_id("(" + source.file_id + ")").fetchall()
            save_filename.write(str(src_item) + '\n')

            # Necessary headers
            hdr_list = "(" + ", ".join(files[0]) + ")"
            items = ip.get_file_path_by_id(hdr_list).fetchall()
            save_filename.write("necessary->" + str(items) + '\n')

            # Unnecessary headers
            hdr_list = "(" + ", ".join(files[1]) + ")"
            items = ip.get_file_path_by_id(hdr_list).fetchall()
            save_filename.write("unnecessary->" + str(items) + '\n\n')

            # Cleanup part
            if args.apply and len(files[1]) != 0:
                cursor = ip.get_inclusion_line_by_source_and_target(
                    source.file_id, hdr_list).fetchall()
                cleanup_lines = []

                for line in cursor:
                    cleanup_lines.append(line[0])
                counter = 0

                src_path = src_item[0][1]

                with open(src_path, "r") as src:
                    lines = src.readlines()

                with open(src_path, "w") as dst:
                    for line in lines:
                        counter += 1
                        if counter in cleanup_lines:
                            continue

                        dst.write(line)

                source.ip.delete_inclusions_by_source_targets(source.file_id, hdr_list)


main()
