import os


def get_last(path, level):
    end=len(path)
    for i in range(level):
        end = path.rfind("/", 0, end)
        if end == -1:
            return path
    return path[end+1:]


def multi_insert(d, key, item):
    if key in d:
        found = d[key]
    else:
        found = []
        d[key] = found
    found.append(item)

def crawl(path):
    with os.scandir(path) as it:
        for entry in it:
            if not entry.name.startswith('.'):
                if entry.is_file() and entry.name.endswith(".lf"):
                    common_pos = path.rfind("common")
                    if not common_pos == -1:
                        yield path[2:common_pos]
                elif entry.is_dir():
                    yield from crawl(entry.path)


module_set = set()
for path in crawl("."):
    if path.find("\\test\\") == -1 and path.find("\\gtest\\")== -1 and path.find("\\tests\\") == -1 and path.find("\\unittest\\") == -1:
        module_set.add(path[:-1].replace("\\", "/"))

module_dict = dict()
for path in module_set:
    key = get_last(path, 1)
    multi_insert(module_dict, key, path)

name_level = 1
while module_dict:
    name_to_remove = []
    for name, paths in module_dict.items():
        if len(paths) == 1:
            print(paths[0], name)
            name_to_remove.append(name)
    for name in name_to_remove:
        del module_dict[name]
    name_level += 1
    module_dict2 = dict()
    for name, paths in module_dict.items():
        for path in paths:
            key = get_last(path, name_level)
            multi_insert(module_dict2, key, path)
    module_dict = module_dict2
