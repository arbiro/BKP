import os
import re
import functools
import operator
from pathlib import Path

def get_owner_file(root):
    file_names= ["OWNERS","OWNERS.txt"]
    for name in file_names:
        owner_file= Path(root,name)
        if owner_file.is_file():
            return owner_file
    return None
   
def create_regexpr(pattern):
    regexpr="".join((c if (c.isalpha() or c in "_" or c.isnumeric()) else "\\"+c) for c in pattern)
    return regexpr.replace("\\*","(.*)")
   
def is_match_pattern(pattern,name):
    return re.match(create_regexpr(pattern),name) != None
   
def get_file_owners(patterns,name):
    result=set()
    for pair in patterns:
        if is_match_pattern(pair[0],name):
            result.add(pair[1])
    return result
   
def is_match_one(name,patterns):
    is_match_iter = (is_match_pattern(pattern,name) for pattern in patterns)
    return functools.reduce(operator.or_,is_match_iter,False)


def add_team_size(global_team_size,teams,size):
    for team in teams:
        global_team_size[team]=(global_team_size[team] if team in global_team_size else 0)+size
    
def read_owner_file(path,parent_owners): 
    per_file_owners=[]
    no_parent_file_patterns=set()
    file=get_owner_file(path)
    if not file:
        return parent_owners,per_file_owners,no_parent_file_patterns
    dir_owners=parent_owners.copy()
    local_owners=set()
    with file.open() as open_file:
        for line in open_file.readlines():
            line = line.split("#")[0].strip().lower() #remove comments
            if "per-file" in line:
                line=line.replace("per-file","").strip()
                pattern_owner=line.split("=")
                pattern=pattern_owner[0].strip()
                owner=pattern_owner[1].strip()
				owner=owner.split("@")[0]
                if "noparent" in owner:
                    no_parent_file_patterns.add(pattern)
                else:
                    per_file_owners.append([pattern,owner])
            elif "noparent" in line:
                dir_owners=set()
            elif line:
                local_owners.add(line)
    dir_owners|=local_owners
    return dir_owners,per_file_owners,no_parent_file_patterns
    
def crawl(path,parent_owners=set()):
    dir_owners,per_file_owners,no_parent_file_patterns=read_owner_file(path,parent_owners)
    yield dir_owners!=parent_owners,path[2:],dir_owners,0    
    with os.scandir(path) as it:
        for entry in it:
            if not entry.name.startswith('.'):
                if entry.is_file():
                    file_owners=get_file_owners(per_file_owners,entry.name)
                    if not is_match_one(entry.name,no_parent_file_patterns):
                        file_owners|=dir_owners
                    file_size=entry.stat().st_size
                    yield dir_owners!=file_owners,entry.path[2:],file_owners,file_size
                elif entry.is_dir():
                    yield from crawl(entry.path,dir_owners)
    
global_team_size={}    
for is_owned,path,owners,size in crawl("."):
    if size!=0:
        add_team_size(global_team_size,owners,size)
        
#Print the ownership by owned size
#print(sorted(global_team_size.items(),key=operator.itemgetter(1)))

for is_owned,path,owners,size in crawl("."):
    if is_owned:
        max_size_team=max(((team,global_team_size[team]) for team in owners),key=operator.itemgetter(1),default=("",0))[0]
        print(path,max_size_team)
