#pragma once
class StepUpdater {
public:
  virtual void setDivisionCount(int) = 0;
  virtual bool increment() = 0;
  virtual bool aborted() = 0;
};
