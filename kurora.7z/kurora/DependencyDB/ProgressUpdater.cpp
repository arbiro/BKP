#include "ProgressUpdater.h"
#include <tulip/Graph.h>

void PluginProgressWrapper::setProgress(int cur, int max) {
  progress->progress(cur, max);
  if (progress->state() != tlp::ProgressState::TLP_CONTINUE) {
    this->aborted = progress->state() == tlp::ProgressState::TLP_CANCEL;
    this->stopped = progress->state() == tlp::ProgressState::TLP_STOP;
    progress->setTitle("Cancelling/Aborting!");
    progress->setError("Operation cancelled/aborted!");
    emit stop();
  }
}

ProgressUpdater::ProgressUpdater(PluginProgressWrapper *wrapper) : m_wrapper(wrapper) {
  m_maxValue = std::numeric_limits<int>::max();
}

void ProgressUpdater::incrementProgress(const std::string &identifier, bool sync) {
  auto step = m_stepsMap.find(identifier);
  if (step != m_stepsMap.end()) {
    int cur = step->second.incrementV();
    if (!sync)
      emit progressChanged(cur, m_maxValue);
    else if (m_wrapper)
      m_wrapper->setProgress(cur, m_maxValue);
  }
}

ProgressUpdater &ProgressUpdater::setStep(const std::string &stepName, int min, int max) {
  m_stepsMap[stepName] = Step(int((double(min) / 100.0) * double(m_maxValue)),
                              int((double(max) / 100.0) * double(m_maxValue)));

  return *this;
}

ProgressUpdater &ProgressUpdater::setStepDivisions(const std::string &stepName, int divs) {
  auto step = m_stepsMap.find(stepName);
  if (step != m_stepsMap.end()) {
    step->second.setNumberOfDivisions(divs);
  }

  return *this;
}

bool ProgressUpdater::isCancelled() {
  if (m_wrapper)
    return m_wrapper->stopped;

  return false;
}

bool ProgressUpdater::isAborted() {
  if (m_wrapper)
    return m_wrapper->aborted;

  return false;
}
