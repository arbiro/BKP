#include <memory>
#include <algorithm>
#include <string>
#include <cctype>
#include <fstream>
#include <tulip/StringCollection.h>
#include <tulip/GraphProperty.h>
#include <tulip/ForEach.h>
#include <tulip/Graph.h>
#include <QtConcurrent/qtconcurrentrun.h>
#include <QtConcurrent/qtconcurrentmap.h>
#include <cstdio>
#include "DependencyDB.h"
#include "Database.h"
#include "ParserLib.h"
#include "ASTMatcherDepParser.h"
#include "ParserOptions.h"
#include <mutex>
#include <QTimer>
#include <QFutureWatcher>
#include <QApplication>
#include <ProgressUpdater.h>
#include "QTLogger.h"

PLUGIN(DependencyDB)

using namespace std;
using namespace tlp;

static const char *FILENAMECC = "file::compile_commands";
static const char *SAVEDBTO = "anyfile::filenamesavedb";
static const char *PARSEINCLUDES = "file::parseincludes";
static const char *GENERATEONLYDB = "file::generateOnlyDb";
static const char *PREFIXFILTER = "dir::prefixfilter";

DependencyDB::DependencyDB(tlp::PluginContext *context) : ImportModule(context) {
  InitializeQTLogger();
  addInParameter<string>(FILENAMECC, "The dependency database filename or compile_commands.json",
                         "");
  addInParameter<string>(PREFIXFILTER, "Path prefix filter", "");
  addInParameter<string>(SAVEDBTO, "DB Name", "");
  addInParameter<bool>(PARSEINCLUDES, "Parse includes", "TRUE");
  addInParameter<bool>(GENERATEONLYDB, "Don't create graph(ignored if db is being loaded)", "");
}

static std::string convertDOSToUnix(const std::string &dosPath) {
  static const std::string UNIX_SEPARATOR("/");
  static const std::string DOS_SEPARATOR("\\");
  std::string result = dosPath;
  for (auto found = result.find(DOS_SEPARATOR); found != std::string::npos;
       found = result.find(DOS_SEPARATOR)) {
    result.replace(found, DOS_SEPARATOR.size(), UNIX_SEPARATOR);
  }
  return result;
}

struct StepUpdaterImpl : public StepUpdater {
  StepUpdaterImpl(ProgressUpdater &updater, const std::string &id) : m_updater(updater), id(id) {}

  void setDivisionCount(int divs) override {
    m_updater.setStepDivisions(id, divs);
  }
  bool increment() override {
    m_updater.incrementProgress(id, true);
    return !(m_updater.isAborted() || m_updater.isCancelled());
  }

  bool aborted() override {
    return m_updater.isAborted();
  }
  ProgressUpdater &m_updater;
  std::string id;
};

bool DependencyDB::importGraph() {
  std::string compileCommands;
  std::string saveDbTo = "";
  std::string prefixFilter = "";
  bool generateOnlyDb = false;
  bool parseIncludes = true;
  bool retValue = true;

  if (dataSet != NULL) {
    dataSet->get(FILENAMECC, compileCommands);
    dataSet->get(SAVEDBTO, saveDbTo);
    dataSet->get(GENERATEONLYDB, generateOnlyDb);
    dataSet->get(PARSEINCLUDES, parseIncludes);
    dataSet->get(PREFIXFILTER, prefixFilter);
  }

  if (compileCommands.empty() && saveDbTo.empty()) {
    return false;
  }

  size_t foundCompileCommandsAt = compileCommands.find("compile_commands.json");
  pluginProgress->progress(0, 100);
  PluginProgressWrapper wrapper(pluginProgress);
  ProgressUpdater updater(&wrapper);
  StepUpdaterImpl stepUpdater(updater, "createGraph");
  QObject::connect(&updater, SIGNAL(progressChanged(int, int)), &wrapper,
                   SLOT(setProgress(int, int)), Qt::QueuedConnection);
  updater.setStep("createGraph", 0, 100);

  GraphAlgorithm algorithm(graph);
  if (foundCompileCommandsAt != std::string::npos) {
    std::string path(compileCommands.begin(), compileCommands.begin() + foundCompileCommandsAt);
    std::vector<std::string> files = getFilesInCompilationDb(path);
    std::transform(files.begin(), files.end(), files.begin(), convertDOSToUnix);
    prefixFilter = convertDOSToUnix(prefixFilter);
    files.erase(std::remove_if(files.begin(), files.end(),
                               [&](const std::string &str) {
                                 return str.size() < prefixFilter.size() ||
                                        str.substr(0, prefixFilter.size()) != prefixFilter;
                               }),
                files.end());

    bool deleteDbAfter = false;
    if (saveDbTo.empty()) {
      deleteDbAfter = true;
      saveDbTo = "temporaryDB.db";
      const int result = remove(saveDbTo.c_str()); // also remove before to make sure
    }

    int maxValue = std::numeric_limits<int>::max() / 2;
    int startValueForGraphAdd = int(double(maxValue) * 0.9);
    int incrementValueParsing = int(double(startValueForGraphAdd) / double(files.size()));

    updater.setStep("parse", 0, 90).setStep("createGraph", 90, 100);
    std::function<void()> incrementFunction =
        std::bind(&ProgressUpdater::incrementProgress, &updater, "parse", false);

    updater.setStepDivisions("parse", files.size());

    Database db(saveDbTo);
    QFuture<Database *> fut =
        QtConcurrent::mappedReduced<Database *, std::vector<std::string>, ParseFile, FillDatabase>(
            files, ParseFile(setOptions(files, path, parseIncludes), db),
            FillDatabase(db, incrementFunction));

    QFutureWatcher<Database *> watcher;
    watcher.setFuture(fut);
    QEventLoop loop;

    QObject::connect(&wrapper, SIGNAL(stop()), &watcher,
                     SLOT(cancel())); // when stop pressed send cancel to watcher
    QObject::connect(&watcher, SIGNAL(finished()), &loop, SLOT(quit()));
    loop.exec();

    if (wrapper.aborted || wrapper.stopped) {
      if (wrapper.aborted)
        remove(saveDbTo.c_str());
      return false;
    }

    if (!generateOnlyDb)
      retValue = algorithm.createGraph(db, &stepUpdater);
    if (deleteDbAfter)
      const int result = remove(saveDbTo.c_str());
  } else {
    if (!saveDbTo.empty())
      retValue = algorithm.createGraph(saveDbTo, &stepUpdater);
    else {
      pluginProgress->setError(
          "Neither compile commands or db was set, cannot create graph from void!");
      retValue = false;
    }
  }

  return retValue;
}

GraphAlgorithm::GraphAlgorithm(Graph *g)
    : graph(g), n_demangled(graph->getLocalProperty<tlp::StringProperty>("demangledName")),
      n_label(graph->getLocalProperty<tlp::StringProperty>("viewLabel")),
      n_shape(graph->getLocalProperty<tlp::IntegerProperty>("viewShape")),
      n_path(graph->getLocalProperty<tlp::StringProperty>("Path")),
      n_type(graph->getLocalProperty<tlp::StringProperty>("Type")),
      n_ln(graph->getLocalProperty<tlp::IntegerProperty>("Ln")),
      n_col(graph->getLocalProperty<tlp::IntegerProperty>("Col")),
      n_key(graph->getLocalProperty<tlp::StringProperty>("Key")) {}

void GraphAlgorithm::mapToProperty(node node, const PropertyMap &props, const string &name,
                                   StringProperty &tlpProperty) {
  auto found = props.find(name);

  if (found != props.end()) {
    tlpProperty.setNodeValue(node, found->second);
  }
}

string GraphAlgorithm::getNodeType(const PropertyMap &props) {
  auto found = props.find("type");
  return (found == props.end()) ? std::string() : found->second;
}

NodeShape::NodeShapes GraphAlgorithm::getNodeShape(const PropertyMap &props) {
  std::string type = getNodeType(props);

  auto found = props.find("usr");
  if (found != props.end()) {
    std::string usr = found->second;
    if (!usr.empty() && usr[usr.size() - 1] == 'r') {
      return tlp::NodeShape::RoundedBox;
    }
  }

  return tlp::NodeShape::Circle;
}

tlp::node GraphAlgorithm::addNode(const PropertyMap &props) {
  try {
    int id = std::stoi(props.at("id"));
    tlp::node n = graph->addNode();
    if (!seenSymbols.insert({id, n}).second) {
      std::cerr << "Another node with the same id " << id << " found when importing" << std::endl;
    }
    // std::cout << "GNode " << n << " " << props.at("usr") << std::endl;
    mapToProperty(n, props, "usr", *n_key);
    mapToProperty(n, props, "demangled_name", *n_label);
    mapToProperty(n, props, "demangled_name", *n_demangled);
    mapToProperty(n, props, "path", *n_path);

    n_shape->setNodeValue(n, getNodeShape(props));

    auto foundLn = props.find("ln");
    if (foundLn != props.end()) {
      n_ln->setNodeValue(n, std::stoi(foundLn->second));
    }
    auto foundCol = props.find("col");
    if (foundCol != props.end()) {
      n_col->setNodeValue(n, std::stoi(foundCol->second));
    }
    return n;
  } catch (std::exception const &) {
  }
  return tlp::node();
}

edge GraphAlgorithm::addEdge(const node &source, const node &target, const PropertyMap &props) {
  if (source == target) {
    return edge();
  }

  edge e = graph->existEdge(source, target);
  if (e.isValid()) {
    return e;
  }

  e = graph->addEdge(source, target);
  if (props.find("type") != props.end() && !props.at("type").empty()) {
    string typeS = props.at("type");
    LinkType type = LinkType::NA;

    try {
      type = LinkType::fromValue(stoi(typeS));
    } catch (...) {
    }

    n_type->setEdgeValue(e, type.getName());
    // std::cout << "GEdge " << source << " -" << typeS<<"> "<<target << std::endl;
  }

  return e;
}

node GraphAlgorithm::existNode(int id) {
  auto found = seenSymbols.find(id);
  return (found != seenSymbols.end()) ? found->second : tlp::node(UINT_MAX);
}

edge GraphAlgorithm::addEdge(const PropertyMap &props) {
  try {
    int source = std::stoi(props.at("source"));
    int target = std::stoi(props.at("target"));
    // std::cout << "PGEdge " << source << " -" << props.at("type") << "> " << target << std::endl;
    node sourceNode = existNode(source);
    if (!sourceNode.isValid()) {
      std::cerr << "Source node" << source << " not found" << std::endl;
      return edge();
    }

    node targetNode = existNode(target);
    if (!targetNode.isValid()) {
      std::cerr << "Target node" << source << " not found" << std::endl;
      return edge();
    }

    return addEdge(sourceNode, targetNode, props);
  } catch (std::exception const &) {
  }
  return edge();
}

bool GraphAlgorithm::createGraph(std::string &dbFilename, StepUpdater *updater) {
  Database db(dbFilename);

  return createGraph(db, updater);
}

bool GraphAlgorithm::createGraph(Database &db, StepUpdater *updater) {
  int nodesCount = db.getTotalNodesCount();
  int edgesCount = db.getTotalEdgesCount();
  if (nodesCount + edgesCount == 0) {
    return false;
  }

  if (updater) {
    updater->setDivisionCount(nodesCount + edgesCount);
  }

  PropertyMap props;

  auto nodeIter = db.getIteratorOnNodes();
  while ((*nodeIter)(props)) {
    addNode(props);
    if (updater) {
      if (!updater->increment()) {
        if (updater->aborted()) {
          graph->clear();
          return false;
        }
        return true;
      }
    }
  }

  auto edgeIter = db.getIteratorOnEdges();
  while ((*edgeIter)(props)) {
    addEdge(props);
    if (updater) {
      if (!updater->increment()) {
        if (updater->aborted()) {
          graph->clear();
          return false;
        }
        return true;
      }
    }
  }

  return true;
}

ParseFile::ParseFile(const ParsingOptions &options, const Database &db)
    : m_options(options), m_db(db) {}

std::pair<std::string, BatchSymbols *> ParseFile::operator()(const std::string &file) {
  if (m_db.existFile(file) > -1) {
    return std::make_pair(file, nullptr);
  }

  if (m_options.useAST) {
    return parseFilesAST(file, m_options);
  }
  return parseFiles(file, m_options);
}
