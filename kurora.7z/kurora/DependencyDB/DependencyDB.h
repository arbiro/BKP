#pragma once

#include <tulip/TulipPluginHeaders.h>
#include <tulip/NumericProperty.h>
#include <tulip/TulipViewSettings.h>
#include "DependencyDBGlobal.h"
#include "ParserLib.h"
#include "StepUpdater.h"
#include <functional>

class DependencyDB : public tlp::ImportModule {
public:
  PLUGININFORMATION("Dependency db", "Murex Team", "29/01/2018", "Generates a graph from database.",
                    "1.0", "Misc")
  DependencyDB(tlp::PluginContext *context);
  bool importGraph();
};

class Database;

class DEPENDENCYDB_LINK GraphAlgorithm {
public:
  GraphAlgorithm(tlp::Graph *graph);
  bool createGraph(std::string &dbFilename, StepUpdater *updater = nullptr);
  bool createGraph(Database &db, StepUpdater *updater = nullptr);

private:
  class UsrHash {
  public:
    UsrHash(tlp::StringProperty *n_key_) : n_key(n_key_) {}

    size_t operator()(const tlp::node &n) const {
      return std::hash<std::string>()(n_key->getNodeValue(n));
    }

  private:
    tlp::StringProperty *n_key;
  };

  class EqualUsr {
  public:
    EqualUsr(tlp::StringProperty *n_key_) : n_key(n_key_) {}

    bool operator()(const tlp::node &n1, const tlp::node &n2) const {
      return n_key->getNodeValue(n1) == n_key->getNodeValue(n2);
    }

  private:
    tlp::StringProperty *n_key;
  };

  using PropertyMap = std::unordered_map<std::string, std::string>;

  void mapToProperty(tlp::node node, const PropertyMap &props, const std::string &name,
                     tlp::StringProperty &tlpProperty);
  std::string getNodeType(const PropertyMap &props);
  tlp::NodeShape::NodeShapes getNodeShape(const PropertyMap &props);

  tlp::node addNode(const PropertyMap &props);
  tlp::edge addEdge(const PropertyMap &props);

  tlp::node existNode(int id);
  tlp::edge addEdge(const tlp::node &n1, const tlp::node &n2, const PropertyMap &props);

  tlp::Graph *graph;
  tlp::PluginProgress *pluginProgress;

  tlp::StringProperty *n_demangled;
  tlp::StringProperty *n_label;
  tlp::IntegerProperty *n_shape;
  tlp::StringProperty *n_path;
  tlp::StringProperty *n_type;
  tlp::IntegerProperty *n_ln;
  tlp::IntegerProperty *n_col;
  tlp::StringProperty *n_key;

  std::unordered_map<int, tlp::node> seenSymbols;
};

class Database;
class BatchSymbols;

struct DEPENDENCYDB_LINK ParseFile {
  ParseFile(const ParsingOptions &options, const Database &db);
  std::pair<std::string, BatchSymbols *> operator()(const std::string &file);
  typedef std::pair<std::string, BatchSymbols *> result_type;

private:
  ParsingOptions m_options;
  const Database &m_db;
};
