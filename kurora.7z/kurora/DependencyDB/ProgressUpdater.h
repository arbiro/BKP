#pragma once
#include "qobject.h"
#include <unordered_map>

namespace tlp {
class PluginProgress;
}

class PluginProgressWrapper : public QObject {
  Q_OBJECT
public:
  PluginProgressWrapper(tlp::PluginProgress *prog) : progress(prog) {}
  bool stopped = false;
  bool aborted = false;

public slots:
  void setProgress(int cur, int max);

private:
  tlp::PluginProgress *progress;

public:
signals:
  void stop();
};

class ProgressUpdater : public QObject {
  Q_OBJECT
public:
  ProgressUpdater(PluginProgressWrapper *wrapper);

  void incrementProgress(const std::string &identifier, bool sync = false);

  ProgressUpdater &setStep(const std::string &stepName, int min, int max);

  ProgressUpdater &setStepDivisions(const std::string &stepName, int divs);

  bool isCancelled();

  bool isAborted();

private:
  int m_maxValue;

  struct Step {
    Step() : min(0), max(0), currentValue(0) {}
    Step(int _min, int _max) : min(_min), max(_max), currentValue(_min) {}

    void setNumberOfDivisions(int divs) {
      increment = (max - min) / divs;
    }

    int incrementV() {
      return currentValue += increment;
    }
    bool started = false;
    int currentValue = 0;
    int min = 0;
    int max = 0;
    int increment = 0;
    bool sync = true;
  };

  std::unordered_map<std::string, Step> m_stepsMap;
  PluginProgressWrapper *m_wrapper;

signals:
  void progressChanged(int, int);
};
