#pragma once

/* MSVC DLL import/export. */
#ifdef _MSC_VER
#pragma warning(disable : 4297)
#ifdef DEPENDENCYDB_LIB
#define DEPENDENCYDB_LINK __declspec(dllexport)
#else
#define DEPENDENCYDB_LINK __declspec(dllimport)
#endif
#else
#define DEPENDENCYDB_LINK
#endif
