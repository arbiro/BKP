#include <functional>
#include <memory>

#include <tulip/StringCollection.h>
#include <tulip/DoubleProperty.h>
#include <tulip/ForEach.h>

#include "FeedbackArcSet.h"

PLUGIN(FeedbackArcSet)

FeedbackArcSet::FeedbackArcSet(tlp::PluginContext *context) : BooleanAlgorithm(context) {
  addInParameter<tlp::PropertyInterface *>("Numeric Property",
                                           "Numeric Property used as edge weight", "viewMetric");
}

namespace {
struct IsSamePath {
  tlp::Graph *graph;
  tlp::BooleanProperty *result;
  std::unique_ptr<tlp::NodeStaticProperty<bool>> isDone;
  std::unique_ptr<tlp::NodeStaticProperty<bool>> isInStack;
  IsSamePath(tlp::Graph *graph, tlp::BooleanProperty *result)
      : graph(graph), result(result), isDone(new tlp::NodeStaticProperty<bool>(graph)),
        isInStack(new tlp::NodeStaticProperty<bool>(graph)) {
    isDone->setAll(false);
    isInStack->setAll(false);
  }
  bool operator()(tlp::node current) {
    if (isDone->getNodeValue(current))
      return isInStack->getNodeValue(current);
    isDone->setNodeValue(current, true);
    isInStack->setNodeValue(current, true);
    std::unique_ptr<tlp::Iterator<tlp::edge>> iter(graph->getOutEdges(current));
    while (iter->hasNext()) {
      tlp::edge e = iter->next();
      if ((*this)(graph->target(e))) {
        result->setEdgeValue(e, true);
      }
    }
    isInStack->setNodeValue(current, false);
  }
};
} // namespace

bool FeedbackArcSet::run() {
  tlp::DoubleProperty *weight = NULL;
  double x = 0.0;
  if (dataSet != NULL) {
    dataSet->get("Numeric Property", weight);
  }
  result->setAllNodeValue(false);
  result->setAllEdgeValue(false);
  tlp::node n;
  IsSamePath isSamePath(graph, result);
  forEach (n, graph->getNodes()) { isSamePath(n); }
  return true;
}
