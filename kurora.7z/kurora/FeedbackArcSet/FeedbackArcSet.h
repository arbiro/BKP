#pragma once

#include <tulip/TulipPluginHeaders.h>

class FeedbackArcSet : public tlp::BooleanAlgorithm {
public:
  PLUGININFORMATION("Feedback Arc Set", "Murex Team", "17/01/2018", "Select a feedback arc set",
                    "1.0", "Selection");
  FeedbackArcSet(tlp::PluginContext *context);

  bool run();
};
