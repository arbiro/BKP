#pragma once

#include <tulip/TulipPluginHeaders.h>

class PropertyValues : public tlp::BooleanAlgorithm {
public:
  PLUGININFORMATION(
      "Property Values", "Murex Team", "27/06/2017",
      "Select nodes or edges where the property values satisfy a condition depending on one value.",
      "1.0", "Selection");
  PropertyValues(tlp::PluginContext *context);

  bool run();
};
