#include <functional>

#include <tulip/StringCollection.h>

#include <PropertyValues.h>

PLUGIN(PropertyValues)

enum SourceType {
  SOURCE_NODES_AND_EDGES = 0,
  SOURCE_NODES,
  SOURCE_EDGES,
  SOURCE_EDGE_SOURCES,
  SOURCE_EDGE_TARGETS
};

static const char *INPUT_PROPERTY = "property";
static const char *OPERATOR = "operator";
static const char *VALUE = "value";
static const char *SOURCE_TYPE = "source";
static const char *SOURCE_TYPES = "nodes&edges;nodes;edges;edge sources;edge targets";

PropertyValues::PropertyValues(tlp::PluginContext *context) : BooleanAlgorithm(context) {
  addInParameter<tlp::PropertyInterface *>(INPUT_PROPERTY, "The Property used", "viewMetric");
  addInParameter<tlp::StringCollection>(
      OPERATOR, "binary operator ('<lex', '=', '>lex', '<num', 'num>')", "<lex;=;>lex;<num;num>",
      true, "<lex <br> = <br> lex> <br> <num <br> num>");
  addInParameter<std::string>(VALUE, "Value", "0", true);
  addInParameter<tlp::StringCollection>(
      SOURCE_TYPE, "Where the values are comming from.", SOURCE_TYPES, true,
      "nodes&edges <br> nodes <br> edges <br> edge sources <br> edge targets");
}

bool PropertyValues::run() {
  if (!dataSet)
    return false;

  tlp::PropertyInterface *property = nullptr;
  dataSet->get(INPUT_PROPERTY, property);

  std::string x;
  dataSet->get(VALUE, x);

  tlp::StringCollection targetTypeCollection;
  dataSet->get(SOURCE_TYPE, targetTypeCollection);
  SourceType targetType = static_cast<SourceType>(targetTypeCollection.getCurrent());

  std::function<bool(const std::string &)> myPredicate;
  {
    std::string symb;
    tlp::StringCollection tmp;
    if (dataSet->get(OPERATOR, tmp)) {
      symb = tmp.getCurrentString();
    }
    if (symb == "=") {
      myPredicate = [&](const std::string &value) { return value == x; };
    } else if (symb == "<lex") {
      myPredicate = [&](const std::string &value) { return value < x; };
    } else if (symb == "lex>") {
      myPredicate = [&](const std::string &value) { return value > x; };
    } else if (symb == "num>") {
      myPredicate = [&](const std::string &value) {
        return value.size() > x.size() || (value.size() == x.size() && value > x);
      };
    } else if (symb == "<num") {
      myPredicate = [&](const std::string &value) {
        return value.size() < x.size() || (value.size() == x.size() && value < x);
      };
    } else {
      myPredicate = [&](const std::string &value) { return false; };
    }
  }

  if (targetType == SOURCE_NODES || targetType == SOURCE_NODES_AND_EDGES) {
    for (tlp::node n : graph->nodes()) {
      if (myPredicate(property->getNodeStringValue(n))) {
        result->setNodeValue(n, true);
      }
    }
  }

  if (targetType == SOURCE_EDGES || targetType == SOURCE_NODES_AND_EDGES) {
    for (tlp::edge e : graph->edges()) {
      if (myPredicate(property->getEdgeStringValue(e))) {
        result->setEdgeValue(e, true);
      }
    }
  }

  if (targetType == SOURCE_EDGE_SOURCES || targetType == SOURCE_EDGE_TARGETS) {
    std::function<tlp::node(tlp::edge)> origin;
    if (targetType == SOURCE_EDGE_SOURCES) {
      origin = [=](tlp::edge e) { return graph->source(e); };
    } else {
      origin = [=](tlp::edge e) { return graph->target(e); };
    }
    for (tlp::edge e : graph->edges()) {
      if (myPredicate(property->getNodeStringValue(origin(e)))) {
        result->setEdgeValue(e, true);
      }
    }
  }
  return true;
}
